# Anti-slop provenance

Vendored `src/` and MIT license from dmmulroy/anti-slop revision
`95a56e5d24fb3d849673c2d51eb0908b8bd2d33b` (9 September 2026).
Upstream deliberately does not publish an npm package. The supported Oxlint
`jsPlugins` integration is in the root config, with every general rule enabled.
The optional Effect plugin is not enabled because Leerr does not use Effect.
Keep `oxlint` and `@oxlint/plugins` pinned to identical versions when upgrading.
