import { mkdtemp, rm } from "node:fs/promises"
import { tmpdir } from "node:os"
import { join } from "node:path"
import * as Actual from "@actual-app/api"
import { Context, Effect, Layer, Option, Redacted, Semaphore } from "effect"
import * as Connections from "./configuration/connections.ts"
import { BudgetOperationFailed, BudgetUnavailable, type ConnectionNotConfigured, type CredentialUnavailable } from "./errors.ts"
import * as ServerConfig from "./server-config.ts"

/**
 * Access to the Actual budget through `@actual-app/api`.
 *
 * Actual has no REST API: the package runs Actual's own engine against a local
 * copy of the budget and syncs changes with the server. The engine is a
 * process-wide singleton, so every budget operation runs inside `use`, one at a
 * time. The copy lives in a temporary directory, is downloaded on first use and
 * is discarded on shutdown or when the connection changes.
 *
 * `@actual-app/api` must match the server's version or opening the budget fails
 * with a migrations error.
 */
export interface Interface {
  /**
   * Run `body` against the open budget, pulling server changes first. With
   * `"write"`, local changes are pushed to the server afterwards.
   *
   * Inside `body`, call the engine through `call`.
   */
  readonly use: <A, E, R>(
    mode: "read" | "write",
    body: Effect.Effect<A, E, R>,
  ) => Effect.Effect<A, E | ConnectionNotConfigured | CredentialUnavailable | BudgetUnavailable | BudgetOperationFailed, R>
}

export class Service extends Context.Service<Service, Interface>()("homelab-mcp/ActualBudget") {}

const describe = (error: unknown): string => (error instanceof Error ? error.message : String(error))

/** Call the Actual engine; only valid inside `Service.use`. */
export const call = <A>(operation: string, run: () => Promise<A>): Effect.Effect<A, BudgetOperationFailed> =>
  Effect.tryPromise({ try: run, catch: (error) => new BudgetOperationFailed({ operation, detail: describe(error) }) })

type Session = {
  readonly dataDir: string
  readonly serverUrl: string
  readonly password: string
}

export const layer: Layer.Layer<Service, never, ServerConfig.Service | Connections.Service> = Layer.effect(
  Service,
  Effect.gen(function* () {
    const { actualBudgetSyncId } = yield* ServerConfig.Service
    const connections = yield* Connections.Service
    const lock = yield* Semaphore.make(1)
    let session: Option.Option<Session> = Option.none()

    const unavailable = (step: string) => (error: unknown) => new BudgetUnavailable({ reason: `${step}: ${describe(error)}` })

    const close = (current: Session) =>
      Effect.promise(async () => {
        session = Option.none()
        await Actual.shutdown().catch(() => undefined)
        await rm(current.dataDir, { recursive: true, force: true })
      })

    const resolveSyncId = Option.match(actualBudgetSyncId, {
      onSome: Effect.succeed,
      onNone: () =>
        Effect.tryPromise({ try: () => Actual.getBudgets(), catch: unavailable("listing budgets") }).pipe(
          Effect.flatMap((budgets) => {
            const remote = new Map(budgets.flatMap((budget) => (budget.groupId === undefined ? [] : [[budget.groupId, budget.name]])))
            const [only, ...rest] = remote.keys()
            if (only !== undefined && rest.length === 0) return Effect.succeed(only)
            const choices = [...remote].map(([id, name]) => `${name} (${id})`).join(", ")
            return Effect.fail(
              new BudgetUnavailable({
                reason:
                  remote.size === 0
                    ? "the Actual server has no budgets"
                    : `several budgets exist, set ACTUAL_BUDGET_SYNC_ID to one of: ${choices}`,
              }),
            )
          }),
        ),
    })

    const open = (serverUrl: string, password: string) =>
      Effect.gen(function* () {
        const dataDir = yield* Effect.promise(() => mkdtemp(join(tmpdir(), "homelab-mcp-actual-")))
        const opened: Session = { dataDir, serverUrl, password }
        yield* Effect.gen(function* () {
          yield* Effect.tryPromise({
            try: () => Actual.init({ dataDir, serverURL: serverUrl, password, verbose: false }),
            catch: unavailable(`signing in to ${serverUrl}`),
          })
          const syncId = yield* resolveSyncId
          yield* Effect.tryPromise({
            try: () => Actual.downloadBudget(syncId),
            catch: unavailable(`opening budget ${syncId}`),
          })
        }).pipe(Effect.onError(() => close(opened)))
        session = Option.some(opened)
      })

    const sync = call("sync", () => Actual.sync())

    const ensureOpen = Effect.gen(function* () {
      const connection = yield* connections.resolve("actual")
      const serverUrl = connection.baseUrl.href.replace(/\/$/, "")
      const password = Redacted.value(connection.credential)
      if (Option.isSome(session)) {
        if (session.value.serverUrl === serverUrl && session.value.password === password) return yield* sync
        yield* close(session.value)
      }
      yield* open(serverUrl, password)
    })

    yield* Effect.addFinalizer(() => Effect.suspend(() => Option.match(session, { onNone: () => Effect.void, onSome: close })))

    return Service.of({
      use: (mode, body) =>
        lock.withPermit(
          Effect.gen(function* () {
            yield* ensureOpen
            const result = yield* body
            if (mode === "write") {
              yield* sync.pipe(
                Effect.mapError(
                  (error) =>
                    new BudgetOperationFailed({
                      operation: "sync",
                      detail: `the change was applied to this server's copy but not uploaded yet and will be retried on the next budget call: ${error.detail}`,
                    }),
                ),
              )
            }
            return result
          }),
        ),
    })
  }),
)
