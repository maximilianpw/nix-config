import { Context, Effect, FileSystem, Layer, Option, Path, Redacted, Ref, Result, Schema } from "effect"
import { CredentialUnavailable } from "./errors.ts"
import type { MediaService } from "./media-service.ts"
import * as ServerConfig from "./server-config.ts"

/**
 * Upstream API credentials and the token MCP clients must present.
 *
 * Each application keeps its generated credential in its own state, so Kim hands
 * this server a copy of that state file through systemd `LoadCredential=` rather
 * than duplicating the key into sops. The files, relative to the credentials
 * directory, are:
 *
 * - `sonarr-config.xml`, `radarr-config.xml`, `lidarr-config.xml`, `prowlarr-config.xml`: `<ApiKey>`
 * - `seerr-settings.json`: `main.apiKey`
 * - `plex-token`: the bare Plex token, or else `plex-preferences.xml`: the `PlexOnlineToken` attribute
 * - `lastfm-api-key`: a Last.fm application API key, for public read methods only
 * - `mcp-access-token`: the bearer token MCP clients send (required)
 *
 * A missing or unreadable application file disables only that application until
 * the file appears.
 */
export interface Interface {
  /** Credential for one application, or why it is unavailable. Retries the file if it failed to load before. */
  readonly credential: (service: MediaService) => Effect.Effect<Redacted.Redacted<string>, CredentialUnavailable>
  /** Re-read one application's credential file, e.g. after the application rejected the loaded key. */
  readonly reload: (service: MediaService) => Effect.Effect<Redacted.Redacted<string>, CredentialUnavailable>
  /** Credential file(s) for one application, for error messages. */
  readonly describeSource: (service: MediaService) => string
  /** Bearer token every MCP request must carry. */
  readonly accessToken: Redacted.Redacted<string>
}

/** Credentials loaded at startup. */
export class Service extends Context.Service<Service, Interface>()("homelab-mcp/Credentials") {}

/** The mandatory MCP access token file is missing, empty, or unreadable. */
export class AccessTokenUnavailable extends Schema.TaggedError<AccessTokenUnavailable>()("AccessTokenUnavailable", {
  path: Schema.String,
  reason: Schema.String,
}) {
  override get message(): string {
    return `MCP access token unavailable at ${this.path}: ${this.reason}`
  }
}

const PLEX_TOKEN_FILE_CONTENTS = /^\s*(\S+)\s*$/
const SERVARR_API_KEY = /<ApiKey>\s*([A-Za-z0-9]+)\s*<\/ApiKey>/
const PLEX_TOKEN = /\bPlexOnlineToken="([^"]+)"/
const SeerrSettings = Schema.fromJsonString(
  Schema.Struct({ main: Schema.Struct({ apiKey: Schema.NonEmptyString }) }),
)
const decodeSeerrSettings = Schema.decodeUnknownResult(SeerrSettings)

type CredentialFile = {
  readonly file: string
  readonly parse: (contents: string) => Option.Option<string>
}

const servarrSource = (file: string): ReadonlyArray<CredentialFile> => [
  { file, parse: (contents) => Option.fromNullishOr(SERVARR_API_KEY.exec(contents)?.[1]) },
]

/** Files holding each application's credential, in order of preference; the first file that exists is used. */
const SOURCES: Readonly<Record<MediaService, ReadonlyArray<CredentialFile>>> = {
  lastfm: [{ file: "lastfm-api-key", parse: (contents) => Option.fromNullishOr(/^\s*([a-fA-F0-9]{32})\s*$/.exec(contents)?.[1]) }],
  sonarr: servarrSource("sonarr-config.xml"),
  radarr: servarrSource("radarr-config.xml"),
  lidarr: servarrSource("lidarr-config.xml"),
  prowlarr: servarrSource("prowlarr-config.xml"),
  seerr: [
    {
      file: "seerr-settings.json",
      parse: (contents) => Result.getSuccess(decodeSeerrSettings(contents)).pipe(Option.map((settings) => settings.main.apiKey)),
    },
  ],
  // `plex-token` lets Kim hand over only the token instead of all of Preferences.xml,
  // which also holds the server's certificate and other account details.
  plex: [
    { file: "plex-token", parse: (contents) => Option.fromNullishOr(PLEX_TOKEN_FILE_CONTENTS.exec(contents)?.[1]) },
    { file: "plex-preferences.xml", parse: (contents) => Option.fromNullishOr(PLEX_TOKEN.exec(contents)?.[1]) },
  ],
}

const ACCESS_TOKEN_FILE = "mcp-access-token"

/** Reads every credential file once from the configured credentials directory. */
export const layer: Layer.Layer<
  Service,
  AccessTokenUnavailable,
  ServerConfig.Service | FileSystem.FileSystem | Path.Path
> = Layer.effect(
  Service,
  Effect.gen(function* () {
    const { credentialsDirectory } = yield* ServerConfig.Service
    const fs = yield* FileSystem.FileSystem
    const path = yield* Path.Path

    type Loaded = Result.Result<Redacted.Redacted<string>, CredentialUnavailable>

    const loadFile = (service: MediaService, source: CredentialFile): Effect.Effect<Loaded> =>
      fs.readFileString(path.join(credentialsDirectory, source.file)).pipe(
        Effect.map((contents) =>
          Option.match(source.parse(contents), {
            onNone: () =>
              Result.fail(new CredentialUnavailable({ service, reason: `${source.file} does not contain a credential` })),
            onSome: (secret) => Result.succeed(Redacted.make(secret)),
          }),
        ),
        Effect.catch((error) =>
          Effect.succeed(Result.fail(new CredentialUnavailable({ service, reason: `${source.file}: ${error.message}` }))),
        ),
      )

    const load = Effect.fnUntraced(function* (service: MediaService) {
      const sources = SOURCES[service]
      const reasons: Array<string> = []
      for (const [index, source] of sources.entries()) {
        const isLast = index === sources.length - 1
        const exists = isLast || (yield* fs.exists(path.join(credentialsDirectory, source.file)).pipe(Effect.orElseSucceed(() => false)))
        if (!exists) {
          reasons.push(`${source.file} not found`)
          continue
        }
        const loaded = yield* loadFile(service, source)
        if (Result.isSuccess(loaded) || reasons.length === 0) return loaded
        return Result.fail(new CredentialUnavailable({ service, reason: [...reasons, loaded.failure.reason].join("; ") }))
      }
      return Result.fail(new CredentialUnavailable({ service, reason: reasons.join("; ") }))
    })

    const initial: Readonly<Record<MediaService, Loaded>> = yield* Effect.all(
      {
        seerr: load("seerr"),
        sonarr: load("sonarr"),
        radarr: load("radarr"),
        lidarr: load("lidarr"),
        prowlarr: load("prowlarr"),
        plex: load("plex"),
        lastfm: load("lastfm"),
      },
      { concurrency: "unbounded" },
    )
    const cache = yield* Ref.make(initial)

    const reload = (service: MediaService) =>
      load(service).pipe(
        Effect.tap((loaded) => Ref.update(cache, (current) => ({ ...current, [service]: loaded }))),
        Effect.flatMap((loaded) => Result.match(loaded, { onSuccess: Effect.succeed, onFailure: Effect.fail })),
      )

    const credential = (service: MediaService) =>
      Effect.flatMap(Ref.get(cache), (current) =>
        Result.match(current[service], { onSuccess: Effect.succeed, onFailure: () => reload(service) }),
      )

    const tokenPath = path.join(credentialsDirectory, ACCESS_TOKEN_FILE)
    const token = yield* fs.readFileString(tokenPath).pipe(
      Effect.mapError((error) => new AccessTokenUnavailable({ path: tokenPath, reason: error.message })),
      Effect.map((contents) => contents.trim()),
    )
    if (token.length < 32) {
      return yield* new AccessTokenUnavailable({ path: tokenPath, reason: "token must be at least 32 characters" })
    }

    return Service.of({
      credential,
      reload,
      describeSource: (service) => SOURCES[service].map((source) => source.file).join(" or "),
      accessToken: Redacted.make(token),
    })
  }),
)
