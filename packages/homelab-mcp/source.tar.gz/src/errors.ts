import { Schema } from "effect"
import { MediaService } from "./media-service.ts"

/** An application's credential was not loaded, so its API cannot be called. */
export class CredentialUnavailable extends Schema.TaggedError<CredentialUnavailable>()("CredentialUnavailable", {
  service: MediaService,
  reason: Schema.String,
}) {
  override get message(): string {
    return `Media service credential unavailable for ${this.service}: ${this.reason}`
  }
}

/** No usable connection exists for the application, so its API cannot be called. */
export class ConnectionNotConfigured extends Schema.TaggedError<ConnectionNotConfigured>()("ConnectionNotConfigured", {
  service: MediaService,
  reason: Schema.String,
}) {
  override get message(): string {
    return `Media service not configured: ${this.service}: ${this.reason}`
  }
}

/** The application could not be reached or did not answer in time. */
export class UpstreamUnreachable extends Schema.TaggedError<UpstreamUnreachable>()("UpstreamUnreachable", {
  service: MediaService,
  method: Schema.String,
  path: Schema.String,
  detail: Schema.String,
}) {
  override get message(): string {
    return `Media service unreachable: ${this.service} ${this.method} ${this.path} failed: ${this.detail}`
  }
}

/** The application answered with a non-success HTTP status. */
export class UpstreamRejected extends Schema.TaggedError<UpstreamRejected>()("UpstreamRejected", {
  service: MediaService,
  method: Schema.String,
  path: Schema.String,
  status: Schema.Int,
  detail: Schema.String,
}) {
  override get message(): string {
    return `Media service rejected request: ${this.service} ${this.method} ${this.path} returned ${this.status}: ${this.detail}`
  }
}

/** The application answered successfully but its body did not have the expected shape. */
export class UpstreamResponseInvalid extends Schema.TaggedError<UpstreamResponseInvalid>()("UpstreamResponseInvalid", {
  service: MediaService,
  method: Schema.String,
  path: Schema.String,
  detail: Schema.String,
}) {
  override get message(): string {
    return `Media service response invalid: ${this.service} ${this.method} ${this.path}: ${this.detail}`
  }
}

/**
 * A tool request cannot proceed as given, for example because a required choice is ambiguous.
 *
 * The reason tells the caller which values would make the request valid.
 */
export class MediaRequestInvalid extends Schema.TaggedError<MediaRequestInvalid>()("MediaRequestInvalid", {
  reason: Schema.String,
}) {
  override get message(): string {
    return `Media request invalid: ${this.reason}`
  }
}

/** Any failure an upstream API call can produce. */
export type MediaApiError = ConnectionNotConfigured | CredentialUnavailable | UpstreamUnreachable | UpstreamRejected | UpstreamResponseInvalid

/** Failure schema shared by every tool; the MCP client receives the error's message. */
export const MediaToolError = Schema.Union([
  ConnectionNotConfigured,
  CredentialUnavailable,
  UpstreamUnreachable,
  UpstreamRejected,
  UpstreamResponseInvalid,
  MediaRequestInvalid,
])
