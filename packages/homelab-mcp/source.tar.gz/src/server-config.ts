import { Config, Context, Effect, Layer, Option } from "effect"
import type { LibraryService, MediaService } from "./media-service.ts"

/**
 * Process and deployment settings, read once from the environment at startup.
 *
 * Application settings such as connections live in the database; the `legacy*` values
 * only serve installations that still read upstream credentials from files.
 */
export interface Interface {
  /** Interface the HTTP endpoint binds to. */
  readonly host: string
  readonly port: number
  /** Directory holding `mcp-access-token` and any legacy credential files described in `credentials.ts`. */
  readonly credentialsDirectory: string
  /** Persistent state directory; `None` keeps state in memory until restart. */
  readonly dataDirectory: Option.Option<string>
  /** Externally supplied key file for sealing stored credentials; defaults to `secret-key` in the data directory. */
  readonly secretKeyFile: Option.Option<string>
  /** Origin of each application for legacy credential files, such as `http://127.0.0.1:8989` for Sonarr. */
  readonly legacyOrigins: Readonly<Record<MediaService, URL>>
  /** Root folder used by legacy connections when adding a title without naming one. */
  readonly legacyRootFolders: Readonly<Record<LibraryService, Option.Option<string>>>
}

/** Server settings resolved at startup. */
export class Service extends Context.Service<Service, Interface>()("homelab-mcp/ServerConfig") {}

const origin = (name: string, fallback: string) =>
  Config.URL(name).pipe(Config.withDefault(new URL(fallback)))

const rootFolder = (name: string) => Config.option(Config.NonEmptyString(name))

// systemd's StateDirectory= sets STATE_DIRECTORY, colon-separated when several are configured.
const systemdStateDirectory = Config.NonEmptyString("STATE_DIRECTORY").pipe(
  Config.map((value) => value.split(":")[0] ?? value),
)

const ServerConfig = Config.all({
  host: Config.String("HOMELAB_MCP_HOST").pipe(Config.withDefault("127.0.0.1")),
  port: Config.Port("HOMELAB_MCP_PORT").pipe(Config.withDefault(19200)),
  // systemd sets CREDENTIALS_DIRECTORY for LoadCredential=; the explicit name wins for local runs.
  credentialsDirectory: Config.NonEmptyString("HOMELAB_MCP_CREDENTIALS_DIRECTORY").pipe(
    Config.orElse(() => Config.NonEmptyString("CREDENTIALS_DIRECTORY")),
  ),
  dataDirectory: Config.option(
    Config.NonEmptyString("HOMELAB_MCP_DATA_DIRECTORY").pipe(Config.orElse(() => systemdStateDirectory)),
  ),
  secretKeyFile: Config.option(Config.NonEmptyString("HOMELAB_MCP_SECRET_KEY_FILE")),
  legacyOrigins: Config.all({
    seerr: origin("SEERR_URL", "http://127.0.0.1:5055"),
    sonarr: origin("SONARR_URL", "http://127.0.0.1:8989"),
    radarr: origin("RADARR_URL", "http://127.0.0.1:7878"),
    lidarr: origin("LIDARR_URL", "http://127.0.0.1:8686"),
    prowlarr: origin("PROWLARR_URL", "http://127.0.0.1:9696"),
    plex: origin("PLEX_URL", "http://127.0.0.1:32400"),
    lastfm: origin("LASTFM_URL", "https://ws.audioscrobbler.com"),
  }),
  legacyRootFolders: Config.all({
    sonarr: rootFolder("SONARR_ROOT_FOLDER"),
    radarr: rootFolder("RADARR_ROOT_FOLDER"),
    lidarr: rootFolder("LIDARR_ROOT_FOLDER"),
  }),
})

/** Reads server settings from the active `ConfigProvider`, normally the process environment. */
export const layer: Layer.Layer<Service, Config.ConfigError> = Layer.effect(
  Service,
  Effect.gen(function* () {
    return Service.of(yield* ServerConfig)
  }),
)
