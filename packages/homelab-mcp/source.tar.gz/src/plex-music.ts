import { createHash } from "node:crypto"
import { Effect, Schema } from "effect"
import { MediaRequestInvalid } from "./errors.ts"
import type * as MediaApi from "./media-api.ts"

/** Numeric Plex metadata or library key. Playlist entry IDs are separate fields. */
export const PlexKey = Schema.String.check(Schema.isPattern(/^\d+$/))

/** A library track, with artist and album preserved for recording disambiguation. */
export const MusicTrack = Schema.Struct({
  ratingKey: PlexKey,
  title: Schema.String,
  artist: Schema.String,
  album: Schema.String,
  durationMs: Schema.Finite,
  playCount: Schema.Int,
  lastPlayedAt: Schema.optionalKey(Schema.Int),
  addedAt: Schema.optionalKey(Schema.Int),
})

/** One occurrence of a track in a playlist; mutations use playlistItemId. */
export const PlaylistTrack = Schema.Struct({ ...MusicTrack.fields, playlistItemId: Schema.NullOr(PlexKey) })

/** Playlist metadata in the currently authenticated Plex user's account. */
export const MusicPlaylist = Schema.Struct({
  ratingKey: PlexKey,
  title: Schema.String,
  smart: Schema.Boolean,
  trackCount: Schema.Int,
})

/** A complete ordered playlist read, with a fingerprint for optimistic concurrency. */
export const PlaylistState = Schema.Struct({
  playlist: MusicPlaylist,
  tracks: Schema.Array(PlaylistTrack),
  snapshot: Schema.String,
})

const Optional = <S extends Schema.Top>(schema: S) => Schema.optionalKey(Schema.NullOr(schema))
const UpstreamTrack = Schema.Struct({
  ratingKey: PlexKey,
  type: Schema.Literal("track"),
  title: Schema.String,
  grandparentTitle: Optional(Schema.String),
  parentTitle: Optional(Schema.String),
  duration: Optional(Schema.Finite),
  viewCount: Optional(Schema.Int),
  lastViewedAt: Optional(Schema.Int),
  addedAt: Optional(Schema.Int),
  playlistItemID: Optional(Schema.Union([PlexKey, Schema.Int])),
})
const UpstreamPlaylist = Schema.Struct({
  ratingKey: PlexKey,
  title: Schema.String,
  playlistType: Schema.Literal("audio"),
  smart: Schema.Union([Schema.Boolean, Schema.Literals([0, 1])]),
  leafCount: Schema.Int,
})
const Container = <S extends Schema.Top>(schema: S) => Schema.Struct({
  MediaContainer: Schema.Struct({
    Metadata: Optional(Schema.Array(schema)),
    totalSize: Optional(Schema.Int),
    size: Optional(Schema.Int),
  }),
})
const TrackContainer = Container(UpstreamTrack)
const PlaylistContainer = Container(UpstreamPlaylist)
const Identity = Schema.Struct({ MediaContainer: Schema.Struct({ machineIdentifier: Schema.NonEmptyString }) })

const toTrack = (track: typeof UpstreamTrack.Type): typeof MusicTrack.Type => ({
  ratingKey: track.ratingKey,
  title: track.title,
  artist: track.grandparentTitle ?? "",
  album: track.parentTitle ?? "",
  durationMs: track.duration ?? 0,
  playCount: track.viewCount ?? 0,
  ...(track.lastViewedAt == null ? {} : { lastPlayedAt: track.lastViewedAt }),
  ...(track.addedAt == null ? {} : { addedAt: track.addedAt }),
})
const toPlaylist = (playlist: typeof UpstreamPlaylist.Type): typeof MusicPlaylist.Type => ({
  ratingKey: playlist.ratingKey, title: playlist.title, smart: playlist.smart === true || playlist.smart === 1, trackCount: playlist.leafCount,
})

/** Read one page of audio playlists, without hiding additional pages. */
export const listPlaylists = Effect.fn("PlexMusic.listPlaylists")(function* (api: MediaApi.Interface, offset: number, limit: number) {
  const { MediaContainer: data } = yield* api.requestAs("plex", {
    method: "GET", path: "/playlists",
    query: { playlistType: "audio", "X-Plex-Container-Start": offset, "X-Plex-Container-Size": limit },
  }, PlaylistContainer)
  const playlists = (data.Metadata ?? []).map(toPlaylist)
  return { playlists, offset, total: data.totalSize ?? null, hasMore: data.totalSize == null ? playlists.length >= limit : offset + playlists.length < data.totalSize }
})

/** Search or browse tracks in one library. The returned hasMore flags truncated searches. */
export const searchTracks = Effect.fn("PlexMusic.searchTracks")(function* (
  api: MediaApi.Interface,
  input: { readonly sectionKey: string; readonly title?: string; readonly sort?: string; readonly offset: number; readonly limit: number },
) {
  const { MediaContainer: data } = yield* api.requestAs("plex", {
    method: "GET", path: `/library/sections/${input.sectionKey}/all`,
    query: { type: 10, "X-Plex-Container-Start": input.offset, "X-Plex-Container-Size": input.limit,
      ...(input.title === undefined ? {} : { title: input.title }), ...(input.sort === undefined ? {} : { sort: input.sort }) },
  }, TrackContainer)
  const tracks = (data.Metadata ?? []).map(toTrack)
  return { tracks, offset: input.offset, total: data.totalSize ?? null, hasMore: data.totalSize == null ? tracks.length >= input.limit : input.offset + tracks.length < data.totalSize }
})

/** Read all entries, refusing oversized, inconsistent or repeated pages instead of losing tracks on refresh. */
export const readPlaylist = Effect.fn("PlexMusic.readPlaylist")(function* (api: MediaApi.Interface, playlistKey: string) {
  const { MediaContainer: metadata } = yield* api.requestAs("plex", { method: "GET", path: `/playlists/${playlistKey}` }, PlaylistContainer)
  const playlist = metadata.Metadata?.[0]
  if (playlist === undefined || playlist.ratingKey !== playlistKey) return yield* new MediaRequestInvalid({ reason: "Plex audio playlist not found in the connected account" })
  if (playlist.leafCount > 10_000) return yield* new MediaRequestInvalid({ reason: "Plex playlist exceeds the 10000-track read limit" })
  const tracks: Array<typeof PlaylistTrack.Type> = []
  const ids = new Set<string>()
  for (let offset = 0; offset < 10_000; offset += 200) {
    const { MediaContainer: page } = yield* api.requestAs("plex", {
      method: "GET", path: `/playlists/${playlistKey}/items`,
      query: { "X-Plex-Container-Start": offset, "X-Plex-Container-Size": 200 },
    }, TrackContainer)
    const items = page.Metadata ?? []
    for (const item of items) {
      const smart = playlist.smart === true || playlist.smart === 1
      const playlistItemId = item.playlistItemID == null ? null : String(item.playlistItemID)
      if ((!smart && playlistItemId === null) || (playlistItemId !== null && !/^\d+$/.test(playlistItemId))) return yield* new MediaRequestInvalid({ reason: "Plex playlist entry has no valid playlistItemID" })
      if (playlistItemId !== null) {
        if (ids.has(playlistItemId)) return yield* new MediaRequestInvalid({ reason: "Plex playlist paging repeated an entry; read it again before editing" })
        ids.add(playlistItemId)
      }
      tracks.push({ ...toTrack(item), playlistItemId })
    }
    if (page.totalSize != null && page.totalSize !== playlist.leafCount) return yield* new MediaRequestInvalid({ reason: "Plex playlist changed while being read; read it again" })
    if (tracks.length >= playlist.leafCount || items.length === 0) break
    if (items.length !== 200) return yield* new MediaRequestInvalid({ reason: "Plex returned an incomplete playlist page; refusing a partial refresh" })
  }
  if (tracks.length !== playlist.leafCount) return yield* new MediaRequestInvalid({ reason: "Plex playlist count changed or its contents are incomplete; read it again" })
  const normalized = toPlaylist(playlist)
  const snapshot = createHash("sha256").update(JSON.stringify([normalized, tracks.map((track) => [track.playlistItemId, track.ratingKey])])).digest("hex")
  return { playlist: normalized, tracks, snapshot }
})

/** Resolve and validate explicit track keys before performing any playlist mutation. */
export const resolveTracks = Effect.fn("PlexMusic.resolveTracks")(function* (api: MediaApi.Interface, keys: ReadonlyArray<string>) {
  const found = new Map<string, typeof MusicTrack.Type>()
  for (let index = 0; index < keys.length; index += 50) {
    const batch = keys.slice(index, index + 50)
    const { MediaContainer: data } = yield* api.requestAs("plex", { method: "GET", path: `/library/metadata/${batch.join(",")}` }, TrackContainer)
    for (const track of data.Metadata ?? []) found.set(track.ratingKey, toTrack(track))
  }
  const tracks: Array<typeof MusicTrack.Type> = []
  for (const key of keys) {
    const track = found.get(key)
    if (track === undefined) return yield* new MediaRequestInvalid({ reason: `Plex music track ${key} could not be resolved; no playlist changes made` })
    tracks.push(track)
  }
  return tracks
})

/** Build the server-local track URI Plex uses for creation and additions. */
export const trackUri = Effect.fn("PlexMusic.trackUri")(function* (api: MediaApi.Interface, keys: ReadonlyArray<string>) {
  const identity = yield* api.requestAs("plex", { method: "GET", path: "/identity" }, Identity)
  return `server://${identity.MediaContainer.machineIdentifier}/com.plexapp.plugins.library/library/metadata/${keys.join(",")}`
})

/** A multi-request playlist edit failed; its writes must not be blindly replayed. */
export class PlaylistRefreshFailed extends Schema.TaggedError<PlaylistRefreshFailed>()("PlaylistRefreshFailed", {
  playlistKey: PlexKey,
  reason: Schema.String,
}) {
  override get message(): string {
    return `Plex playlist refresh incomplete for ${this.playlistKey}: ${this.reason}. Some changes may have applied. Read the playlist and preview again; do not replay this request.`
  }
}

/** Apply an exact unique ordered selection, adding before removing and checking the final result. Not atomic upstream. */
export const applyPlaylistTracks = Effect.fn("PlexMusic.applyPlaylistTracks")(function* (
  api: MediaApi.Interface, current: typeof PlaylistState.Type, desiredKeys: ReadonlyArray<string>,
) {
  const playlistKey = current.playlist.ratingKey
  if (current.playlist.smart || current.tracks.some((track) => track.playlistItemId === null)) return yield* new MediaRequestInvalid({ reason: "Only regular playlists with entry IDs can be refreshed" })
  return yield* Effect.gen(function* () {
    const existingKeys = new Set(current.tracks.map((track) => track.ratingKey))
    const added = desiredKeys.filter((key) => !existingKeys.has(key))
    if (added.length > 0) {
      const uri = yield* trackUri(api, added)
      yield* api.request("plex", { method: "PUT", path: `/playlists/${playlistKey}/items`, query: { uri } })
    }
    const afterAdd = added.length > 0 ? yield* readPlaylist(api, playlistKey) : current
    const originalIds = new Set(current.tracks.map((track) => track.playlistItemId))
    const originalsAfterAdd = afterAdd.tracks.filter((track) => originalIds.has(track.playlistItemId))
    const membership = (tracks: ReadonlyArray<typeof PlaylistTrack.Type>) => JSON.stringify(tracks.map((track) => [track.playlistItemId, track.ratingKey]))
    if (afterAdd.playlist.smart || afterAdd.playlist.title !== current.playlist.title ||
      afterAdd.tracks.length !== current.tracks.length + added.length || membership(originalsAfterAdd) !== membership(current.tracks)) {
      return yield* new MediaRequestInvalid({ reason: "Plex playlist changed during additions; stopping before removals" })
    }
    const retained: Array<typeof PlaylistTrack.Type> = []
    for (const key of desiredKeys) {
      const track = afterAdd.tracks.find((track) => track.ratingKey === key)
      if (track === undefined) return yield* new MediaRequestInvalid({ reason: "Plex did not add every requested track; existing entries have not been removed" })
      retained.push(track)
    }
    const retainedIds = new Set(retained.map((track) => track.playlistItemId))
    for (const track of afterAdd.tracks) {
      if (!retainedIds.has(track.playlistItemId)) yield* api.request("plex", { method: "DELETE", path: `/playlists/${playlistKey}/items/${track.playlistItemId}` })
    }
    const order = afterAdd.tracks.filter((track) => retainedIds.has(track.playlistItemId)).map((track) => track.playlistItemId)
    for (let index = 0; index < retained.length; index++) {
      const track = retained[index]
      if (track === undefined || order[index] === track.playlistItemId) continue
      const after = retained[index - 1]?.playlistItemId
      yield* api.request("plex", { method: "PUT", path: `/playlists/${playlistKey}/items/${track.playlistItemId}/move`, query: after == null ? {} : { after } })
      order.splice(order.indexOf(track.playlistItemId), 1)
      order.splice(index, 0, track.playlistItemId)
    }
    const result = yield* readPlaylist(api, playlistKey)
    if (JSON.stringify(result.tracks.map((track) => track.ratingKey)) !== JSON.stringify(desiredKeys)) return yield* new MediaRequestInvalid({ reason: "Plex playlist contents do not match the requested order" })
    return result
  }).pipe(Effect.mapError((error) => new PlaylistRefreshFailed({ playlistKey, reason: error.message })))
})
