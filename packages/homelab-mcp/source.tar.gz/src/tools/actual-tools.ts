import * as Actual from "@actual-app/api"
import { Effect, Option, Schema } from "effect"
import { Tool, Toolkit } from "effect/ai"
import * as ActualBudget from "../actual-budget.ts"
import { BudgetOperationFailed, BudgetRequestInvalid, BudgetToolError } from "../errors.ts"

const Confirm = Schema.Literal(true).annotate({ description: "Must be true; confirms the change to the live budget" })
const IsoDate = Schema.String.check(Schema.isPattern(/^\d{4}-\d{2}-\d{2}$/)).annotate({ description: "Date as YYYY-MM-DD" })
const Month = Schema.String.check(Schema.isPattern(/^\d{4}-\d{2}$/)).annotate({ description: "Budget month as YYYY-MM" })
const Amount = Schema.Finite.annotate({
  description: "Amount in the budget's currency units, e.g. -12.5; outflows (spending) are negative, inflows positive",
})
const Reference = (kind: string) =>
  Schema.NonEmptyString.annotate({ description: `${kind} id or exact name (case-insensitive)` })

const AccountSummary = Schema.Struct({
  id: Schema.String,
  name: Schema.String,
  balance: Schema.Finite,
  offBudget: Schema.Boolean,
  closed: Schema.Boolean,
})

const Transaction = Schema.Struct({
  id: Schema.String,
  date: Schema.String,
  account: Schema.NullOr(Schema.String),
  payee: Schema.NullOr(Schema.String),
  category: Schema.NullOr(Schema.String),
  amount: Schema.Finite,
  notes: Schema.NullOr(Schema.String),
  cleared: Schema.Boolean,
  transfer: Schema.Boolean.annotate({ description: "Whether this is one side of a transfer between accounts" }),
})

const Accounts = Tool.make("actual_accounts", {
  description: "List Actual Budget accounts with current balances. Start here to learn account names.",
  parameters: Schema.Struct({
    includeClosed: Schema.Boolean.pipe(Schema.withDecodingDefault(Effect.succeed(false))),
  }),
  success: Schema.Struct({ accounts: Schema.Array(AccountSummary) }),
  failure: BudgetToolError,
})
  .annotate(Tool.Title, "Budget accounts")
  .annotate(Tool.Readonly, true)
  .annotate(Tool.Destructive, false)
  .annotate(Tool.Idempotent, true)

const Categories = Tool.make("actual_categories", {
  description: "List budget category groups and their categories.",
  parameters: Schema.Struct({
    includeHidden: Schema.Boolean.pipe(Schema.withDecodingDefault(Effect.succeed(false))),
  }),
  success: Schema.Struct({
    groups: Schema.Array(
      Schema.Struct({
        id: Schema.String,
        name: Schema.String,
        income: Schema.Boolean,
        categories: Schema.Array(Schema.Struct({ id: Schema.String, name: Schema.String, hidden: Schema.Boolean })),
      }),
    ),
  }),
  failure: BudgetToolError,
})
  .annotate(Tool.Title, "Budget categories")
  .annotate(Tool.Readonly, true)
  .annotate(Tool.Destructive, false)
  .annotate(Tool.Idempotent, true)

const Payees = Tool.make("actual_payees", {
  description: "List payees, optionally filtered by a name fragment. Transfer payees name the account they transfer to.",
  parameters: Schema.Struct({ search: Schema.optionalKey(Schema.NonEmptyString) }),
  success: Schema.Struct({
    payees: Schema.Array(
      Schema.Struct({ id: Schema.String, name: Schema.String, transferAccount: Schema.optionalKey(Schema.String) }),
    ),
  }),
  failure: BudgetToolError,
})
  .annotate(Tool.Title, "Budget payees")
  .annotate(Tool.Readonly, true)
  .annotate(Tool.Destructive, false)
  .annotate(Tool.Idempotent, true)

const Transactions = Tool.make("actual_transactions", {
  description:
    "Find transactions between two dates, newest first, optionally limited to one account, category or payee, or to notes and payee names containing text. Split transactions appear as their individual parts.",
  parameters: Schema.Struct({
    startDate: IsoDate,
    endDate: Schema.optionalKey(IsoDate.annotate({ description: "Inclusive end date as YYYY-MM-DD; defaults to today" })),
    account: Schema.optionalKey(Reference("Account")),
    category: Schema.optionalKey(Reference("Category")),
    payee: Schema.optionalKey(Reference("Payee")),
    search: Schema.optionalKey(Schema.NonEmptyString),
    limit: Schema.Int.check(Schema.isBetween({ minimum: 1, maximum: 500 })).pipe(
      Schema.withDecodingDefault(Effect.succeed(100)),
    ),
  }),
  success: Schema.Struct({
    matched: Schema.Int.annotate({ description: "Number of matching transactions, which may exceed the returned list" }),
    total: Schema.Finite.annotate({ description: "Sum of every matching transaction" }),
    transactions: Schema.Array(Transaction),
  }),
  failure: BudgetToolError,
})
  .annotate(Tool.Title, "Budget transactions")
  .annotate(Tool.Readonly, true)
  .annotate(Tool.Destructive, false)
  .annotate(Tool.Idempotent, true)

const SpendingGroup = Schema.Literals(["category", "payee", "account", "month"])

const Spending = Tool.make("actual_spending", {
  description:
    "Total on-budget inflows and outflows between two dates, grouped by category, payee, account or month, largest outflow first. Starting balances and transfers between on-budget accounts are excluded.",
  parameters: Schema.Struct({
    startDate: IsoDate,
    endDate: Schema.optionalKey(IsoDate.annotate({ description: "Inclusive end date as YYYY-MM-DD; defaults to today" })),
    groupBy: SpendingGroup.pipe(Schema.withDecodingDefault(Effect.succeed("category" as const))),
    account: Schema.optionalKey(Reference("Account")),
  }),
  success: Schema.Struct({
    groups: Schema.Array(
      Schema.Struct({ name: Schema.String, outflow: Schema.Finite, inflow: Schema.Finite, net: Schema.Finite, count: Schema.Int }),
    ),
    outflow: Schema.Finite,
    inflow: Schema.Finite,
  }),
  failure: BudgetToolError,
})
  .annotate(Tool.Title, "Budget spending summary")
  .annotate(Tool.Readonly, true)
  .annotate(Tool.Destructive, false)
  .annotate(Tool.Idempotent, true)

const BudgetMonth = Tool.make("actual_budget_month", {
  description:
    "Show one month of the envelope budget: money left to budget, income, and each category's budgeted amount, spending and remaining balance.",
  parameters: Schema.Struct({
    month: Schema.optionalKey(Month.annotate({ description: "Budget month as YYYY-MM; defaults to the current month" })),
  }),
  success: Schema.Struct({
    month: Schema.String,
    toBudget: Schema.Finite,
    totalIncome: Schema.Finite,
    totalBudgeted: Schema.Finite,
    totalSpent: Schema.Finite,
    totalBalance: Schema.Finite,
    groups: Schema.Array(
      Schema.Struct({
        name: Schema.String,
        income: Schema.Boolean,
        categories: Schema.Array(
          Schema.Struct({
            id: Schema.String,
            name: Schema.String,
            budgeted: Schema.Finite,
            spent: Schema.Finite,
            balance: Schema.Finite,
          }),
        ),
      }),
    ),
  }),
  failure: BudgetToolError,
})
  .annotate(Tool.Title, "Budget month")
  .annotate(Tool.Readonly, true)
  .annotate(Tool.Destructive, false)
  .annotate(Tool.Idempotent, true)

const NewTransaction = Schema.Struct({
  date: IsoDate,
  amount: Amount,
  payee: Schema.optionalKey(
    Schema.NonEmptyString.annotate({ description: "Payee id or name; an unknown name creates a new payee" }),
  ),
  category: Schema.optionalKey(Reference("Category")),
  notes: Schema.optionalKey(Schema.String),
  cleared: Schema.optionalKey(Schema.Boolean),
})

const AddTransactions = Tool.make("actual_add_transactions", {
  description:
    "Add transactions to one account. Check account and category names with actual_accounts and actual_categories first, and confirm the entries with the user.",
  parameters: Schema.Struct({
    account: Reference("Account"),
    transactions: Schema.Array(NewTransaction).check(Schema.isMinLength(1), Schema.isMaxLength(100)),
    confirm: Confirm,
  }),
  success: Schema.Struct({ account: Schema.String, added: Schema.Int }),
  failure: BudgetToolError,
})
  .annotate(Tool.Title, "Add budget transactions")
  .annotate(Tool.Readonly, false)
  .annotate(Tool.Destructive, false)
  .annotate(Tool.Idempotent, false)

const UpdateTransaction = Tool.make("actual_update_transaction", {
  description: "Change fields of one transaction found with actual_transactions. Returns the transaction before and after.",
  parameters: Schema.Struct({
    id: Schema.NonEmptyString,
    changes: Schema.Struct({
      date: Schema.optionalKey(IsoDate),
      amount: Schema.optionalKey(Amount),
      payee: Schema.optionalKey(
        Schema.NonEmptyString.annotate({ description: "Payee id or name; an unknown name creates a new payee" }),
      ),
      category: Schema.optionalKey(Schema.NullOr(Reference("Category")).annotate({ description: "Category id or name, or null to clear" })),
      notes: Schema.optionalKey(Schema.NullOr(Schema.String)),
      cleared: Schema.optionalKey(Schema.Boolean),
    }),
    confirm: Confirm,
  }),
  success: Schema.Struct({ before: Transaction, after: Transaction }),
  failure: BudgetToolError,
})
  .annotate(Tool.Title, "Update budget transaction")
  .annotate(Tool.Readonly, false)
  .annotate(Tool.Destructive, true)
  .annotate(Tool.Idempotent, true)

const SetBudget = Tool.make("actual_set_budget", {
  description: "Set the amount budgeted to one category for one month, replacing the current amount.",
  parameters: Schema.Struct({
    month: Month,
    category: Reference("Category"),
    amount: Schema.Finite.annotate({ description: "Amount to budget in the budget's currency units, e.g. 250" }),
    confirm: Confirm,
  }),
  success: Schema.Struct({ month: Schema.String, category: Schema.String, previous: Schema.Finite, budgeted: Schema.Finite }),
  failure: BudgetToolError,
})
  .annotate(Tool.Title, "Set category budget")
  .annotate(Tool.Readonly, false)
  .annotate(Tool.Destructive, true)
  .annotate(Tool.Idempotent, true)

/** Actual Budget tools: accounts, categories, transactions, reports and budget amounts. */
export const toolkit = Toolkit.make(
  Accounts,
  Categories,
  Payees,
  Transactions,
  Spending,
  BudgetMonth,
  AddTransactions,
  UpdateTransaction,
  SetBudget,
)

const TransactionRow = Schema.Struct({
  id: Schema.String,
  date: Schema.String,
  amount: Schema.Finite,
  notes: Schema.NullOr(Schema.String),
  cleared: Schema.Boolean,
  transfer_id: Schema.NullOr(Schema.String),
  "account.name": Schema.NullOr(Schema.String),
  "payee.name": Schema.NullOr(Schema.String),
  "category.name": Schema.NullOr(Schema.String),
})
type TransactionRow = typeof TransactionRow.Type

const TRANSACTION_FIELDS = [
  "id",
  "date",
  "amount",
  "notes",
  "cleared",
  "transfer_id",
  "account.name",
  "payee.name",
  "category.name",
]
const decodeRows = Schema.decodeUnknownEffect(Schema.Struct({ data: Schema.Array(TransactionRow) }))

const BudgetMonthCategory = Schema.Struct({
  id: Schema.String,
  name: Schema.String,
  hidden: Schema.optionalKey(Schema.Boolean),
  budgeted: Schema.optionalKey(Schema.Finite),
  spent: Schema.optionalKey(Schema.Finite),
  received: Schema.optionalKey(Schema.Finite),
  balance: Schema.optionalKey(Schema.Finite),
})
const decodeMonthGroups = Schema.decodeUnknownEffect(
  Schema.Array(
    Schema.Struct({
      name: Schema.String,
      is_income: Schema.Boolean,
      hidden: Schema.optionalKey(Schema.Boolean),
      categories: Schema.optionalKey(Schema.Array(BudgetMonthCategory)),
    }),
  ),
)

const toAmount = (value: number): number => Actual.utils.integerToAmount(value)
const toInteger = (value: number): number => Actual.utils.amountToInteger(value)

const pad = (value: number) => String(value).padStart(2, "0")
const localToday = (now: Date) => `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}`

const toTransaction = (row: TransactionRow): typeof Transaction.Type => ({
  id: row.id,
  date: row.date,
  account: row["account.name"],
  payee: row["payee.name"],
  category: row["category.name"],
  amount: toAmount(row.amount),
  notes: row.notes,
  cleared: row.cleared,
  transfer: row.transfer_id !== null,
})

type Named = { readonly id: string; readonly name: string }

const resolve = <T extends Named>(kind: string, reference: string, items: ReadonlyArray<T>) => {
  const byId = items.find((item) => item.id === reference)
  if (byId !== undefined) return Effect.succeed(byId)
  const wanted = reference.toLocaleLowerCase()
  const matches = items.filter((item) => item.name.toLocaleLowerCase() === wanted)
  const [only, ...rest] = matches
  if (only !== undefined && rest.length === 0) return Effect.succeed(only)
  const candidates = (matches.length > 0 ? matches.map((item) => `${item.name} (${item.id})`) : items.map((item) => item.name))
    .slice(0, 30)
    .join(", ")
  return Effect.fail(
    new BudgetRequestInvalid({
      reason:
        matches.length > 0
          ? `${kind} "${reference}" is ambiguous; use one of these ids: ${candidates}`
          : `no ${kind} named "${reference}"; known: ${candidates}`,
    }),
  )
}

export const layer = toolkit.toLayer(
  Effect.gen(function* () {
    const budget = yield* ActualBudget.Service
    const { call } = ActualBudget

    const accounts = call("getAccounts", () => Actual.getAccounts())
    const categories = call("getCategories", () => Actual.getCategories())
    const payees = call("getPayees", () => Actual.getPayees())
    const today = Effect.sync(() => localToday(new Date()))

    const resolveAccount = (reference: string) =>
      Effect.flatMap(accounts, (items) => resolve("account", reference, items))
    const resolveCategory = (reference: string) =>
      Effect.flatMap(categories, (items) => resolve("category", reference, items))

    const resolvePayeeId = (reference: string) =>
      Effect.gen(function* () {
        const items = (yield* payees).filter((payee) => payee.transfer_acct == null)
        const existing = yield* resolve("payee", reference, items).pipe(Effect.option)
        if (Option.isSome(existing)) return existing.value.id
        return yield* call("createPayee", () => Actual.createPayee({ name: reference }))
      })

    const queryTransactions = (filters: ReadonlyArray<Record<string, unknown>>) =>
      Effect.gen(function* () {
        const query = filters
          .reduce((built, filter) => built.filter(filter), Actual.q("transactions"))
          .select(TRANSACTION_FIELDS)
          .orderBy([{ date: "desc" }, { sort_order: "desc" }])
        const result = yield* call("aqlQuery", () => Actual.aqlQuery(query))
        const decoded = yield* decodeRows(result).pipe(
          Effect.mapError((error) => new BudgetRequestInvalid({ reason: `unexpected query result: ${error.message}` })),
        )
        return decoded.data
      })

    const dateFilter = (startDate: string, endDate: string | undefined) =>
      Effect.map(today, (fallback) => ({ date: { $gte: startDate, $lte: endDate ?? fallback } }))

    const findTransaction = (id: string) =>
      Effect.flatMap(queryTransactions([{ id }]), ([row]) =>
        row === undefined
          ? Effect.fail(new BudgetRequestInvalid({ reason: `no transaction with id ${id}; find ids with actual_transactions` }))
          : Effect.succeed(row),
      )

    return toolkit.of({
      actual_accounts: Effect.fn("ActualTools.accounts")(function* ({ includeClosed }) {
        return yield* budget.use(
          "read",
          Effect.gen(function* () {
            const listed = (yield* accounts).filter((account) => includeClosed || !account.closed)
            const withBalances = yield* Effect.forEach(listed, (account) =>
              Effect.map(call("getAccountBalance", () => Actual.getAccountBalance(account.id)), (balance) => ({
                id: account.id,
                name: account.name,
                balance: toAmount(balance),
                offBudget: account.offbudget === true,
                closed: account.closed === true,
              })),
            )
            return { accounts: withBalances }
          }),
        )
      }),
      actual_categories: Effect.fn("ActualTools.categories")(function* ({ includeHidden }) {
        return yield* budget.use(
          "read",
          Effect.map(call("getCategoryGroups", () => Actual.getCategoryGroups()), (groups) => ({
            groups: groups
              .filter((group) => includeHidden || group.hidden !== true)
              .map((group) => ({
                id: group.id,
                name: group.name,
                income: group.is_income === true,
                categories: (group.categories ?? [])
                  .filter((category) => includeHidden || category.hidden !== true)
                  .map((category) => ({ id: category.id, name: category.name, hidden: category.hidden === true })),
              })),
          })),
        )
      }),
      actual_payees: Effect.fn("ActualTools.payees")(function* ({ search }) {
        return yield* budget.use(
          "read",
          Effect.gen(function* () {
            const [items, accountList] = yield* Effect.all([payees, accounts])
            const accountNames = new Map(accountList.map((account) => [account.id, account.name]))
            const fragment = search?.toLocaleLowerCase()
            return {
              payees: items
                .filter((payee) => fragment === undefined || payee.name.toLocaleLowerCase().includes(fragment))
                .map((payee) => {
                  const transferAccount = payee.transfer_acct == null ? undefined : accountNames.get(payee.transfer_acct)
                  return transferAccount === undefined
                    ? { id: payee.id, name: payee.name }
                    : { id: payee.id, name: payee.name, transferAccount }
                }),
            }
          }),
        )
      }),
      actual_transactions: Effect.fn("ActualTools.transactions")(function* (params) {
        return yield* budget.use(
          "read",
          Effect.gen(function* () {
            const filters: Array<Record<string, unknown>> = [yield* dateFilter(params.startDate, params.endDate)]
            if (params.account !== undefined) filters.push({ account: (yield* resolveAccount(params.account)).id })
            if (params.category !== undefined) filters.push({ category: (yield* resolveCategory(params.category)).id })
            const payeeReference = params.payee
            if (payeeReference !== undefined) {
              const payee = yield* Effect.flatMap(payees, (items) => resolve("payee", payeeReference, items))
              filters.push({ payee: payee.id })
            }
            if (params.search !== undefined) {
              const pattern = `%${params.search}%`
              filters.push({ $or: [{ notes: { $like: pattern } }, { "payee.name": { $like: pattern } }] })
            }
            const rows = yield* queryTransactions(filters)
            return {
              matched: rows.length,
              total: toAmount(rows.reduce((sum, row) => sum + row.amount, 0)),
              transactions: rows.slice(0, params.limit).map(toTransaction),
            }
          }),
        )
      }),
      actual_spending: Effect.fn("ActualTools.spending")(function* ({ startDate, endDate, groupBy, account }) {
        return yield* budget.use(
          "read",
          Effect.gen(function* () {
            const filters: Array<Record<string, unknown>> = [
              yield* dateFilter(startDate, endDate),
              { "account.offbudget": false },
              { starting_balance_flag: false },
              { $or: [{ transfer_id: null }, { category: { $ne: null } }] },
            ]
            if (account !== undefined) filters.push({ account: (yield* resolveAccount(account)).id })
            const rows = yield* queryTransactions(filters)
            const keyOf = (row: TransactionRow): string => {
              switch (groupBy) {
                case "category":
                  return row["category.name"] ?? "Uncategorized"
                case "payee":
                  return row["payee.name"] ?? "No payee"
                case "account":
                  return row["account.name"] ?? "Unknown account"
                case "month":
                  return row.date.slice(0, 7)
              }
            }
            const totals = new Map<string, { outflow: number; inflow: number; count: number }>()
            for (const row of rows) {
              const key = keyOf(row)
              const entry = totals.get(key) ?? { outflow: 0, inflow: 0, count: 0 }
              if (row.amount < 0) entry.outflow += row.amount
              else entry.inflow += row.amount
              entry.count += 1
              totals.set(key, entry)
            }
            const groups = [...totals]
              .map(([name, entry]) => ({
                name,
                outflow: toAmount(entry.outflow),
                inflow: toAmount(entry.inflow),
                net: toAmount(entry.outflow + entry.inflow),
                count: entry.count,
              }))
              .sort((left, right) => (groupBy === "month" ? left.name.localeCompare(right.name) : left.outflow - right.outflow))
            return {
              groups,
              outflow: toAmount([...totals.values()].reduce((sum, entry) => sum + entry.outflow, 0)),
              inflow: toAmount([...totals.values()].reduce((sum, entry) => sum + entry.inflow, 0)),
            }
          }),
        )
      }),
      actual_budget_month: Effect.fn("ActualTools.budgetMonth")(function* ({ month }) {
        const selected = month ?? (yield* today).slice(0, 7)
        return yield* budget.use(
          "read",
          Effect.gen(function* () {
            const summary = yield* call("getBudgetMonth", () => Actual.getBudgetMonth(selected))
            const groups = yield* decodeMonthGroups(summary.categoryGroups).pipe(
              Effect.mapError((error) => new BudgetRequestInvalid({ reason: `unexpected budget month: ${error.message}` })),
            )
            return {
              month: summary.month,
              toBudget: toAmount(summary.toBudget),
              totalIncome: toAmount(summary.totalIncome),
              totalBudgeted: toAmount(summary.totalBudgeted),
              totalSpent: toAmount(summary.totalSpent),
              totalBalance: toAmount(summary.totalBalance),
              groups: groups
                .filter((group) => group.hidden !== true)
                .map((group) => ({
                  name: group.name,
                  income: group.is_income,
                  categories: (group.categories ?? [])
                    .filter((category) => category.hidden !== true)
                    .map((category) => ({
                      id: category.id,
                      name: category.name,
                      budgeted: toAmount(category.budgeted ?? 0),
                      spent: toAmount(category.spent ?? category.received ?? 0),
                      balance: toAmount(category.balance ?? 0),
                    })),
                })),
            }
          }),
        )
      }),
      actual_add_transactions: Effect.fn("ActualTools.addTransactions")(function* ({ account, transactions }) {
        return yield* budget.use(
          "write",
          Effect.gen(function* () {
            const target = yield* resolveAccount(account)
            if (target.closed === true) {
              return yield* new BudgetRequestInvalid({ reason: `account ${target.name} is closed` })
            }
            const knownPayees = (yield* payees).filter((payee) => payee.transfer_acct == null)
            const entries = yield* Effect.forEach(transactions, (entry) =>
              Effect.gen(function* () {
                const category = entry.category === undefined ? undefined : (yield* resolveCategory(entry.category)).id
                const payeeId = knownPayees.find((payee) => payee.id === entry.payee)?.id
                return {
                  date: entry.date,
                  amount: toInteger(entry.amount),
                  ...(payeeId !== undefined ? { payee: payeeId } : entry.payee !== undefined ? { payee_name: entry.payee } : {}),
                  ...(category === undefined ? {} : { category }),
                  ...(entry.notes === undefined ? {} : { notes: entry.notes }),
                  ...(entry.cleared === undefined ? {} : { cleared: entry.cleared }),
                }
              }),
            )
            yield* call("addTransactions", () =>
              Actual.addTransactions(target.id, entries, { learnCategories: true, runTransfers: true }),
            )
            return { account: target.name, added: entries.length }
          }),
        )
      }),
      actual_update_transaction: Effect.fn("ActualTools.updateTransaction")(function* ({ id, changes }) {
        return yield* budget.use(
          "write",
          Effect.gen(function* () {
            const before = yield* findTransaction(id)
            const fields: Record<string, unknown> = {}
            if (changes.date !== undefined) fields["date"] = changes.date
            if (changes.amount !== undefined) fields["amount"] = toInteger(changes.amount)
            if (changes.notes !== undefined) fields["notes"] = changes.notes
            if (changes.cleared !== undefined) fields["cleared"] = changes.cleared
            if (changes.payee !== undefined) fields["payee"] = yield* resolvePayeeId(changes.payee)
            if (changes.category !== undefined) {
              fields["category"] = changes.category === null ? null : (yield* resolveCategory(changes.category)).id
            }
            // Actual.updateTransaction in 26.10 returns before its batch update finishes, so the
            // re-read below could see the old row. Send the same engine message and await it.
            const engine = Actual.internal
            if (engine === null) {
              return yield* new BudgetOperationFailed({ operation: "updateTransaction", detail: "the Actual engine is not running" })
            }
            yield* call("updateTransaction", () => engine.send("transactions-batch-update", { updated: [{ id, ...fields }] }))
            const after = yield* findTransaction(id)
            return { before: toTransaction(before), after: toTransaction(after) }
          }),
        )
      }),
      actual_set_budget: Effect.fn("ActualTools.setBudget")(function* ({ month, category, amount }) {
        return yield* budget.use(
          "write",
          Effect.gen(function* () {
            const target = yield* resolveCategory(category)
            if (target.is_income === true) {
              return yield* new BudgetRequestInvalid({ reason: `${target.name} is an income category and cannot be budgeted` })
            }
            const summary = yield* call("getBudgetMonth", () => Actual.getBudgetMonth(month))
            const groups = yield* decodeMonthGroups(summary.categoryGroups).pipe(
              Effect.mapError((error) => new BudgetRequestInvalid({ reason: `unexpected budget month: ${error.message}` })),
            )
            const previous = groups.flatMap((group) => group.categories ?? []).find((entry) => entry.id === target.id)?.budgeted ?? 0
            yield* call("setBudgetAmount", () => Actual.setBudgetAmount(month, target.id, toInteger(amount)))
            return { month, category: target.name, previous: toAmount(previous), budgeted: amount }
          }),
        )
      }),
    })
  }),
)
