import { Effect, Schema } from "effect"
import { Tool, Toolkit } from "effect/ai"
import type { MediaApiError } from "../errors.ts"
import { MediaToolError } from "../errors.ts"
import * as MediaApi from "../media-api.ts"
import { searchPlex } from "./plex-tools.ts"

const StageState = Schema.Literals(["ok", "pending", "missing", "problem", "unavailable"])
type StageState = typeof StageState.Type

const Stage = Schema.Struct({
  stage: Schema.Literals(["request", "library", "download", "import", "playback"]),
  state: StageState,
  summary: Schema.String,
})
type Stage = typeof Stage.Type

const MediaTrace = Tool.make("media_trace", {
  description:
    "Explain where a movie or TV show is in the pipeline: Seerr request → Radarr/Sonarr → download queue → import → Plex. Use it for 'why isn't X available yet?'. Each stage reports ok, pending, missing, problem, or unavailable (the application could not be asked).",
  parameters: Schema.Struct({
    mediaType: Schema.Literals(["movie", "tv"]),
    tmdbId: Schema.Int.annotate({ description: "TMDB id, from seerr_search" }),
  }),
  success: Schema.Struct({
    title: Schema.String,
    verdict: Schema.String,
    stages: Schema.Array(Stage),
  }),
  failure: MediaToolError,
})
  .annotate(Tool.Title, "Trace a title through the media stack")
  .annotate(Tool.Readonly, true)
  .annotate(Tool.Destructive, false)
  .annotate(Tool.Idempotent, true)

/** Cross-service diagnosis of a single title. */
export const toolkit = Toolkit.make(MediaTrace)

const Nullable = <S extends Schema.Top>(schema: S) => Schema.optionalKey(Schema.NullOr(schema))

const SeerrDetails = Schema.Struct({
  title: Nullable(Schema.String),
  name: Nullable(Schema.String),
  releaseDate: Nullable(Schema.String),
  firstAirDate: Nullable(Schema.String),
  externalIds: Nullable(Schema.Struct({ tvdbId: Nullable(Schema.Int) })),
  mediaInfo: Nullable(
    Schema.Struct({
      status: Nullable(Schema.Int),
      requests: Nullable(Schema.Array(Schema.Struct({ id: Schema.Int, status: Schema.Int }))),
    }),
  ),
})

const LibraryEntry = Schema.Struct({
  id: Schema.Int,
  title: Schema.String,
  tmdbId: Nullable(Schema.Int),
  tvdbId: Nullable(Schema.Int),
  monitored: Schema.Boolean,
  hasFile: Nullable(Schema.Boolean),
  path: Nullable(Schema.String),
  statistics: Nullable(Schema.Struct({ episodeFileCount: Nullable(Schema.Int), episodeCount: Nullable(Schema.Int) })),
})
type LibraryEntry = typeof LibraryEntry.Type

const QueuePage = Schema.Struct({
  records: Schema.Array(
    Schema.Struct({
      title: Nullable(Schema.String),
      trackedDownloadState: Nullable(Schema.String),
      trackedDownloadStatus: Nullable(Schema.String),
      size: Nullable(Schema.Finite),
      sizeleft: Nullable(Schema.Finite),
      errorMessage: Nullable(Schema.String),
      statusMessages: Nullable(Schema.Array(Schema.Struct({ messages: Nullable(Schema.Array(Schema.String)) }))),
    }),
  ),
})

const HistoryList = Schema.Array(
  Schema.Struct({ date: Schema.String, eventType: Schema.String, sourceTitle: Nullable(Schema.String) }),
)

const present = <A>(value: A | null | undefined): value is A => value !== null && value !== undefined

const REQUEST_STATUS: Readonly<Record<number, string>> = {
  1: "pending approval",
  2: "approved",
  3: "declined",
  4: "failed",
  5: "completed",
}

const MEDIA_STATUS: Readonly<Record<number, string>> = {
  1: "unknown",
  2: "pending",
  3: "processing",
  4: "partially available",
  5: "available",
  6: "deleted",
}

const unavailable = (stage: Stage["stage"]) => (error: MediaApiError) =>
  Effect.succeed<Stage>({ stage, state: "unavailable", summary: error.message })

/** Handler for the trace tool. */
export const layer = toolkit.toLayer(
  Effect.gen(function* () {
    const api = yield* MediaApi.Service

    return toolkit.of({
      media_trace: Effect.fn("TraceTools.trace")(function* ({ mediaType, tmdbId }) {
        const stages: Array<Stage> = []
        const seerr = yield* api
          .requestAs("seerr", { method: "GET", path: `/${mediaType}/${tmdbId}` }, SeerrDetails)
          .pipe(Effect.option)
        const details = seerr._tag === "Some" ? seerr.value : undefined
        const titleFromSeerr = details?.title ?? details?.name ?? undefined

        // 1. Request
        if (details === undefined) {
          stages.push({ stage: "request", state: "unavailable", summary: "Seerr could not be asked about this title" })
        } else {
          const requests = details.mediaInfo?.requests ?? []
          const latest = requests.at(-1)
          const availability = MEDIA_STATUS[details.mediaInfo?.status ?? 0] ?? "not requested"
          if (latest === undefined) {
            stages.push({ stage: "request", state: "missing", summary: `No Seerr request; Seerr reports ${availability}` })
          } else {
            const status = REQUEST_STATUS[latest.status] ?? "unknown"
            const state: StageState = latest.status === 1 ? "pending" : latest.status === 3 || latest.status === 4 ? "problem" : "ok"
            stages.push({ stage: "request", state, summary: `Request ${latest.id} is ${status}; Seerr reports ${availability}` })
          }
        }

        // 2. Library
        const service = mediaType === "movie" ? "radarr" : "sonarr"
        const tvdbId = details?.externalIds?.tvdbId
        const libraryLookup =
          mediaType === "movie"
            ? api.requestAs("radarr", { method: "GET", path: "/movie", query: { tmdbId } }, Schema.Array(LibraryEntry))
            : api
                .requestAs("sonarr", { method: "GET", path: "/series", query: present(tvdbId) ? { tvdbId } : {} }, Schema.Array(LibraryEntry))
                .pipe(
                  Effect.map((series) =>
                    series.filter((entry) => entry.tmdbId === tmdbId || (present(tvdbId) && entry.tvdbId === tvdbId)),
                  ),
                )
        const entries = yield* libraryLookup.pipe(Effect.result)
        let entry: LibraryEntry | undefined
        if (entries._tag === "Failure") {
          stages.push(yield* unavailable("library")(entries.failure))
        } else {
          entry = entries.success[0]
          if (entry === undefined) {
            stages.push({ stage: "library", state: "missing", summary: `Not in ${service}` })
          } else {
            const complete =
              mediaType === "movie"
                ? entry.hasFile === true
                : present(entry.statistics?.episodeCount) &&
                  entry.statistics.episodeCount > 0 &&
                  entry.statistics.episodeFileCount === entry.statistics.episodeCount
            const files =
              mediaType === "movie"
                ? entry.hasFile === true ? "file downloaded" : "no file yet"
                : `${entry.statistics?.episodeFileCount ?? 0}/${entry.statistics?.episodeCount ?? 0} monitored episodes downloaded`
            stages.push({
              stage: "library",
              state: !entry.monitored ? "problem" : complete ? "ok" : "pending",
              summary: `${service} id ${entry.id}, ${entry.monitored ? "monitored" : "NOT monitored"}, ${files}`,
            })
          }
        }

        // 3. Download queue and 4. import history
        if (entry !== undefined) {
          const idParameter = mediaType === "movie" ? { movieIds: entry.id } : { seriesIds: entry.id }
          const queue = yield* api
            .requestAs(service, { method: "GET", path: "/queue", query: { ...idParameter, pageSize: 50 } }, QueuePage)
            .pipe(Effect.result)
          if (queue._tag === "Failure") {
            stages.push(yield* unavailable("download")(queue.failure))
          } else if (queue.success.records.length === 0) {
            stages.push({ stage: "download", state: "ok", summary: "Nothing in the download queue" })
          } else {
            const problems = queue.success.records.flatMap((record) => [
              ...(present(record.errorMessage) ? [record.errorMessage] : []),
              ...(record.statusMessages ?? []).flatMap((message) => message.messages ?? []),
            ])
            const lines = queue.success.records.slice(0, 5).map((record) => {
              const progress =
                present(record.size) && present(record.sizeleft) && record.size > 0
                  ? `${Math.round(((record.size - record.sizeleft) / record.size) * 100)}%`
                  : "?%"
              return `${record.title ?? "untitled"} (${record.trackedDownloadState ?? "unknown"}, ${progress})`
            })
            stages.push({
              stage: "download",
              state: problems.length > 0 ? "problem" : "pending",
              summary: [`${queue.success.records.length} queued: ${lines.join("; ")}`, ...problems.slice(0, 3)].join(" — "),
            })
          }

          const historyPath = mediaType === "movie" ? "/history/movie" : "/history/series"
          const historyQuery = mediaType === "movie" ? { movieId: entry.id } : { seriesId: entry.id }
          const history = yield* api
            .requestAs(service, { method: "GET", path: historyPath, query: historyQuery }, HistoryList)
            .pipe(Effect.result)
          if (history._tag === "Failure") {
            stages.push(yield* unavailable("import")(history.failure))
          } else {
            const recent = [...history.success].sort((left, right) => right.date.localeCompare(left.date)).slice(0, 5)
            const failed = recent.find((event) => /failed/i.test(event.eventType))
            const imported = recent.find((event) => /imported/i.test(event.eventType))
            stages.push({
              stage: "import",
              state: failed !== undefined && (imported === undefined || failed.date > imported.date) ? "problem" : imported ? "ok" : "pending",
              summary:
                recent.length === 0
                  ? "No grab or import history yet"
                  : recent.map((event) => `${event.date.slice(0, 16)} ${event.eventType}${present(event.sourceTitle) ? ` ${event.sourceTitle}` : ""}`).join("; "),
            })
          }
        }

        // 5. Playback
        const title = titleFromSeerr ?? entry?.title
        if (title === undefined) {
          stages.push({ stage: "playback", state: "unavailable", summary: "No title known to search Plex for" })
        } else {
          const guid = mediaType === "movie" ? `tmdb://${tmdbId}` : present(tvdbId) ? `tvdb://${tvdbId}` : `tmdb://${tmdbId}`
          const plexType = mediaType === "movie" ? "movie" : "show"
          const found = yield* searchPlex(api, title, 20).pipe(Effect.result)
          if (found._tag === "Failure") {
            stages.push(yield* unavailable("playback")(found.failure))
          } else {
            const match =
              found.success.find((item) => item.guids.includes(guid)) ??
              found.success.find((item) => item.type === plexType && item.title.toLowerCase() === title.toLowerCase())
            stages.push(
              match === undefined
                ? { stage: "playback", state: "missing", summary: `Not found in Plex (searched "${title}")` }
                : {
                    stage: "playback",
                    state: "ok",
                    summary: `In Plex library ${match.library ?? "?"} as ratingKey ${match.ratingKey}${match.addedAt ? `, added ${match.addedAt.slice(0, 10)}` : ""}`,
                  },
            )
          }
        }

        const blocking = stages.find((stage) => stage.state !== "ok")
        const verdict =
          blocking === undefined
            ? "Available: every stage is complete"
            : `${blocking.stage} stage is ${blocking.state}: ${blocking.summary}`
        return { title: title ?? `TMDB ${tmdbId}`, verdict, stages }
      }),
    })
  }),
)
