import { Effect, Option, Schema } from "effect"
import { Tool, Toolkit } from "effect/ai"
import { MediaRequestInvalid, MediaToolError } from "../errors.ts"
import * as MediaApi from "../media-api.ts"
import { LibraryService } from "../media-service.ts"
import * as Connections from "../configuration/connections.ts"

// ---------------------------------------------------------------------------
// Tool definitions
// ---------------------------------------------------------------------------

const Confirm = Schema.Literal(true).annotate({ description: "Must be true; confirms the change to the live library" })
const flag = (fallback: boolean, description: string) =>
  Schema.Boolean.pipe(Schema.withDecodingDefault(Effect.succeed(fallback))).annotate({ description })

const QualityProfileId = Schema.optionalKey(
  Schema.Int.annotate({ description: "Quality profile id; omit when only one exists. List with servarr_config_list resource=qualityprofile" }),
)
const RootFolderPath = Schema.optionalKey(
  Schema.String.annotate({ description: "Root folder; omit to use the connection's default root folder or the only one. List with servarr_config_list resource=rootfolder" }),
)

const Candidate = Schema.Struct({
  title: Schema.String,
  year: Schema.optionalKey(Schema.Int),
  ids: Schema.Record(Schema.String, Schema.Union([Schema.Int, Schema.String])),
  status: Schema.optionalKey(Schema.String),
  overview: Schema.optionalKey(Schema.String),
  libraryId: Schema.optionalKey(Schema.Int.annotate({ description: "Present when the title is already in the library" })),
})
const Candidates = Schema.Struct({ results: Schema.Array(Candidate) })

const LibraryItem = Schema.Struct({
  service: LibraryService,
  id: Schema.Int,
  title: Schema.String,
  year: Schema.optionalKey(Schema.Int),
  ids: Schema.Record(Schema.String, Schema.Union([Schema.Int, Schema.String])),
  status: Schema.optionalKey(Schema.String),
  monitored: Schema.Boolean,
  qualityProfileId: Schema.optionalKey(Schema.Int),
  rootFolderPath: Schema.optionalKey(Schema.String),
  path: Schema.optionalKey(Schema.String),
  files: Schema.optionalKey(Schema.String.annotate({ description: "Downloaded vs expected, e.g. '10/12 episodes'" })),
  sizeOnDiskGb: Schema.optionalKey(Schema.Finite),
  seasons: Schema.optionalKey(
    Schema.Array(Schema.Struct({ seasonNumber: Schema.Int, monitored: Schema.Boolean, files: Schema.optionalKey(Schema.String) })),
  ),
})

const SonarrLookup = Tool.make("sonarr_lookup", {
  description: "Search for TV series to add to Sonarr. Returns TVDB ids for sonarr_add_series and marks series already in the library.",
  parameters: Schema.Struct({ term: Schema.NonEmptyString }),
  success: Candidates,
  failure: MediaToolError,
})
  .annotate(Tool.Title, "Find TV series")
  .annotate(Tool.Readonly, true)
  .annotate(Tool.Destructive, false)
  .annotate(Tool.Idempotent, true)

const SonarrAdd = Tool.make("sonarr_add_series", {
  description: "Add a TV series to Sonarr by TVDB id and optionally search for its episodes right away.",
  parameters: Schema.Struct({
    tvdbId: Schema.Int,
    qualityProfileId: QualityProfileId,
    rootFolderPath: RootFolderPath,
    monitor: Schema.Literals([
      "all", "future", "missing", "existing", "firstSeason", "lastSeason", "latestSeason", "pilot", "recent", "none",
    ]).pipe(Schema.withDecodingDefault(Effect.succeed("all" as const))),
    seriesType: Schema.Literals(["standard", "daily", "anime"]).pipe(Schema.withDecodingDefault(Effect.succeed("standard" as const))),
    seasonFolder: flag(true, "Store episodes in season folders"),
    searchNow: flag(true, "Search for missing monitored episodes after adding"),
    confirm: Confirm,
  }),
  success: Schema.Struct({ added: LibraryItem }),
  failure: MediaToolError,
})
  .annotate(Tool.Title, "Add TV series")
  .annotate(Tool.Readonly, false)
  .annotate(Tool.Destructive, false)

const RadarrLookup = Tool.make("radarr_lookup", {
  description: "Search for movies to add to Radarr. Returns TMDB ids for radarr_add_movie and marks movies already in the library.",
  parameters: Schema.Struct({ term: Schema.NonEmptyString }),
  success: Candidates,
  failure: MediaToolError,
})
  .annotate(Tool.Title, "Find movies")
  .annotate(Tool.Readonly, true)
  .annotate(Tool.Destructive, false)
  .annotate(Tool.Idempotent, true)

const RadarrAdd = Tool.make("radarr_add_movie", {
  description: "Add a movie to Radarr by TMDB id and optionally search for it right away.",
  parameters: Schema.Struct({
    tmdbId: Schema.Int,
    qualityProfileId: QualityProfileId,
    rootFolderPath: RootFolderPath,
    minimumAvailability: Schema.Literals(["announced", "inCinemas", "released"]).pipe(
      Schema.withDecodingDefault(Effect.succeed("released" as const)),
    ),
    monitor: Schema.Literals(["movieOnly", "movieAndCollection", "none"]).pipe(
      Schema.withDecodingDefault(Effect.succeed("movieOnly" as const)),
    ),
    searchNow: flag(true, "Search for the movie after adding"),
    confirm: Confirm,
  }),
  success: Schema.Struct({ added: LibraryItem }),
  failure: MediaToolError,
})
  .annotate(Tool.Title, "Add movie")
  .annotate(Tool.Readonly, false)
  .annotate(Tool.Destructive, false)

const LidarrLookup = Tool.make("lidarr_lookup", {
  description: "Search for music artists to add to Lidarr. Returns MusicBrainz artist ids for lidarr_add_artist.",
  parameters: Schema.Struct({ term: Schema.NonEmptyString }),
  success: Candidates,
  failure: MediaToolError,
})
  .annotate(Tool.Title, "Find artists")
  .annotate(Tool.Readonly, true)
  .annotate(Tool.Destructive, false)
  .annotate(Tool.Idempotent, true)

const LidarrAdd = Tool.make("lidarr_add_artist", {
  description: "Add a music artist to Lidarr by MusicBrainz artist id and optionally search for their albums right away.",
  parameters: Schema.Struct({
    musicBrainzId: Schema.NonEmptyString,
    qualityProfileId: QualityProfileId,
    metadataProfileId: Schema.optionalKey(
      Schema.Int.annotate({ description: "Metadata profile id; omit when only one exists. List with servarr_config_list resource=metadataprofile" }),
    ),
    rootFolderPath: RootFolderPath,
    monitor: Schema.Literals(["all", "future", "missing", "existing", "latest", "first", "none"]).pipe(
      Schema.withDecodingDefault(Effect.succeed("all" as const)),
    ),
    searchNow: flag(true, "Search for missing monitored albums after adding"),
    confirm: Confirm,
  }),
  success: Schema.Struct({ added: LibraryItem }),
  failure: MediaToolError,
})
  .annotate(Tool.Title, "Add artist")
  .annotate(Tool.Readonly, false)
  .annotate(Tool.Destructive, false)

const LibraryItems = Tool.make("library_items", {
  description:
    "List the series (Sonarr), movies (Radarr) or artists (Lidarr) in a library, optionally filtered by title, or show one item with its seasons by id.",
  parameters: Schema.Struct({
    service: LibraryService,
    id: Schema.optionalKey(Schema.Int),
    search: Schema.optionalKey(Schema.String.annotate({ description: "Case-insensitive title filter" })),
    limit: Schema.Int.check(Schema.isBetween({ minimum: 1, maximum: 1000 })).pipe(Schema.withDecodingDefault(Effect.succeed(100))),
  }),
  success: Schema.Struct({ total: Schema.Int, items: Schema.Array(LibraryItem) }),
  failure: MediaToolError,
})
  .annotate(Tool.Title, "Library items")
  .annotate(Tool.Readonly, true)
  .annotate(Tool.Destructive, false)
  .annotate(Tool.Idempotent, true)

const LibraryUpdate = Tool.make("library_update", {
  description:
    "Change a library item: monitoring, quality profile, per-season monitoring (Sonarr), or other resource properties. Changing rootFolderPath moves the item's files to that root folder, e.g. from the NVMe library to the LaCie.",
  parameters: Schema.Struct({
    service: LibraryService,
    id: Schema.Int,
    monitored: Schema.optionalKey(Schema.Boolean),
    qualityProfileId: Schema.optionalKey(Schema.Int),
    rootFolderPath: Schema.optionalKey(Schema.String.annotate({ description: "New root folder; files are moved" })),
    seasons: Schema.optionalKey(
      Schema.Array(Schema.Struct({ seasonNumber: Schema.Int, monitored: Schema.Boolean })).annotate({
        description: "Sonarr only: seasons whose monitoring changes; unlisted seasons keep their setting",
      }),
    ),
    otherChanges: Schema.optionalKey(
      Schema.Record(Schema.String, Schema.Json).annotate({
        description: "Other top-level properties to set, e.g. {\"minimumAvailability\": \"released\"} or {\"seriesType\": \"anime\"}",
      }),
    ),
    confirm: Confirm,
  }),
  success: Schema.Struct({ updated: LibraryItem, movedTo: Schema.optionalKey(Schema.String) }),
  failure: MediaToolError,
})
  .annotate(Tool.Title, "Update library item")
  .annotate(Tool.Readonly, false)
  .annotate(Tool.Destructive, true)

const LibraryDelete = Tool.make("library_delete", {
  description:
    "Remove a series, movie or artist from its library. Files stay on disk unless deleteFiles is true, which cannot be undone.",
  parameters: Schema.Struct({
    service: LibraryService,
    id: Schema.Int,
    deleteFiles: flag(false, "Also delete the downloaded files from disk"),
    addExclusion: flag(false, "Prevent import lists from adding this title again"),
    confirm: Confirm,
  }),
  success: Schema.Struct({ deleted: LibraryItem, filesDeleted: Schema.Boolean }),
  failure: MediaToolError,
})
  .annotate(Tool.Title, "Delete library item")
  .annotate(Tool.Readonly, false)
  .annotate(Tool.Destructive, true)

/** Library management for Sonarr, Radarr and Lidarr. */
export const toolkit = Toolkit.make(
  SonarrLookup,
  SonarrAdd,
  RadarrLookup,
  RadarrAdd,
  LidarrLookup,
  LidarrAdd,
  LibraryItems,
  LibraryUpdate,
  LibraryDelete,
)

// ---------------------------------------------------------------------------
// Response representations
// ---------------------------------------------------------------------------

const Nullable = <S extends Schema.Top>(schema: S) => Schema.optionalKey(Schema.NullOr(schema))

const Statistics = Schema.Struct({
  episodeFileCount: Nullable(Schema.Int),
  episodeCount: Nullable(Schema.Int),
  trackFileCount: Nullable(Schema.Int),
  trackCount: Nullable(Schema.Int),
  sizeOnDisk: Nullable(Schema.Finite),
})

/** The fields this server reads from Sonarr series, Radarr movies and Lidarr artists. */
const LibraryResource = Schema.Struct({
  id: Nullable(Schema.Int),
  title: Nullable(Schema.String),
  artistName: Nullable(Schema.String),
  year: Nullable(Schema.Int),
  tvdbId: Nullable(Schema.Int),
  tmdbId: Nullable(Schema.Int),
  imdbId: Nullable(Schema.String),
  foreignArtistId: Nullable(Schema.String),
  status: Nullable(Schema.String),
  overview: Nullable(Schema.String),
  monitored: Nullable(Schema.Boolean),
  hasFile: Nullable(Schema.Boolean),
  qualityProfileId: Nullable(Schema.Int),
  rootFolderPath: Nullable(Schema.String),
  path: Nullable(Schema.String),
  sizeOnDisk: Nullable(Schema.Finite),
  statistics: Nullable(Statistics),
  seasons: Nullable(
    Schema.Array(
      Schema.Struct({
        seasonNumber: Schema.Int,
        monitored: Schema.Boolean,
        statistics: Nullable(Statistics),
      }),
    ),
  ),
})
type LibraryResource = typeof LibraryResource.Type

const JsonObject = Schema.Record(Schema.String, Schema.Json)
const decodeResource = Schema.decodeUnknownEffect(LibraryResource)
const ResourceList = Schema.Array(JsonObject)
const Profiles = Schema.Array(Schema.Struct({ id: Schema.Int, name: Schema.String }))
const RootFolders = Schema.Array(Schema.Struct({ path: Schema.String }))

const RESOURCE_PATH: Readonly<Record<LibraryService, string>> = { sonarr: "series", radarr: "movie", lidarr: "artist" }
const EDITOR_IDS: Readonly<Record<LibraryService, string>> = { sonarr: "seriesIds", radarr: "movieIds", lidarr: "artistIds" }

const present = <A>(value: A | null | undefined): value is A => value !== null && value !== undefined

const idsOf = (resource: LibraryResource): Record<string, number | string> => {
  const ids: Record<string, number | string> = {}
  if (present(resource.tvdbId) && resource.tvdbId > 0) ids["tvdb"] = resource.tvdbId
  if (present(resource.tmdbId) && resource.tmdbId > 0) ids["tmdb"] = resource.tmdbId
  if (present(resource.imdbId) && resource.imdbId !== "") ids["imdb"] = resource.imdbId
  if (present(resource.foreignArtistId)) ids["musicBrainz"] = resource.foreignArtistId
  return ids
}

const fileCount = (statistics: typeof Statistics.Type | null | undefined, unit: string): string | undefined => {
  if (!present(statistics)) return undefined
  const have = statistics.episodeFileCount ?? statistics.trackFileCount
  const total = statistics.episodeCount ?? statistics.trackCount
  return present(have) && present(total) ? `${have}/${total} ${unit}` : undefined
}

const gigabytes = (bytes: number | null | undefined) =>
  present(bytes) ? Math.round((bytes / 1_000_000_000) * 100) / 100 : undefined

const summarize = (service: LibraryService, resource: LibraryResource, options: { readonly withSeasons: boolean }): typeof LibraryItem.Type | undefined => {
  if (!present(resource.id)) return undefined
  const unit = service === "lidarr" ? "tracks" : "episodes"
  const files =
    service === "radarr" ? (present(resource.hasFile) ? (resource.hasFile ? "downloaded" : "missing") : undefined) : fileCount(resource.statistics, unit)
  const size = gigabytes(resource.sizeOnDisk ?? resource.statistics?.sizeOnDisk)
  const seasons = options.withSeasons && present(resource.seasons)
    ? resource.seasons.map((season) => {
        const seasonFiles = fileCount(season.statistics, "episodes")
        return { seasonNumber: season.seasonNumber, monitored: season.monitored, ...(seasonFiles === undefined ? {} : { files: seasonFiles }) }
      })
    : undefined
  return {
    service,
    id: resource.id,
    title: resource.title ?? resource.artistName ?? "untitled",
    ids: idsOf(resource),
    monitored: resource.monitored ?? false,
    ...(present(resource.year) && resource.year > 0 ? { year: resource.year } : {}),
    ...(present(resource.status) ? { status: resource.status } : {}),
    ...(present(resource.qualityProfileId) ? { qualityProfileId: resource.qualityProfileId } : {}),
    ...(present(resource.rootFolderPath) ? { rootFolderPath: resource.rootFolderPath } : {}),
    ...(present(resource.path) ? { path: resource.path } : {}),
    ...(files === undefined ? {} : { files }),
    ...(size === undefined ? {} : { sizeOnDiskGb: size }),
    ...(seasons === undefined ? {} : { seasons }),
  }
}

const toCandidate = (resource: LibraryResource): typeof Candidate.Type => ({
  title: resource.title ?? resource.artistName ?? "untitled",
  ids: idsOf(resource),
  ...(present(resource.year) && resource.year > 0 ? { year: resource.year } : {}),
  ...(present(resource.status) ? { status: resource.status } : {}),
  ...(present(resource.overview) ? { overview: resource.overview.slice(0, 280) } : {}),
  ...(present(resource.id) && resource.id > 0 ? { libraryId: resource.id } : {}),
})

// ---------------------------------------------------------------------------
// Handlers
// ---------------------------------------------------------------------------

/** Handlers for the library tools. */
export const layer = toolkit.toLayer(
  Effect.gen(function* () {
    const api = yield* MediaApi.Service
    const connections = yield* Connections.Service

    const invalidResponse = (service: LibraryService, path: string) => (error: Schema.SchemaError) =>
      new MediaRequestInvalid({ reason: `${service} returned an unexpected ${path} resource: ${error.message.slice(0, 300)}` })

    const decodeFrom = (service: LibraryService, path: string) => (raw: Schema.Json) =>
      decodeResource(raw).pipe(Effect.mapError(invalidResponse(service, path)))

    const lookup = Effect.fn("LibraryTools.lookup")(function* (service: LibraryService, term: string) {
      const raw = yield* api.requestAs(service, { method: "GET", path: `/${RESOURCE_PATH[service]}/lookup`, query: { term } }, ResourceList)
      const resources = yield* Effect.forEach(raw.slice(0, 20), decodeFrom(service, "lookup"))
      return { results: resources.map(toCandidate) }
    })

    /** Resolve an optional profile id against the application's profiles. */
    const chooseProfile = Effect.fn("LibraryTools.chooseProfile")(function* (
      service: LibraryService,
      resource: "qualityprofile" | "metadataprofile",
      requested: number | undefined,
    ) {
      const profiles = yield* api.requestAs(service, { method: "GET", path: `/${resource}` }, Profiles)
      const listing = profiles.map((profile) => `${profile.id}: ${profile.name}`).join(", ")
      if (requested !== undefined) {
        if (profiles.some((profile) => profile.id === requested)) return requested
        return yield* new MediaRequestInvalid({ reason: `${service} has no ${resource} ${requested}; choose one of ${listing}` })
      }
      const [only, ...rest] = profiles
      if (only !== undefined && rest.length === 0) return only.id
      return yield* new MediaRequestInvalid({ reason: `choose a ${resource} id for ${service}: ${listing}` })
    })

    /** Resolve an optional root folder: requested, then the connection's default, then the only one. */
    const chooseRootFolder = Effect.fn("LibraryTools.chooseRootFolder")(function* (service: LibraryService, requested: string | undefined) {
      const folders = yield* api.requestAs(service, { method: "GET", path: "/rootfolder" }, RootFolders)
      const paths = folders.map((folder) => folder.path)
      const candidate = requested ?? (yield* connections.resolve(service)).defaults.rootFolder
      if (candidate !== undefined) {
        if (paths.includes(candidate)) return candidate
        return yield* new MediaRequestInvalid({ reason: `${service} has no root folder ${candidate}; choose one of ${paths.join(", ")}` })
      }
      const [only, ...rest] = paths
      if (only !== undefined && rest.length === 0) return only
      return yield* new MediaRequestInvalid({ reason: `choose a root folder for ${service}: ${paths.join(", ")}` })
    })

    /** Fetch the lookup resource for a known external id and reject titles already in the library. */
    const lookupForAdd = Effect.fn("LibraryTools.lookupForAdd")(function* (service: LibraryService, term: string, label: string) {
      const raw = yield* api.requestAs(service, { method: "GET", path: `/${RESOURCE_PATH[service]}/lookup`, query: { term } }, ResourceList)
      const [first] = raw
      if (first === undefined) return yield* new MediaRequestInvalid({ reason: `${service} found nothing for ${label}` })
      const resource = yield* decodeFrom(service, "lookup")(first)
      if (present(resource.id) && resource.id > 0) {
        return yield* new MediaRequestInvalid({ reason: `${label} is already in ${service} as id ${resource.id}` })
      }
      return first
    })

    const addResource = Effect.fn("LibraryTools.add")(function* (service: LibraryService, body: Schema.JsonObject) {
      const created = yield* api.request(service, { method: "POST", path: `/${RESOURCE_PATH[service]}`, body })
      const resource = yield* decodeFrom(service, RESOURCE_PATH[service])(created)
      const added = summarize(service, resource, { withSeasons: false })
      if (added === undefined) return yield* new MediaRequestInvalid({ reason: `${service} did not return the created item's id` })
      return { added }
    })

    const fetchOne = Effect.fn("LibraryTools.fetchOne")(function* (service: LibraryService, id: number) {
      const path = `/${RESOURCE_PATH[service]}/${id}`
      const raw = yield* api.requestAs(service, { method: "GET", path }, JsonObject)
      const resource = yield* decodeFrom(service, RESOURCE_PATH[service])(raw)
      const item = summarize(service, resource, { withSeasons: true })
      if (item === undefined) return yield* new MediaRequestInvalid({ reason: `${service} item ${id} has no id` })
      return { raw, item }
    })

    return toolkit.of({
      sonarr_lookup: ({ term }) => lookup("sonarr", term),
      radarr_lookup: ({ term }) => lookup("radarr", term),
      lidarr_lookup: ({ term }) => lookup("lidarr", term),

      sonarr_add_series: Effect.fn("LibraryTools.addSeries")(function* (input) {
        const series = yield* lookupForAdd("sonarr", `tvdb:${input.tvdbId}`, `TVDB ${input.tvdbId}`)
        const qualityProfileId = yield* chooseProfile("sonarr", "qualityprofile", input.qualityProfileId)
        const rootFolderPath = yield* chooseRootFolder("sonarr", input.rootFolderPath)
        return yield* addResource("sonarr", {
          ...series,
          qualityProfileId,
          rootFolderPath,
          monitored: input.monitor !== "none",
          seasonFolder: input.seasonFolder,
          seriesType: input.seriesType,
          addOptions: { monitor: input.monitor, searchForMissingEpisodes: input.searchNow, searchForCutoffUnmetEpisodes: false },
        })
      }),

      radarr_add_movie: Effect.fn("LibraryTools.addMovie")(function* (input) {
        const movie = yield* lookupForAdd("radarr", `tmdb:${input.tmdbId}`, `TMDB ${input.tmdbId}`)
        const qualityProfileId = yield* chooseProfile("radarr", "qualityprofile", input.qualityProfileId)
        const rootFolderPath = yield* chooseRootFolder("radarr", input.rootFolderPath)
        return yield* addResource("radarr", {
          ...movie,
          qualityProfileId,
          rootFolderPath,
          monitored: input.monitor !== "none",
          minimumAvailability: input.minimumAvailability,
          addOptions: { monitor: input.monitor, searchForMovie: input.searchNow },
        })
      }),

      lidarr_add_artist: Effect.fn("LibraryTools.addArtist")(function* (input) {
        const artist = yield* lookupForAdd("lidarr", `lidarr:${input.musicBrainzId}`, `MusicBrainz ${input.musicBrainzId}`)
        const qualityProfileId = yield* chooseProfile("lidarr", "qualityprofile", input.qualityProfileId)
        const metadataProfileId = yield* chooseProfile("lidarr", "metadataprofile", input.metadataProfileId)
        const rootFolderPath = yield* chooseRootFolder("lidarr", input.rootFolderPath)
        return yield* addResource("lidarr", {
          ...artist,
          qualityProfileId,
          metadataProfileId,
          rootFolderPath,
          monitored: input.monitor !== "none",
          addOptions: { monitor: input.monitor, searchForMissingAlbums: input.searchNow },
        })
      }),

      library_items: Effect.fn("LibraryTools.items")(function* ({ service, id, search, limit }) {
        if (id !== undefined) {
          const { item } = yield* fetchOne(service, id)
          return { total: 1, items: [item] }
        }
        const raw = yield* api.requestAs(service, { method: "GET", path: `/${RESOURCE_PATH[service]}` }, ResourceList)
        const resources = yield* Effect.forEach(raw, decodeFrom(service, RESOURCE_PATH[service]))
        const needle = search?.toLowerCase()
        const matching = resources
          .map((resource) => summarize(service, resource, { withSeasons: false }))
          .filter((item): item is typeof LibraryItem.Type => item !== undefined)
          .filter((item) => needle === undefined || item.title.toLowerCase().includes(needle))
          .sort((left, right) => left.title.localeCompare(right.title))
        return { total: matching.length, items: matching.slice(0, limit) }
      }),

      library_update: Effect.fn("LibraryTools.update")(function* (input) {
        const { service, id } = input
        const { raw, item } = yield* fetchOne(service, id)
        if (input.seasons !== undefined && service !== "sonarr") {
          return yield* new MediaRequestInvalid({ reason: "per-season monitoring is only available for Sonarr series" })
        }
        if (input.qualityProfileId !== undefined) yield* chooseProfile(service, "qualityprofile", input.qualityProfileId)

        const seasonChanges = new Map((input.seasons ?? []).map((season) => [season.seasonNumber, season.monitored]))
        const currentSeasons = raw["seasons"]
        const seasons =
          seasonChanges.size > 0 && Array.isArray(currentSeasons)
            ? currentSeasons.map((season) => {
                if (season === null || typeof season !== "object" || Array.isArray(season)) return season
                const number = season["seasonNumber"]
                const monitored = typeof number === "number" ? seasonChanges.get(number) : undefined
                return monitored === undefined ? season : { ...season, monitored }
              })
            : undefined

        const changes: Record<string, Schema.Json> = {
          ...input.otherChanges,
          ...(input.monitored === undefined ? {} : { monitored: input.monitored }),
          ...(input.qualityProfileId === undefined ? {} : { qualityProfileId: input.qualityProfileId }),
          ...(seasons === undefined ? {} : { seasons }),
        }
        const path = `/${RESOURCE_PATH[service]}/${id}`
        if (Object.keys(changes).length > 0) {
          yield* api.request(service, { method: "PUT", path, body: { ...raw, ...changes } })
        }

        let movedTo: string | undefined
        if (input.rootFolderPath !== undefined && input.rootFolderPath !== item.rootFolderPath) {
          movedTo = yield* chooseRootFolder(service, input.rootFolderPath)
          // The bulk editor derives the new path from the item's folder name and queues the move.
          yield* api.request(service, {
            method: "PUT",
            path: `/${RESOURCE_PATH[service]}/editor`,
            body: { [EDITOR_IDS[service]]: [id], rootFolderPath: movedTo, moveFiles: true },
          })
        }
        const { item: updated } = yield* fetchOne(service, id)
        return { updated, ...(movedTo === undefined ? {} : { movedTo }) }
      }),

      library_delete: Effect.fn("LibraryTools.delete")(function* ({ service, id, deleteFiles, addExclusion }) {
        const { item } = yield* fetchOne(service, id)
        const exclusionParameter = service === "radarr" ? "addImportExclusion" : "addImportListExclusion"
        yield* api.request(service, {
          method: "DELETE",
          path: `/${RESOURCE_PATH[service]}/${id}`,
          query: { deleteFiles, [exclusionParameter]: addExclusion },
        })
        return { deleted: item, filesDeleted: deleteFiles }
      }),
    })
  }),
)
