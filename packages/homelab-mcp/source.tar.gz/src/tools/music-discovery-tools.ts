import { Clock, Effect, Schema } from "effect"
import { Tool, Toolkit } from "effect/ai"
import { MediaToolError } from "../errors.ts"
import * as Lastfm from "../lastfm.ts"
import * as MediaApi from "../media-api.ts"
import * as PlexMusic from "../plex-music.ts"

const Count = (fallback: number, maximum: number) => Schema.Int.check(Schema.isBetween({ minimum: 1, maximum })).pipe(Schema.withDecodingDefault(Effect.succeed(fallback)))
const NonNegative = Schema.Int.check(Schema.isGreaterThanOrEqualTo(0))
const Tracks = Tool.make("lastfm_tracks", {
  description: "Read a public Last.fm user's top, loved or recently scrobbled tracks. Requires a configured Last.fm API key, no user session. Page with hasMore. Recent tracks may include nowPlaying entries without a completed scrobble. Timestamps are Unix seconds.",
  parameters: Schema.Struct({ username: Lastfm.Username, kind: Schema.Literals(["top", "recent", "loved"]),
    period: Lastfm.Period.pipe(Schema.withDecodingDefault(Effect.succeed("overall"))), page: Count(1, 10000), limit: Count(50, 200), from: Schema.optionalKey(NonNegative) }),
  success: Schema.Struct({ tracks: Schema.Array(Lastfm.LastfmTrack), page: Schema.Int, totalPages: Schema.NullOr(Schema.Int), hasMore: Schema.Boolean }), failure: MediaToolError,
}).annotate(Tool.Readonly, true).annotate(Tool.Destructive, false).annotate(Tool.Idempotent, true)

const Similar = Tool.make("lastfm_similar_tracks", {
  description: "Find similar tracks using Last.fm. These are metadata suggestions, not audio files or proof the tracks exist in Plex.",
  parameters: Schema.Struct({ artist: Schema.NonEmptyString, title: Schema.NonEmptyString, limit: Count(20, 100) }),
  success: Schema.Struct({ tracks: Schema.Array(Lastfm.LastfmTrack) }), failure: MediaToolError,
}).annotate(Tool.Readonly, true).annotate(Tool.Destructive, false).annotate(Tool.Idempotent, true)

const Suggestion = Schema.Struct({
  candidate: Lastfm.LastfmTrack,
  source: Schema.Literals(["favorite", "similar"]),
  status: Schema.Literals(["matched", "missing", "ambiguous", "search_incomplete"]),
  matches: Schema.Array(PlexMusic.MusicTrack),
})
const Discover = Tool.make("music_discovery", {
  description: "Preview a daily mix from Last.fm favorites and similar tracks, matched conservatively to a Plex music library. Excludes recent scrobbles and caller-supplied track keys. Seed choices rotate by UTC day unless rotation is supplied. Reports unavailable and ambiguous recordings separately, plus history/search coverage. Makes no playlist edits, downloads or schedules. Pass matched ratingKeys to plex_playlist_create or preview plex_playlist_refresh. Save prior selections externally in excludeRatingKeys to avoid repeating unplayed suggestions.",
  parameters: Schema.Struct({ username: Lastfm.Username, sectionKey: PlexMusic.PlexKey,
    limit: Count(30, 50), seedCount: Count(3, 5), excludeRecentDays: Count(7, 90),
    rotation: Schema.optionalKey(NonNegative),
    excludeRatingKeys: Schema.Array(PlexMusic.PlexKey).check(Schema.isMaxLength(2000)).pipe(Schema.withDecodingDefault(Effect.succeed([]))) }),
  success: Schema.Struct({ username: Schema.String, rotation: Schema.Int, seeds: Schema.Array(Lastfm.LastfmTrack),
    tracks: Schema.Array(PlexMusic.MusicTrack), suggestions: Schema.Array(Suggestion),
    recentHistoryComplete: Schema.Boolean, recentFrom: Schema.Int, warnings: Schema.Array(Schema.String) }), failure: MediaToolError,
}).annotate(Tool.Readonly, true).annotate(Tool.Destructive, false).annotate(Tool.Idempotent, true)

/** Public Last.fm reads and a bounded, read-only Plex discovery preview. */
export const toolkit = Toolkit.make(Tracks, Similar, Discover)

const rotate = <A>(items: ReadonlyArray<A>, offset: number): ReadonlyArray<A> => {
  const start = items.length === 0 ? 0 : offset % items.length
  return [...items.slice(start), ...items.slice(0, start)]
}

/** Discovery selects exact artist/title matches only; it never acquires or edits music. */
export const layer = toolkit.toLayer(Effect.gen(function* () {
  const api = yield* MediaApi.Service
  return toolkit.of({
    lastfm_tracks: (input) => Lastfm.userTracks(api, input),
    lastfm_similar_tracks: Effect.fn("MusicDiscoveryTools.similar")(function* ({ artist, title, limit }) {
      return { tracks: yield* Lastfm.similarTracks(api, artist, title, limit) }
    }),
    music_discovery: Effect.fn("MusicDiscoveryTools.discover")(function* (input) {
      const now = yield* Clock.currentTimeMillis
      const rotation = input.rotation ?? Math.floor(now / 86_400_000)
      const recentFrom = Math.floor(now / 1000) - input.excludeRecentDays * 86_400
      const top = yield* Lastfm.userTracks(api, { username: input.username, kind: "top", period: "overall", page: 1, limit: 50 })
      const loved = yield* Lastfm.userTracks(api, { username: input.username, kind: "loved", period: "overall", page: 1, limit: 50 })
      const recent = new Set<string>()
      let recentHistoryComplete = false
      for (let page = 1; page <= 5; page++) {
        const history = yield* Lastfm.userTracks(api, { username: input.username, kind: "recent", period: "overall", page, limit: 200, from: recentFrom })
        // Also avoid the currently playing track, although it is not yet a scrobble.
        for (const track of history.tracks) recent.add(Lastfm.trackIdentity(track))
        if (!history.hasMore) { recentHistoryComplete = true; break }
      }
      const favorites = Array.from(new Map([...loved.tracks, ...top.tracks].map((track) => [Lastfm.trackIdentity(track), track])).values())
      const rotated = rotate(favorites, rotation)
      const seeds = rotated.slice(0, input.seedCount)
      const similar: Array<typeof Lastfm.LastfmTrack.Type> = []
      for (const seed of seeds) similar.push(...yield* Lastfm.similarTracks(api, seed.artist, seed.title, 20))
      const discoveryPool = rotate(similar, rotation)
      const candidates: Array<{ candidate: typeof Lastfm.LastfmTrack.Type; source: "favorite" | "similar" }> = []
      // Two discovery candidates per favorite. Availability can change the final ratio.
      for (let index = 0; index < Math.max(rotated.length, Math.ceil(discoveryPool.length / 2)); index++) {
        for (const candidate of discoveryPool.slice(index * 2, index * 2 + 2)) candidates.push({ candidate, source: "similar" })
        const candidate = rotated[index]
        if (candidate !== undefined) candidates.push({ candidate, source: "favorite" })
      }
      const tracks: Array<typeof PlexMusic.MusicTrack.Type> = []
      const suggestions: Array<typeof Suggestion.Type> = []
      const seen = new Set<string>()
      const excluded = new Set(input.excludeRatingKeys)
      let searched = 0
      for (const entry of candidates) {
        const identity = Lastfm.trackIdentity(entry.candidate)
        if (seen.has(identity) || recent.has(identity)) continue
        seen.add(identity)
        if (tracks.length >= input.limit || searched >= 60) break
        searched++
        const found = yield* PlexMusic.searchTracks(api, { sectionKey: input.sectionKey, title: entry.candidate.title, offset: 0, limit: 100 })
        const matches = found.tracks.filter((track) => Lastfm.trackIdentity(track) === identity)
        const status = found.hasMore ? "search_incomplete" : matches.length === 0 ? "missing" : matches.length === 1 ? "matched" : "ambiguous"
        suggestions.push({ ...entry, status, matches })
        const track = matches[0]
        if (status === "matched" && track !== undefined && !excluded.has(track.ratingKey) &&
          (track.lastPlayedAt === undefined || track.lastPlayedAt < recentFrom)) {
          excluded.add(track.ratingKey)
          tracks.push(track)
        }
      }
      const warnings: Array<string> = []
      if (!recentHistoryComplete) warnings.push("Recent scrobbles exceed the 1000-entry read budget; recent-play exclusion is incomplete.")
      if (top.hasMore || loved.hasMore) warnings.push("Seeds use the first 50 top and first 50 loved tracks, not the whole profile.")
      if (tracks.length < input.limit) warnings.push(`Found ${tracks.length} unambiguous, eligible Plex tracks within the candidate budget; requested ${input.limit}. Do not replace a longer playlist without reviewing this shortfall.`)
      if (searched >= 60) warnings.push("Stopped after 60 Plex searches; more candidates may be available.")
      if (seeds.length === 0) warnings.push("No top or loved tracks were returned; choose a seed with lastfm_similar_tracks or browse plex_music_search.")
      return { username: input.username, rotation, seeds, tracks, suggestions, recentHistoryComplete, recentFrom, warnings }
    }),
  })
}))
