import { Effect, Result, Schema } from "effect"
import { Tool, Toolkit } from "effect/ai"
import { MediaRequestInvalid, MediaToolError } from "../errors.ts"
import { diffJson, mergeChanges } from "../json-changes.ts"
import * as MediaApi from "../media-api.ts"
import { LibraryService, ServarrService } from "../media-service.ts"
import { redactSecrets } from "../redaction.ts"

// ---------------------------------------------------------------------------
// Configuration resources
// ---------------------------------------------------------------------------

/** Collection resources: listed, fetched by id, created, updated and deleted. */
const COLLECTIONS = {
  sonarr: [
    "qualityprofile", "qualitydefinition", "customformat", "rootfolder", "downloadclient", "indexer", "notification",
    "tag", "delayprofile", "releaseprofile", "importlist", "remotepathmapping", "autotagging",
  ],
  radarr: [
    "qualityprofile", "qualitydefinition", "customformat", "rootfolder", "downloadclient", "indexer", "notification",
    "tag", "delayprofile", "releaseprofile", "importlist", "remotepathmapping", "autotagging",
  ],
  lidarr: [
    "qualityprofile", "qualitydefinition", "metadataprofile", "customformat", "rootfolder", "downloadclient", "indexer",
    "notification", "tag", "delayprofile", "releaseprofile", "importlist", "remotepathmapping",
  ],
  prowlarr: ["indexer", "applications", "appprofile", "downloadclient", "notification", "tag", "indexerproxy"],
} as const satisfies Record<ServarrService, ReadonlyArray<string>>

/** Singleton settings pages, fetched and updated without an id. */
const SETTINGS = {
  sonarr: ["config/host", "config/ui", "config/naming", "config/mediamanagement", "config/indexer", "config/downloadclient"],
  radarr: ["config/host", "config/ui", "config/naming", "config/mediamanagement", "config/indexer", "config/downloadclient"],
  lidarr: [
    "config/host", "config/ui", "config/naming", "config/mediamanagement", "config/indexer", "config/downloadclient",
    "config/metadataprovider",
  ],
  prowlarr: ["config/host", "config/ui", "config/development"],
} as const satisfies Record<ServarrService, ReadonlyArray<string>>

/** Provider resources with `/schema` templates and `/test` endpoints. */
const PROVIDERS = ["downloadclient", "indexer", "notification", "importlist", "applications", "indexerproxy"] as const

const ConfigResource = Schema.Literals([
  ...new Set([...Object.values(COLLECTIONS).flat(), ...Object.values(SETTINGS).flat()]),
]).annotate({
  description:
    "Collection (qualityprofile, customformat, rootfolder, downloadclient, indexer, notification, tag, delayprofile, releaseprofile, importlist, remotepathmapping, qualitydefinition, autotagging, metadataprofile [Lidarr], applications/appprofile/indexerproxy [Prowlarr]) or settings page (config/host, config/ui, config/naming, config/mediamanagement, config/indexer, config/downloadclient, config/metadataprovider [Lidarr], config/development [Prowlarr])",
})
type ConfigResource = typeof ConfigResource.Type

const ProviderResource = Schema.Literals(PROVIDERS)

type ResourceKind = { readonly _tag: "Collection" } | { readonly _tag: "Settings" }

const resourceKind = (service: ServarrService, resource: ConfigResource): Result.Result<ResourceKind, MediaRequestInvalid> => {
  const collections: ReadonlyArray<string> = COLLECTIONS[service]
  const settings: ReadonlyArray<string> = SETTINGS[service]
  if (collections.includes(resource)) return Result.succeed({ _tag: "Collection" })
  if (settings.includes(resource)) return Result.succeed({ _tag: "Settings" })
  return Result.fail(
    new MediaRequestInvalid({
      reason: `${service} has no ${resource} resource; available: ${[...collections, ...settings].join(", ")}`,
    }),
  )
}

const JsonObject = Schema.Record(Schema.String, Schema.Json)
const JsonObjectList = Schema.Array(JsonObject)
const WithId = Schema.Struct({ id: Schema.Int })

const Change = Schema.Struct({
  path: Schema.String,
  before: Schema.optionalKey(Schema.Json),
  after: Schema.optionalKey(Schema.Json),
})

const redactChanges = (before: Schema.Json, after: Schema.Json) => {
  // Keep real changes even when both secret values become the same redaction marker.
  // Redact whole documents first so provider privacy metadata is still available.
  const safeChanges = new Map(diffJson(redactSecrets(before), redactSecrets(after)).map((change) => [change.path, change]))
  return diffJson(before, after).map((change) => {
    const safe = safeChanges.get(change.path)
    const hidden = safe === undefined || safe.before === "[redacted]" || safe.after === "[redacted]"
    return {
      path: change.path,
      ...(change.before === undefined ? {} : { before: hidden || safe.before === undefined ? "[redacted]" : safe.before }),
      ...(change.after === undefined ? {} : { after: hidden || safe.after === undefined ? "[redacted]" : safe.after }),
    }
  })
}

const ConfigList = Tool.make("servarr_config_list", {
  description:
    "List a configuration collection in Sonarr, Radarr, Lidarr or Prowlarr, e.g. quality profiles, custom formats, root folders, download clients, indexers, notifications, tags. Secret values are redacted.",
  parameters: Schema.Struct({ service: ServarrService, resource: ConfigResource }),
  success: Schema.Struct({ items: Schema.Array(Schema.Json) }),
  failure: MediaToolError,
})
  .annotate(Tool.Title, "List Servarr configuration")
  .annotate(Tool.Readonly, true)
  .annotate(Tool.Destructive, false)
  .annotate(Tool.Idempotent, true)

const ConfigGet = Tool.make("servarr_config_get", {
  description:
    "Read one configuration item (by id) or one settings page (config/*, no id) from Sonarr, Radarr, Lidarr or Prowlarr. Secret values are redacted.",
  parameters: Schema.Struct({
    service: ServarrService,
    resource: ConfigResource,
    id: Schema.optionalKey(Schema.Int.annotate({ description: "Item id; omit for config/* settings pages" })),
  }),
  success: Schema.Struct({ item: Schema.Json }),
  failure: MediaToolError,
})
  .annotate(Tool.Title, "Read Servarr configuration")
  .annotate(Tool.Readonly, true)
  .annotate(Tool.Destructive, false)
  .annotate(Tool.Idempotent, true)

const ConfigSave = Tool.make("servarr_config_save", {
  description: `Create or update Servarr configuration and preview the change first.
- Update: give an id (or a config/* settings page) and only the properties to change; they merge into the current item. Update provider settings with an object keyed by field name, e.g. {"fields": {"host": "127.0.0.1", "port": 18080}}.
- Create: omit the id for a collection and pass the complete new item as changes; start from servarr_config_schema for download clients, indexers, notifications, import lists and Prowlarr applications.
With apply=false (default) nothing is written and the result lists every changed value. Show that to the user, then call again with apply=true.`,
  parameters: Schema.Struct({
    service: ServarrService,
    resource: ConfigResource,
    id: Schema.optionalKey(Schema.Int),
    changes: JsonObject.annotate({ description: "Properties to change (update) or the complete item (create)" }),
    apply: Schema.Boolean.pipe(Schema.withDecodingDefault(Effect.succeed(false))).annotate({
      description: "false previews the change; true writes it",
    }),
  }),
  success: Schema.Struct({
    outcome: Schema.Literals(["preview", "applied"]),
    operation: Schema.Literals(["create", "update"]),
    changes: Schema.Array(Change),
    warnings: Schema.Array(Schema.String),
    item: Schema.optionalKey(Schema.Json),
  }),
  failure: MediaToolError,
})
  .annotate(Tool.Title, "Save Servarr configuration")
  .annotate(Tool.Readonly, false)
  .annotate(Tool.Destructive, true)

const ConfigDelete = Tool.make("servarr_config_delete", {
  description: "Delete one configuration item, such as a download client, indexer, custom format or tag, from Sonarr, Radarr, Lidarr or Prowlarr.",
  parameters: Schema.Struct({
    service: ServarrService,
    resource: ConfigResource,
    id: Schema.Int,
    confirm: Schema.Literal(true).annotate({ description: "Must be true; confirms the deletion" }),
  }),
  success: Schema.Struct({ deleted: Schema.Json }),
  failure: MediaToolError,
})
  .annotate(Tool.Title, "Delete Servarr configuration")
  .annotate(Tool.Readonly, false)
  .annotate(Tool.Destructive, true)

const ConfigSchema = Tool.make("servarr_config_schema", {
  description:
    "List the templates for creating a download client, indexer, notification, import list, Prowlarr application or indexer proxy. Without an implementation, returns a summary of every implementation; with one, returns its full template to fill in and pass to servarr_config_save.",
  parameters: Schema.Struct({
    service: ServarrService,
    resource: ProviderResource,
    implementation: Schema.optionalKey(Schema.String.annotate({ description: "e.g. QBittorrent, Sabnzbd, Newznab, Radarr" })),
  }),
  success: Schema.Struct({ templates: Schema.Array(Schema.Json) }),
  failure: MediaToolError,
})
  .annotate(Tool.Title, "Servarr provider templates")
  .annotate(Tool.Readonly, true)
  .annotate(Tool.Destructive, false)
  .annotate(Tool.Idempotent, true)

const ConfigTest = Tool.make("servarr_config_test", {
  description:
    "Run the application's connection test for an existing download client, indexer, notification, import list or Prowlarr application. Validation failures are returned as an error message.",
  parameters: Schema.Struct({ service: ServarrService, resource: ProviderResource, id: Schema.Int }),
  success: Schema.Struct({ passed: Schema.Boolean }),
  failure: MediaToolError,
})
  .annotate(Tool.Title, "Test Servarr provider")
  .annotate(Tool.Readonly, true)
  .annotate(Tool.Destructive, false)

// ---------------------------------------------------------------------------
// Operations: queue, wanted, history, calendar, commands
// ---------------------------------------------------------------------------

const Limit = (fallback: number) =>
  Schema.Int.check(Schema.isBetween({ minimum: 1, maximum: 500 }))
    .pipe(Schema.withDecodingDefault(Effect.succeed(fallback)))
    .annotate({ description: `Maximum records to return (default ${fallback})` })

const QueueItem = Schema.Struct({
  id: Schema.Int,
  title: Schema.String,
  status: Schema.optionalKey(Schema.String),
  state: Schema.optionalKey(Schema.String),
  progressPercent: Schema.optionalKey(Schema.Finite),
  timeLeft: Schema.optionalKey(Schema.String),
  downloadClient: Schema.optionalKey(Schema.String),
  protocol: Schema.optionalKey(Schema.String),
  problems: Schema.Array(Schema.String),
  mediaId: Schema.optionalKey(Schema.Int),
})

const Queue = Tool.make("servarr_queue", {
  description:
    "Show the download queue of Sonarr, Radarr or Lidarr with progress, state and problems such as stalled torrents or failed imports.",
  parameters: Schema.Struct({ service: LibraryService, limit: Limit(50) }),
  success: Schema.Struct({ totalRecords: Schema.Int, items: Schema.Array(QueueItem) }),
  failure: MediaToolError,
})
  .annotate(Tool.Title, "Download queue")
  .annotate(Tool.Readonly, true)
  .annotate(Tool.Destructive, false)
  .annotate(Tool.Idempotent, true)

const QueueRemove = Tool.make("servarr_queue_remove", {
  description:
    "Remove an item from a Sonarr, Radarr or Lidarr download queue, optionally deleting it from the download client and blocklisting the release so another one is searched.",
  parameters: Schema.Struct({
    service: LibraryService,
    id: Schema.Int.annotate({ description: "Queue item id from servarr_queue" }),
    removeFromClient: Schema.Boolean.pipe(Schema.withDecodingDefault(Effect.succeed(true))),
    blocklist: Schema.Boolean.pipe(Schema.withDecodingDefault(Effect.succeed(false))),
    confirm: Schema.Literal(true),
  }),
  success: Schema.Struct({ removed: Schema.Int }),
  failure: MediaToolError,
})
  .annotate(Tool.Title, "Remove queue item")
  .annotate(Tool.Readonly, false)
  .annotate(Tool.Destructive, true)

const WantedItem = Schema.Struct({
  id: Schema.Int,
  title: Schema.String,
  airDate: Schema.optionalKey(Schema.String),
  monitored: Schema.optionalKey(Schema.Boolean),
  mediaId: Schema.optionalKey(Schema.Int),
})

const Wanted = Tool.make("servarr_wanted", {
  description:
    "List monitored items that are missing (not downloaded) or below their quality cutoff in Sonarr (episodes), Radarr (movies) or Lidarr (albums).",
  parameters: Schema.Struct({
    service: LibraryService,
    kind: Schema.Literals(["missing", "cutoff"]),
    limit: Limit(50),
  }),
  success: Schema.Struct({ totalRecords: Schema.Int, items: Schema.Array(WantedItem) }),
  failure: MediaToolError,
})
  .annotate(Tool.Title, "Wanted items")
  .annotate(Tool.Readonly, true)
  .annotate(Tool.Destructive, false)
  .annotate(Tool.Idempotent, true)

const HistoryItem = Schema.Struct({
  id: Schema.Int,
  date: Schema.String,
  eventType: Schema.String,
  sourceTitle: Schema.optionalKey(Schema.String),
  mediaId: Schema.optionalKey(Schema.Int),
  details: Schema.optionalKey(Schema.String),
})

const History = Tool.make("servarr_history", {
  description:
    "Show recent history events (grabbed, imported, failed, deleted, indexer queries) from Sonarr, Radarr, Lidarr or Prowlarr, newest first.",
  parameters: Schema.Struct({ service: ServarrService, limit: Limit(30) }),
  success: Schema.Struct({ items: Schema.Array(HistoryItem) }),
  failure: MediaToolError,
})
  .annotate(Tool.Title, "Servarr history")
  .annotate(Tool.Readonly, true)
  .annotate(Tool.Destructive, false)
  .annotate(Tool.Idempotent, true)

const IsoDate = Schema.String.check(Schema.isPattern(/^\d{4}-\d{2}-\d{2}$/)).annotate({ description: "YYYY-MM-DD" })

const Calendar = Tool.make("servarr_calendar", {
  description: "List upcoming or recent releases in a date range: episodes (Sonarr), movies (Radarr) or albums (Lidarr).",
  parameters: Schema.Struct({ service: LibraryService, start: IsoDate, end: IsoDate }),
  success: Schema.Struct({ items: Schema.Array(Schema.Struct({ id: Schema.Int, title: Schema.String, date: Schema.optionalKey(Schema.String), hasFile: Schema.optionalKey(Schema.Boolean), mediaId: Schema.optionalKey(Schema.Int) })) }),
  failure: MediaToolError,
})
  .annotate(Tool.Title, "Release calendar")
  .annotate(Tool.Readonly, true)
  .annotate(Tool.Destructive, false)
  .annotate(Tool.Idempotent, true)

const Command = Tool.make("servarr_command", {
  description: `Start a background command in Sonarr, Radarr, Lidarr or Prowlarr and return its id and status. Common commands:
- Sonarr: SeriesSearch {seriesId}, SeasonSearch {seriesId, seasonNumber}, EpisodeSearch {episodeIds}, MissingEpisodeSearch, RefreshSeries {seriesId?}, RescanSeries {seriesId?}, RssSync
- Radarr: MoviesSearch {movieIds}, MissingMoviesSearch, CutOffUnmetMoviesSearch, RefreshMovie {movieIds?}, RescanMovie {movieId?}, RssSync
- Lidarr: ArtistSearch {artistId}, AlbumSearch {albumIds}, MissingAlbumSearch, RefreshArtist {artistId?}, RssSync
- Prowlarr: ApplicationIndexerSync
Check progress with media_api_get path /command/{id}.`,
  parameters: Schema.Struct({
    service: ServarrService,
    name: Schema.NonEmptyString,
    arguments: Schema.optionalKey(JsonObject.annotate({ description: "Command body properties, e.g. {\"seriesId\": 12}" })),
  }),
  success: Schema.Struct({ id: Schema.Int, name: Schema.String, status: Schema.String }),
  failure: MediaToolError,
})
  .annotate(Tool.Title, "Run Servarr command")
  .annotate(Tool.Readonly, false)
  .annotate(Tool.Destructive, false)

/** Configuration and operations shared by Sonarr, Radarr, Lidarr and Prowlarr. */
export const toolkit = Toolkit.make(
  ConfigList,
  ConfigGet,
  ConfigSave,
  ConfigDelete,
  ConfigSchema,
  ConfigTest,
  Queue,
  QueueRemove,
  Wanted,
  History,
  Calendar,
  Command,
)

// ---------------------------------------------------------------------------
// Response representations
// ---------------------------------------------------------------------------

const OptionalString = Schema.optionalKey(Schema.NullOr(Schema.String))
const OptionalInt = Schema.optionalKey(Schema.NullOr(Schema.Int))

const QueuePage = Schema.Struct({
  totalRecords: Schema.Int,
  records: Schema.Array(
    Schema.Struct({
      id: Schema.Int,
      title: OptionalString,
      status: OptionalString,
      trackedDownloadState: OptionalString,
      trackedDownloadStatus: OptionalString,
      size: Schema.optionalKey(Schema.NullOr(Schema.Finite)),
      sizeleft: Schema.optionalKey(Schema.NullOr(Schema.Finite)),
      timeleft: OptionalString,
      downloadClient: OptionalString,
      protocol: OptionalString,
      errorMessage: OptionalString,
      statusMessages: Schema.optionalKey(
        Schema.Array(Schema.Struct({ title: OptionalString, messages: Schema.optionalKey(Schema.Array(Schema.String)) })),
      ),
      seriesId: OptionalInt,
      movieId: OptionalInt,
      artistId: OptionalInt,
    }),
  ),
})

const Titled = Schema.Struct({ title: OptionalString, artistName: OptionalString })

const WantedPage = Schema.Struct({
  totalRecords: Schema.Int,
  records: Schema.Array(
    Schema.Struct({
      id: Schema.Int,
      title: OptionalString,
      seasonNumber: OptionalInt,
      episodeNumber: OptionalInt,
      airDateUtc: OptionalString,
      releaseDate: OptionalString,
      inCinemas: OptionalString,
      monitored: Schema.optionalKey(Schema.Boolean),
      seriesId: OptionalInt,
      artistId: OptionalInt,
      series: Schema.optionalKey(Schema.NullOr(Titled)),
      artist: Schema.optionalKey(Schema.NullOr(Titled)),
    }),
  ),
})

const HistoryRecord = Schema.Struct({
  id: Schema.Int,
  date: Schema.String,
  eventType: Schema.String,
  sourceTitle: OptionalString,
  successful: Schema.optionalKey(Schema.Boolean),
  seriesId: OptionalInt,
  movieId: OptionalInt,
  artistId: OptionalInt,
  indexerId: OptionalInt,
  data: Schema.optionalKey(Schema.NullOr(Schema.Record(Schema.String, Schema.NullOr(Schema.String)))),
})
const HistoryPage = Schema.Struct({ records: Schema.Array(HistoryRecord) })

const CalendarEntries = Schema.Array(
  Schema.Struct({
    id: Schema.Int,
    title: OptionalString,
    seasonNumber: OptionalInt,
    episodeNumber: OptionalInt,
    airDateUtc: OptionalString,
    releaseDate: OptionalString,
    inCinemas: OptionalString,
    digitalRelease: OptionalString,
    hasFile: Schema.optionalKey(Schema.Boolean),
    seriesId: OptionalInt,
    artistId: OptionalInt,
    series: Schema.optionalKey(Schema.NullOr(Titled)),
    artist: Schema.optionalKey(Schema.NullOr(Titled)),
  }),
)

const CommandStatus = Schema.Struct({ id: Schema.Int, name: Schema.String, status: Schema.String })

const present = <A>(value: A | null | undefined): value is A => value !== null && value !== undefined

const episodeCode = (season: number | null | undefined, episode: number | null | undefined) =>
  present(season) && present(episode) ? ` S${String(season).padStart(2, "0")}E${String(episode).padStart(2, "0")}` : ""

const displayTitle = (record: {
  readonly title?: string | null | undefined
  readonly seasonNumber?: number | null | undefined
  readonly episodeNumber?: number | null | undefined
  readonly series?: { readonly title?: string | null | undefined } | null | undefined
  readonly artist?: { readonly artistName?: string | null | undefined } | null | undefined
}): string => {
  const parent = record.series?.title ?? record.artist?.artistName
  const own = record.title ?? "untitled"
  return present(parent) ? `${parent}${episodeCode(record.seasonNumber, record.episodeNumber)} – ${own}` : own
}

/** Drop null and undefined properties so optional result keys are omitted rather than null. */
const withoutNullish = <T extends Record<string, unknown>>(record: T) =>
  // SAFETY: the filter keeps each surviving key paired with its original value and removes only
  // null/undefined values; TypeScript cannot carry key-to-value types through Object.fromEntries.
  Object.fromEntries(Object.entries(record).filter(([, value]) => present(value))) as {
    [K in keyof T]?: Exclude<T[K], null | undefined>
  }

// Prowlarr's startup reconciliation on Kim re-adds category 8000 to the Radarr and
// Lidarr applications, so removing it through this server would be silently undone.
const nixReconciledWarnings = (service: ServarrService, resource: ConfigResource, item: Schema.JsonObject): ReadonlyArray<string> => {
  if (service !== "prowlarr" || resource !== "applications") return []
  const implementation = item["implementation"]
  const fields = item["fields"]
  if ((implementation !== "Radarr" && implementation !== "Lidarr") || !Array.isArray(fields)) return []
  const categories = fields.find(
    (field): field is Schema.JsonObject => typeof field === "object" && field !== null && !Array.isArray(field) && field["name"] === "syncCategories",
  )?.["value"]
  return Array.isArray(categories) && !categories.includes(8000)
    ? ["Kim's Nix configuration re-adds sync category 8000 to this application on every Prowlarr start"]
    : []
}

/** Handlers for the shared Servarr tools. */
export const layer = toolkit.toLayer(
  Effect.gen(function* () {
    const api = yield* MediaApi.Service

    const kindOf = (service: ServarrService, resource: ConfigResource) =>
      Result.match(resourceKind(service, resource), { onSuccess: Effect.succeed, onFailure: Effect.fail })

    const itemPath = (resource: ConfigResource, kind: ResourceKind, id: number | undefined) =>
      kind._tag === "Settings" || id === undefined ? `/${resource}` : `/${resource}/${id}`

    const saveConfig = Effect.fn("ServarrTools.configSave")(function* (input: {
      readonly service: ServarrService
      readonly resource: ConfigResource
      readonly id?: number
      readonly changes: Schema.JsonObject
      readonly apply: boolean
    }) {
      const { service, resource, id, changes, apply } = input
      const kind = yield* kindOf(service, resource)

      if (kind._tag === "Collection" && id === undefined) {
        const warnings = nixReconciledWarnings(service, resource, changes)
        const diff = redactChanges({}, changes)
        if (!apply) return { outcome: "preview" as const, operation: "create" as const, changes: diff, warnings }
        const created = yield* api.request(service, { method: "POST", path: `/${resource}`, body: changes })
        return { outcome: "applied" as const, operation: "create" as const, changes: diff, warnings, item: redactSecrets(created) }
      }

      const current = yield* api.requestAs(service, { method: "GET", path: itemPath(resource, kind, id) }, JsonObject)
      const merged = yield* Result.match(mergeChanges(current, changes), {
        onSuccess: Effect.succeed,
        onFailure: (unknownFields) =>
          Effect.fail(new MediaRequestInvalid({ reason: `unknown field names: ${unknownFields.join(", ")}` })),
      })
      const diff = redactChanges(current, merged)
      const warnings = nixReconciledWarnings(service, resource, merged)
      if (!apply || diff.length === 0) {
        return { outcome: "preview" as const, operation: "update" as const, changes: diff, warnings }
      }
      const { id: storedId } = yield* Schema.decodeUnknownEffect(WithId)(merged).pipe(
        Effect.mapError(() => new MediaRequestInvalid({ reason: `${resource} has no numeric id to update` })),
      )
      const updated = yield* api.request(service, { method: "PUT", path: `/${resource}/${storedId}`, body: merged })
      return { outcome: "applied" as const, operation: "update" as const, changes: diff, warnings, item: redactSecrets(updated) }
    })

    const TemplateSummary = Schema.Array(
      Schema.Struct({
        implementation: Schema.String,
        implementationName: OptionalString,
        protocol: OptionalString,
        infoLink: OptionalString,
      }),
    )

    return toolkit.of({
      servarr_config_list: Effect.fn("ServarrTools.configList")(function* ({ service, resource }) {
        const kind = yield* kindOf(service, resource)
        if (kind._tag === "Settings") {
          const item = yield* api.request(service, { method: "GET", path: `/${resource}` })
          return { items: [redactSecrets(item)] }
        }
        const items = yield* api.requestAs(service, { method: "GET", path: `/${resource}` }, Schema.Array(Schema.Json))
        return { items: items.map(redactSecrets) }
      }),

      servarr_config_get: Effect.fn("ServarrTools.configGet")(function* ({ service, resource, id }) {
        const kind = yield* kindOf(service, resource)
        if (kind._tag === "Collection" && id === undefined) {
          return yield* new MediaRequestInvalid({ reason: `${resource} is a collection; pass an id or use servarr_config_list` })
        }
        const item = yield* api.request(service, { method: "GET", path: itemPath(resource, kind, id) })
        return { item: redactSecrets(item) }
      }),

      servarr_config_save: saveConfig,

      servarr_config_delete: Effect.fn("ServarrTools.configDelete")(function* ({ service, resource, id }) {
        const kind = yield* kindOf(service, resource)
        if (kind._tag === "Settings") {
          return yield* new MediaRequestInvalid({ reason: `${resource} is a settings page and cannot be deleted` })
        }
        const item = yield* api.request(service, { method: "GET", path: `/${resource}/${id}` })
        yield* api.request(service, { method: "DELETE", path: `/${resource}/${id}` })
        return { deleted: redactSecrets(item) }
      }),

      servarr_config_schema: Effect.fn("ServarrTools.configSchema")(function* ({ service, resource, implementation }) {
        yield* kindOf(service, resource)
        const templates = yield* api.requestAs(service, { method: "GET", path: `/${resource}/schema` }, JsonObjectList)
        if (implementation === undefined) {
          const summary = yield* Schema.decodeUnknownEffect(TemplateSummary)(templates).pipe(
            Effect.mapError(() => new MediaRequestInvalid({ reason: `${resource} templates have no implementation names` })),
          )
          return { templates: summary.map((template) => withoutNullish(template)) }
        }
        const wanted = implementation.toLowerCase()
        const matching = templates.filter((template) => String(template["implementation"]).toLowerCase() === wanted)
        if (matching.length === 0) {
          return yield* new MediaRequestInvalid({
            reason: `${service} has no ${resource} implementation named ${implementation}; call without implementation to list them`,
          })
        }
        return { templates: matching.map(redactSecrets) }
      }),

      servarr_config_test: Effect.fn("ServarrTools.configTest")(function* ({ service, resource, id }) {
        yield* kindOf(service, resource)
        const item = yield* api.request(service, { method: "GET", path: `/${resource}/${id}` })
        yield* api.request(service, { method: "POST", path: `/${resource}/test`, body: item })
        return { passed: true }
      }),

      servarr_queue: Effect.fn("ServarrTools.queue")(function* ({ service, limit }) {
        const page = yield* api.requestAs(
          service,
          { method: "GET", path: "/queue", query: { pageSize: limit, includeUnknownSeriesItems: true } },
          QueuePage,
        )
        return {
          totalRecords: page.totalRecords,
          items: page.records.map((record) => {
            const problems = [
              ...(present(record.errorMessage) ? [record.errorMessage] : []),
              ...(record.statusMessages ?? []).flatMap((message) => message.messages ?? []),
            ]
            const progress =
              present(record.size) && present(record.sizeleft) && record.size > 0
                ? Math.round(((record.size - record.sizeleft) / record.size) * 1000) / 10
                : undefined
            return {
              id: record.id,
              title: record.title ?? "untitled",
              problems,
              ...withoutNullish({
                status: record.status,
                state: record.trackedDownloadState,
                progressPercent: progress,
                timeLeft: record.timeleft,
                downloadClient: record.downloadClient,
                protocol: record.protocol,
                mediaId: record.seriesId ?? record.movieId ?? record.artistId,
              }),
            }
          }),
        }
      }),

      servarr_queue_remove: Effect.fn("ServarrTools.queueRemove")(function* ({ service, id, removeFromClient, blocklist }) {
        yield* api.request(service, { method: "DELETE", path: `/queue/${id}`, query: { removeFromClient, blocklist } })
        return { removed: id }
      }),

      servarr_wanted: Effect.fn("ServarrTools.wanted")(function* ({ service, kind, limit }) {
        const include = service === "sonarr" ? { includeSeries: true } : service === "lidarr" ? { includeArtist: true } : {}
        const page = yield* api.requestAs(
          service,
          {
            method: "GET",
            path: `/wanted/${kind}`,
            query: { pageSize: limit, sortKey: service === "sonarr" ? "airDateUtc" : "title", sortDirection: "descending", monitored: true, ...include },
          },
          WantedPage,
        )
        return {
          totalRecords: page.totalRecords,
          items: page.records.map((record) => ({
            id: record.id,
            title: displayTitle(record),
            ...withoutNullish({
              airDate: record.airDateUtc ?? record.releaseDate ?? record.inCinemas,
              monitored: record.monitored,
              mediaId: record.seriesId ?? record.artistId,
            }),
          })),
        }
      }),

      servarr_history: Effect.fn("ServarrTools.history")(function* ({ service, limit }) {
        const page = yield* api.requestAs(
          service,
          { method: "GET", path: "/history", query: { pageSize: limit, sortKey: "date", sortDirection: "descending" } },
          HistoryPage,
        )
        return {
          items: page.records.map((record) => {
            const data = record.data ?? {}
            const detail = data["message"] ?? data["reason"] ?? data["importedPath"] ?? data["downloadClientName"] ?? data["query"]
            return {
              id: record.id,
              date: record.date,
              eventType: record.successful === false ? `${record.eventType} (failed)` : record.eventType,
              ...withoutNullish({
                sourceTitle: record.sourceTitle,
                mediaId: record.seriesId ?? record.movieId ?? record.artistId ?? record.indexerId,
                details: detail,
              }),
            }
          }),
        }
      }),

      servarr_calendar: Effect.fn("ServarrTools.calendar")(function* ({ service, start, end }) {
        const include = service === "sonarr" ? { includeSeries: true } : service === "lidarr" ? { includeArtist: true } : {}
        const entries = yield* api.requestAs(
          service,
          { method: "GET", path: "/calendar", query: { start, end, unmonitored: false, ...include } },
          CalendarEntries,
        )
        return {
          items: entries.map((entry) => ({
            id: entry.id,
            title: displayTitle(entry),
            ...withoutNullish({
              date: entry.airDateUtc ?? entry.releaseDate ?? entry.digitalRelease ?? entry.inCinemas,
              hasFile: entry.hasFile,
              mediaId: entry.seriesId ?? entry.artistId,
            }),
          })),
        }
      }),

      servarr_command: Effect.fn("ServarrTools.command")(function* ({ service, name, arguments: args }) {
        return yield* api.requestAs(
          service,
          { method: "POST", path: "/command", body: { ...args, name } },
          CommandStatus,
        )
      }),
    })
  }),
)
