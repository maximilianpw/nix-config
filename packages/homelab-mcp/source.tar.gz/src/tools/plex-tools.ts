import { Effect, Schema } from "effect"
import { Tool, Toolkit } from "effect/ai"
import { MediaRequestInvalid, MediaToolError } from "../errors.ts"
import * as MediaApi from "../media-api.ts"

// ---------------------------------------------------------------------------
// Tool definitions
// ---------------------------------------------------------------------------

const SectionKey = Schema.String.check(Schema.isPattern(/^\d+$/)).annotate({ description: "Library section key from plex_libraries" })
const RatingKey = Schema.String.check(Schema.isPattern(/^\d+$/)).annotate({ description: "Plex item ratingKey from plex_search or plex_recently_added" })
const Limit = (fallback: number) =>
  Schema.Int.check(Schema.isBetween({ minimum: 1, maximum: 100 })).pipe(Schema.withDecodingDefault(Effect.succeed(fallback)))

const PlexItem = Schema.Struct({
  ratingKey: Schema.String,
  type: Schema.String,
  title: Schema.String,
  year: Schema.optionalKey(Schema.Int),
  library: Schema.optionalKey(Schema.String),
  addedAt: Schema.optionalKey(Schema.String),
  guids: Schema.Array(Schema.String).annotate({ description: "External ids such as tmdb://603 or tvdb://81189" }),
})

const Libraries = Tool.make("plex_libraries", {
  description: "List Plex libraries with their section keys, types, folders and scan state.",
  success: Schema.Struct({
    libraries: Schema.Array(
      Schema.Struct({
        key: Schema.String,
        title: Schema.String,
        type: Schema.String,
        folders: Schema.Array(Schema.String),
        refreshing: Schema.Boolean,
        scannedAt: Schema.optionalKey(Schema.String),
      }),
    ),
  }),
  failure: MediaToolError,
})
  .annotate(Tool.Title, "Plex libraries")
  .annotate(Tool.Readonly, true)
  .annotate(Tool.Destructive, false)
  .annotate(Tool.Idempotent, true)

const ScanLibrary = Tool.make("plex_scan_library", {
  description: "Scan a Plex library for new or removed files, optionally limited to one folder inside it.",
  parameters: Schema.Struct({
    sectionKey: SectionKey,
    path: Schema.optionalKey(Schema.String.annotate({ description: "Folder to scan, e.g. /srv/media-secondary/library/tv/Severance" })),
    confirm: Schema.Literal(true),
  }),
  success: Schema.Struct({ started: Schema.Boolean }),
  failure: MediaToolError,
})
  .annotate(Tool.Title, "Scan Plex library")
  .annotate(Tool.Readonly, false)
  .annotate(Tool.Destructive, false)
  .annotate(Tool.Idempotent, true)

const Search = Tool.make("plex_search", {
  description: "Search every Plex library for movies, shows, episodes, artists or albums by title.",
  parameters: Schema.Struct({ query: Schema.NonEmptyString, limit: Limit(10) }),
  success: Schema.Struct({ items: Schema.Array(PlexItem) }),
  failure: MediaToolError,
})
  .annotate(Tool.Title, "Search Plex")
  .annotate(Tool.Readonly, true)
  .annotate(Tool.Destructive, false)
  .annotate(Tool.Idempotent, true)

const RecentlyAdded = Tool.make("plex_recently_added", {
  description: "List items recently added to Plex, across all libraries or in one library.",
  parameters: Schema.Struct({ sectionKey: Schema.optionalKey(SectionKey), limit: Limit(20) }),
  success: Schema.Struct({ items: Schema.Array(PlexItem) }),
  failure: MediaToolError,
})
  .annotate(Tool.Title, "Recently added to Plex")
  .annotate(Tool.Readonly, true)
  .annotate(Tool.Destructive, false)
  .annotate(Tool.Idempotent, true)

const Sessions = Tool.make("plex_sessions", {
  description: "Show what is playing on Plex right now: who, what, on which player, and whether it direct plays or transcodes.",
  success: Schema.Struct({
    sessions: Schema.Array(
      Schema.Struct({
        user: Schema.String,
        title: Schema.String,
        player: Schema.String,
        state: Schema.String,
        progressPercent: Schema.optionalKey(Schema.Finite),
        playback: Schema.String.annotate({ description: "direct play, or the video/audio transcode decisions" }),
        location: Schema.optionalKey(Schema.String),
        bandwidthKbps: Schema.optionalKey(Schema.Int),
      }),
    ),
  }),
  failure: MediaToolError,
})
  .annotate(Tool.Title, "Plex now playing")
  .annotate(Tool.Readonly, true)
  .annotate(Tool.Destructive, false)
  .annotate(Tool.Idempotent, true)

const Item = Tool.make("plex_item", {
  description: "Show one Plex item: external ids, watch count, episode counts, and its media files with resolution and codecs.",
  parameters: Schema.Struct({ ratingKey: RatingKey }),
  success: Schema.Struct({
    item: PlexItem,
    summary: Schema.optionalKey(Schema.String),
    viewCount: Schema.optionalKey(Schema.Int),
    episodes: Schema.optionalKey(Schema.String.annotate({ description: "Watched vs total episodes for a show or season" })),
    files: Schema.Array(
      Schema.Struct({
        file: Schema.String,
        sizeGb: Schema.optionalKey(Schema.Finite),
        resolution: Schema.optionalKey(Schema.String),
        videoCodec: Schema.optionalKey(Schema.String),
        audioCodec: Schema.optionalKey(Schema.String),
        container: Schema.optionalKey(Schema.String),
      }),
    ),
  }),
  failure: MediaToolError,
})
  .annotate(Tool.Title, "Plex item details")
  .annotate(Tool.Readonly, true)
  .annotate(Tool.Destructive, false)
  .annotate(Tool.Idempotent, true)

const RefreshItem = Tool.make("plex_refresh_item", {
  description: "Refresh one Plex item's metadata and artwork from its agents, e.g. after fixing a wrong match or a renamed file.",
  parameters: Schema.Struct({ ratingKey: RatingKey, confirm: Schema.Literal(true) }),
  success: Schema.Struct({ started: Schema.Boolean }),
  failure: MediaToolError,
})
  .annotate(Tool.Title, "Refresh Plex metadata")
  .annotate(Tool.Readonly, false)
  .annotate(Tool.Destructive, false)
  .annotate(Tool.Idempotent, true)

const EmptyTrash = Tool.make("plex_empty_trash", {
  description: "Permanently remove items whose files are gone from a Plex library, e.g. after deleting titles in Sonarr or Radarr.",
  parameters: Schema.Struct({ sectionKey: SectionKey, confirm: Schema.Literal(true) }),
  success: Schema.Struct({ started: Schema.Boolean }),
  failure: MediaToolError,
})
  .annotate(Tool.Title, "Empty Plex trash")
  .annotate(Tool.Readonly, false)
  .annotate(Tool.Destructive, true)

/** Plex library and playback tools. */
export const toolkit = Toolkit.make(Libraries, ScanLibrary, Search, RecentlyAdded, Sessions, Item, RefreshItem, EmptyTrash)

// ---------------------------------------------------------------------------
// Response representations
// ---------------------------------------------------------------------------

const Nullable = <S extends Schema.Top>(schema: S) => Schema.optionalKey(Schema.NullOr(schema))

const Guid = Schema.Struct({ id: Schema.String })

const MetadataFields = {
  ratingKey: Schema.String,
  type: Schema.String,
  title: Schema.String,
  grandparentTitle: Nullable(Schema.String),
  parentTitle: Nullable(Schema.String),
  parentIndex: Nullable(Schema.Int),
  index: Nullable(Schema.Int),
  year: Nullable(Schema.Int),
  librarySectionTitle: Nullable(Schema.String),
  addedAt: Nullable(Schema.Int),
  summary: Nullable(Schema.String),
  viewCount: Nullable(Schema.Int),
  leafCount: Nullable(Schema.Int),
  viewedLeafCount: Nullable(Schema.Int),
  Guid: Nullable(Schema.Array(Guid)),
} as const

const Metadata = Schema.Struct(MetadataFields)
type Metadata = typeof Metadata.Type

const Container = <F extends Schema.Struct.Fields>(fields: F) => Schema.Struct({ MediaContainer: Schema.Struct(fields) })

const SectionsResponse = Container({
  Directory: Nullable(
    Schema.Array(
      Schema.Struct({
        key: Schema.String,
        title: Schema.String,
        type: Schema.String,
        refreshing: Nullable(Schema.Boolean),
        scannedAt: Nullable(Schema.Int),
        Location: Nullable(Schema.Array(Schema.Struct({ path: Schema.String }))),
      }),
    ),
  ),
})

const MetadataResponse = Container({ Metadata: Nullable(Schema.Array(Metadata)) })

const HubsResponse = Container({
  Hub: Nullable(Schema.Array(Schema.Struct({ Metadata: Nullable(Schema.Array(Metadata)) }))),
})

const SessionsResponse = Container({
  Metadata: Nullable(
    Schema.Array(
      Schema.Struct({
        ...MetadataFields,
        viewOffset: Nullable(Schema.Finite),
        duration: Nullable(Schema.Finite),
        User: Nullable(Schema.Struct({ title: Nullable(Schema.String) })),
        Player: Nullable(Schema.Struct({ title: Nullable(Schema.String), product: Nullable(Schema.String), state: Nullable(Schema.String) })),
        Session: Nullable(Schema.Struct({ location: Nullable(Schema.String), bandwidth: Nullable(Schema.Int) })),
        TranscodeSession: Nullable(
          Schema.Struct({ videoDecision: Nullable(Schema.String), audioDecision: Nullable(Schema.String) }),
        ),
      }),
    ),
  ),
})

const ItemResponse = Container({
  Metadata: Nullable(
    Schema.Array(
      Schema.Struct({
        ...MetadataFields,
        Media: Nullable(
          Schema.Array(
            Schema.Struct({
              videoResolution: Nullable(Schema.String),
              videoCodec: Nullable(Schema.String),
              audioCodec: Nullable(Schema.String),
              container: Nullable(Schema.String),
              Part: Nullable(Schema.Array(Schema.Struct({ file: Nullable(Schema.String), size: Nullable(Schema.Finite) }))),
            }),
          ),
        ),
      }),
    ),
  ),
})

const present = <A>(value: A | null | undefined): value is A => value !== null && value !== undefined

const isoFromUnix = (seconds: number | null | undefined) =>
  present(seconds) ? new Date(seconds * 1000).toISOString() : undefined

const episodeCode = (metadata: Metadata) =>
  present(metadata.parentIndex) && present(metadata.index)
    ? ` S${String(metadata.parentIndex).padStart(2, "0")}E${String(metadata.index).padStart(2, "0")}`
    : ""

const displayTitle = (metadata: Metadata) =>
  metadata.type === "episode" && present(metadata.grandparentTitle)
    ? `${metadata.grandparentTitle}${episodeCode(metadata)} – ${metadata.title}`
    : metadata.type === "season" && present(metadata.parentTitle)
      ? `${metadata.parentTitle} – ${metadata.title}`
      : metadata.title

/** Summarise Plex metadata; exported for the cross-service trace tool. */
export const toPlexItem = (metadata: Metadata): typeof PlexItem.Type => {
  const addedAt = isoFromUnix(metadata.addedAt)
  return {
    ratingKey: metadata.ratingKey,
    type: metadata.type,
    title: displayTitle(metadata),
    guids: (metadata.Guid ?? []).map((guid) => guid.id),
    ...(present(metadata.year) ? { year: metadata.year } : {}),
    ...(present(metadata.librarySectionTitle) ? { library: metadata.librarySectionTitle } : {}),
    ...(addedAt === undefined ? {} : { addedAt }),
  }
}

/** Search every Plex library and return matching items with their external ids; shared with the trace tool. */
export const searchPlex = (api: MediaApi.Interface, query: string, limit: number) =>
  api
    .requestAs("plex", { method: "GET", path: "/hubs/search", query: { query, limit, includeGuids: 1 } }, HubsResponse)
    .pipe(Effect.map((response) => (response.MediaContainer.Hub ?? []).flatMap((hub) => hub.Metadata ?? []).map(toPlexItem)))

// ---------------------------------------------------------------------------
// Handlers
// ---------------------------------------------------------------------------

/** Handlers for the Plex tools. */
export const layer = toolkit.toLayer(
  Effect.gen(function* () {
    const api = yield* MediaApi.Service

    return toolkit.of({
      plex_libraries: Effect.fn("PlexTools.libraries")(function* () {
        const response = yield* api.requestAs("plex", { method: "GET", path: "/library/sections" }, SectionsResponse)
        return {
          libraries: (response.MediaContainer.Directory ?? []).map((section) => {
            const scannedAt = isoFromUnix(section.scannedAt)
            return {
              key: section.key,
              title: section.title,
              type: section.type,
              folders: (section.Location ?? []).map((location) => location.path),
              refreshing: section.refreshing ?? false,
              ...(scannedAt === undefined ? {} : { scannedAt }),
            }
          }),
        }
      }),

      plex_scan_library: Effect.fn("PlexTools.scanLibrary")(function* ({ sectionKey, path }) {
        yield* api.request("plex", {
          method: "GET",
          path: `/library/sections/${sectionKey}/refresh`,
          query: path === undefined ? undefined : { path },
          retry: false,
        })
        return { started: true }
      }),

      plex_search: Effect.fn("PlexTools.search")(function* ({ query, limit }) {
        return { items: (yield* searchPlex(api, query, limit)).slice(0, limit) }
      }),

      plex_recently_added: Effect.fn("PlexTools.recentlyAdded")(function* ({ sectionKey, limit }) {
        const path = sectionKey === undefined ? "/library/recentlyAdded" : `/library/sections/${sectionKey}/recentlyAdded`
        const response = yield* api.requestAs(
          "plex",
          { method: "GET", path, query: { "X-Plex-Container-Start": 0, "X-Plex-Container-Size": limit, includeGuids: 1 } },
          MetadataResponse,
        )
        return { items: (response.MediaContainer.Metadata ?? []).slice(0, limit).map(toPlexItem) }
      }),

      plex_sessions: Effect.fn("PlexTools.sessions")(function* () {
        const response = yield* api.requestAs("plex", { method: "GET", path: "/status/sessions" }, SessionsResponse)
        return {
          sessions: (response.MediaContainer.Metadata ?? []).map((session) => {
            const transcode = session.TranscodeSession
            const playback = present(transcode)
              ? `transcode (video ${transcode.videoDecision ?? "unknown"}, audio ${transcode.audioDecision ?? "unknown"})`
              : "direct play"
            const progress =
              present(session.viewOffset) && present(session.duration) && session.duration > 0
                ? Math.round((session.viewOffset / session.duration) * 1000) / 10
                : undefined
            return {
              user: session.User?.title ?? "unknown",
              title: displayTitle(session),
              player: session.Player?.title ?? session.Player?.product ?? "unknown",
              state: session.Player?.state ?? "unknown",
              playback,
              ...(progress === undefined ? {} : { progressPercent: progress }),
              ...(present(session.Session?.location) ? { location: session.Session.location } : {}),
              ...(present(session.Session?.bandwidth) ? { bandwidthKbps: session.Session.bandwidth } : {}),
            }
          }),
        }
      }),

      plex_item: Effect.fn("PlexTools.item")(function* ({ ratingKey }) {
        const response = yield* api.requestAs(
          "plex",
          { method: "GET", path: `/library/metadata/${ratingKey}`, query: { includeGuids: 1 } },
          ItemResponse,
        )
        const [metadata] = response.MediaContainer.Metadata ?? []
        if (metadata === undefined) return yield* new MediaRequestInvalid({ reason: `Plex has no item ${ratingKey}` })
        const files = (metadata.Media ?? []).flatMap((media) =>
          (media.Part ?? []).flatMap((part) =>
            present(part.file)
              ? [
                  {
                    file: part.file,
                    ...(present(part.size) ? { sizeGb: Math.round((part.size / 1_000_000_000) * 100) / 100 } : {}),
                    ...(present(media.videoResolution) ? { resolution: media.videoResolution } : {}),
                    ...(present(media.videoCodec) ? { videoCodec: media.videoCodec } : {}),
                    ...(present(media.audioCodec) ? { audioCodec: media.audioCodec } : {}),
                    ...(present(media.container) ? { container: media.container } : {}),
                  },
                ]
              : [],
          ),
        )
        return {
          item: toPlexItem(metadata),
          files,
          ...(present(metadata.summary) && metadata.summary !== "" ? { summary: metadata.summary.slice(0, 500) } : {}),
          ...(present(metadata.viewCount) ? { viewCount: metadata.viewCount } : {}),
          ...(present(metadata.leafCount)
            ? { episodes: `${metadata.viewedLeafCount ?? 0}/${metadata.leafCount} watched` }
            : {}),
        }
      }),

      plex_refresh_item: Effect.fn("PlexTools.refreshItem")(function* ({ ratingKey }) {
        yield* api.request("plex", { method: "PUT", path: `/library/metadata/${ratingKey}/refresh` })
        return { started: true }
      }),

      plex_empty_trash: Effect.fn("PlexTools.emptyTrash")(function* ({ sectionKey }) {
        yield* api.request("plex", { method: "PUT", path: `/library/sections/${sectionKey}/emptyTrash` })
        return { started: true }
      }),
    })
  }),
)
