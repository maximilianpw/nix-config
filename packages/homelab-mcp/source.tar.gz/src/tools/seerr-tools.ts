import { Effect, Schema } from "effect"
import { Tool, Toolkit } from "effect/ai"
import { MediaRequestInvalid, MediaToolError } from "../errors.ts"
import * as MediaApi from "../media-api.ts"

// ---------------------------------------------------------------------------
// Tool definitions
// ---------------------------------------------------------------------------

const MediaType = Schema.Literals(["movie", "tv"])
type MediaType = typeof MediaType.Type
const TmdbId = Schema.Int.annotate({ description: "TMDB id, from seerr_search" })
const RequestId = Schema.Int.annotate({ description: "Seerr request id, from seerr_requests" })

const Availability = Schema.Literals(["unknown", "pending", "processing", "partially available", "available", "deleted", "not requested"])
const RequestStatus = Schema.Literals(["pending approval", "approved", "declined", "failed", "completed", "unknown"])

const SearchResult = Schema.Struct({
  mediaType: MediaType,
  tmdbId: Schema.Int,
  title: Schema.String,
  year: Schema.optionalKey(Schema.Int),
  availability: Availability,
  overview: Schema.optionalKey(Schema.String),
})

const RequestSummary = Schema.Struct({
  id: Schema.Int,
  status: RequestStatus,
  mediaType: MediaType,
  tmdbId: Schema.Int,
  title: Schema.optionalKey(Schema.String),
  availability: Availability,
  requestedBy: Schema.optionalKey(Schema.String),
  createdAt: Schema.optionalKey(Schema.String),
  seasons: Schema.optionalKey(Schema.Array(Schema.Int)),
})

const SeerrSearch = Tool.make("seerr_search", {
  description: "Search Seerr (TMDB) for movies and TV shows, with each title's availability on Kim. Use the tmdbId for seerr_request or seerr_media.",
  parameters: Schema.Struct({
    query: Schema.NonEmptyString,
    page: Schema.Int.check(Schema.isGreaterThanOrEqualTo(1)).pipe(Schema.withDecodingDefault(Effect.succeed(1))),
  }),
  success: Schema.Struct({ page: Schema.Int, totalPages: Schema.Int, results: Schema.Array(SearchResult) }),
  failure: MediaToolError,
})
  .annotate(Tool.Title, "Search Seerr")
  .annotate(Tool.Readonly, true)
  .annotate(Tool.Destructive, false)
  .annotate(Tool.Idempotent, true)

const SeerrMedia = Tool.make("seerr_media", {
  description:
    "Show a movie or TV show in Seerr: availability, external ids (TVDB/IMDb), per-season availability, and existing requests.",
  parameters: Schema.Struct({ mediaType: MediaType, tmdbId: TmdbId }),
  success: Schema.Struct({
    mediaType: MediaType,
    tmdbId: Schema.Int,
    title: Schema.String,
    year: Schema.optionalKey(Schema.Int),
    overview: Schema.optionalKey(Schema.String),
    tvdbId: Schema.optionalKey(Schema.Int),
    imdbId: Schema.optionalKey(Schema.String),
    availability: Availability,
    seasons: Schema.optionalKey(
      Schema.Array(Schema.Struct({ seasonNumber: Schema.Int, episodeCount: Schema.optionalKey(Schema.Int), availability: Availability })),
    ),
    requests: Schema.Array(RequestSummary),
  }),
  failure: MediaToolError,
})
  .annotate(Tool.Title, "Seerr media details")
  .annotate(Tool.Readonly, true)
  .annotate(Tool.Destructive, false)
  .annotate(Tool.Idempotent, true)

const SeerrRequest = Tool.make("seerr_request", {
  description:
    "Request a movie or TV show through Seerr, which forwards approved requests to Radarr or Sonarr. Omit server, profile and root folder to use Seerr's defaults.",
  parameters: Schema.Struct({
    mediaType: MediaType,
    tmdbId: TmdbId,
    seasons: Schema.optionalKey(
      Schema.Union([Schema.Literal("all"), Schema.Array(Schema.Int)]).annotate({
        description: "TV only: season numbers to request, or \"all\" (default)",
      }),
    ),
    serverId: Schema.optionalKey(Schema.Int),
    profileId: Schema.optionalKey(Schema.Int),
    rootFolder: Schema.optionalKey(Schema.String),
    confirm: Schema.Literal(true).annotate({ description: "Must be true; confirms creating the request" }),
  }),
  success: Schema.Struct({ request: RequestSummary }),
  failure: MediaToolError,
})
  .annotate(Tool.Title, "Request media")
  .annotate(Tool.Readonly, false)
  .annotate(Tool.Destructive, false)

const SeerrRequests = Tool.make("seerr_requests", {
  description: "List Seerr requests, newest first, filtered by state and media type.",
  parameters: Schema.Struct({
    filter: Schema.Literals(["all", "pending", "approved", "processing", "available", "unavailable", "failed", "completed", "deleted"]).pipe(
      Schema.withDecodingDefault(Effect.succeed("all" as const)),
    ),
    mediaType: Schema.Literals(["all", "movie", "tv"]).pipe(Schema.withDecodingDefault(Effect.succeed("all" as const))),
    take: Schema.Int.check(Schema.isBetween({ minimum: 1, maximum: 50 })).pipe(Schema.withDecodingDefault(Effect.succeed(20))),
    skip: Schema.Int.check(Schema.isGreaterThanOrEqualTo(0)).pipe(Schema.withDecodingDefault(Effect.succeed(0))),
  }),
  success: Schema.Struct({ total: Schema.Int, requests: Schema.Array(RequestSummary) }),
  failure: MediaToolError,
})
  .annotate(Tool.Title, "Seerr requests")
  .annotate(Tool.Readonly, true)
  .annotate(Tool.Destructive, false)
  .annotate(Tool.Idempotent, true)

const SeerrDecide = Tool.make("seerr_request_decide", {
  description: "Approve (sends it to Radarr/Sonarr) or decline a pending Seerr request.",
  parameters: Schema.Struct({
    requestId: RequestId,
    decision: Schema.Literals(["approve", "decline"]),
    confirm: Schema.Literal(true),
  }),
  success: Schema.Struct({ request: RequestSummary }),
  failure: MediaToolError,
})
  .annotate(Tool.Title, "Approve or decline request")
  .annotate(Tool.Readonly, false)
  .annotate(Tool.Destructive, false)

const SeerrRetry = Tool.make("seerr_request_retry", {
  description: "Retry sending a failed Seerr request to Radarr or Sonarr.",
  parameters: Schema.Struct({ requestId: RequestId, confirm: Schema.Literal(true) }),
  success: Schema.Struct({ request: RequestSummary }),
  failure: MediaToolError,
})
  .annotate(Tool.Title, "Retry request")
  .annotate(Tool.Readonly, false)
  .annotate(Tool.Destructive, false)

const SeerrDelete = Tool.make("seerr_request_delete", {
  description: "Delete a Seerr request. The title stays in Radarr/Sonarr; remove it there with library_delete.",
  parameters: Schema.Struct({ requestId: RequestId, confirm: Schema.Literal(true) }),
  success: Schema.Struct({ deleted: Schema.Int }),
  failure: MediaToolError,
})
  .annotate(Tool.Title, "Delete request")
  .annotate(Tool.Readonly, false)
  .annotate(Tool.Destructive, true)

/** Request management through Seerr. */
export const toolkit = Toolkit.make(SeerrSearch, SeerrMedia, SeerrRequest, SeerrRequests, SeerrDecide, SeerrRetry, SeerrDelete)

// ---------------------------------------------------------------------------
// Response representations
// ---------------------------------------------------------------------------

const Nullable = <S extends Schema.Top>(schema: S) => Schema.optionalKey(Schema.NullOr(schema))

const MediaInfo = Schema.Struct({
  status: Nullable(Schema.Int),
  seasons: Nullable(Schema.Array(Schema.Struct({ seasonNumber: Schema.Int, status: Nullable(Schema.Int) }))),
})

const MediaRequest = Schema.Struct({
  id: Schema.Int,
  status: Schema.Int,
  type: Nullable(Schema.String),
  createdAt: Nullable(Schema.String),
  media: Nullable(Schema.Struct({ tmdbId: Schema.Int, mediaType: Nullable(Schema.String), status: Nullable(Schema.Int) })),
  requestedBy: Nullable(
    Schema.Struct({
      displayName: Nullable(Schema.String),
      username: Nullable(Schema.String),
      plexUsername: Nullable(Schema.String),
      jellyfinUsername: Nullable(Schema.String),
      email: Nullable(Schema.String),
    }),
  ),
  seasons: Nullable(Schema.Array(Schema.Struct({ seasonNumber: Schema.Int }))),
})
type MediaRequest = typeof MediaRequest.Type

const SearchPage = Schema.Struct({
  page: Schema.Int,
  totalPages: Schema.Int,
  results: Schema.Array(
    Schema.Struct({
      id: Schema.Int,
      mediaType: Schema.String,
      title: Nullable(Schema.String),
      name: Nullable(Schema.String),
      releaseDate: Nullable(Schema.String),
      firstAirDate: Nullable(Schema.String),
      overview: Nullable(Schema.String),
      mediaInfo: Nullable(MediaInfo),
    }),
  ),
})

const Details = Schema.Struct({
  id: Schema.Int,
  title: Nullable(Schema.String),
  name: Nullable(Schema.String),
  releaseDate: Nullable(Schema.String),
  firstAirDate: Nullable(Schema.String),
  overview: Nullable(Schema.String),
  imdbId: Nullable(Schema.String),
  externalIds: Nullable(Schema.Struct({ tvdbId: Nullable(Schema.Int), imdbId: Nullable(Schema.String) })),
  seasons: Nullable(Schema.Array(Schema.Struct({ seasonNumber: Schema.Int, episodeCount: Nullable(Schema.Int) }))),
  mediaInfo: Nullable(MediaInfo.pipe(Schema.fieldsAssign({ requests: Nullable(Schema.Array(MediaRequest)) }))),
})

const RequestPage = Schema.Struct({
  pageInfo: Schema.Struct({ results: Schema.Int }),
  results: Schema.Array(MediaRequest),
})

const present = <A>(value: A | null | undefined): value is A => value !== null && value !== undefined

const AVAILABILITY: Readonly<Record<number, typeof Availability.Type>> = {
  1: "unknown",
  2: "pending",
  3: "processing",
  4: "partially available",
  5: "available",
  6: "deleted",
}
const availabilityOf = (status: number | null | undefined): typeof Availability.Type =>
  present(status) ? (AVAILABILITY[status] ?? "unknown") : "not requested"

const REQUEST_STATUS: Readonly<Record<number, typeof RequestStatus.Type>> = {
  1: "pending approval",
  2: "approved",
  3: "declined",
  4: "failed",
  5: "completed",
}

const yearOf = (date: string | null | undefined) => {
  const year = present(date) ? Number.parseInt(date.slice(0, 4), 10) : Number.NaN
  return Number.isFinite(year) ? { year } : {}
}

const isMediaType = (value: string | null | undefined): value is MediaType => value === "movie" || value === "tv"

const summarizeRequest = (request: MediaRequest, title?: string): typeof RequestSummary.Type | undefined => {
  const mediaType = request.type ?? request.media?.mediaType
  if (!isMediaType(mediaType) || !present(request.media)) return undefined
  const user = request.requestedBy
  const requestedBy = user?.displayName ?? user?.username ?? user?.plexUsername ?? user?.jellyfinUsername ?? user?.email
  const seasons = request.seasons?.map((season) => season.seasonNumber)
  return {
    id: request.id,
    status: REQUEST_STATUS[request.status] ?? "unknown",
    mediaType,
    tmdbId: request.media.tmdbId,
    availability: availabilityOf(request.media.status),
    ...(title === undefined ? {} : { title }),
    ...(present(requestedBy) ? { requestedBy } : {}),
    ...(present(request.createdAt) ? { createdAt: request.createdAt } : {}),
    ...(seasons === undefined || seasons.length === 0 ? {} : { seasons }),
  }
}

// ---------------------------------------------------------------------------
// Handlers
// ---------------------------------------------------------------------------

/** Handlers for the Seerr tools. */
export const layer = toolkit.toLayer(
  Effect.gen(function* () {
    const api = yield* MediaApi.Service

    const details = (mediaType: MediaType, tmdbId: number) =>
      api.requestAs("seerr", { method: "GET", path: `/${mediaType}/${tmdbId}` }, Details)

    const requireSummary = (request: MediaRequest, title?: string) => {
      const summary = summarizeRequest(request, title)
      return summary === undefined
        ? Effect.fail(new MediaRequestInvalid({ reason: `Seerr request ${request.id} has no media type or media` }))
        : Effect.succeed(summary)
    }

    const titleFor = (request: MediaRequest) => {
      const mediaType = request.type ?? request.media?.mediaType
      if (!isMediaType(mediaType) || !present(request.media)) return Effect.succeed(undefined)
      return details(mediaType, request.media.tmdbId).pipe(
        Effect.map((media) => media.title ?? media.name ?? undefined),
        // A missing TMDB title should not hide the request itself.
        Effect.orElseSucceed(() => undefined),
      )
    }

    const reloadRequest = (requestId: number) =>
      api.requestAs("seerr", { method: "GET", path: `/request/${requestId}` }, MediaRequest).pipe(
        Effect.flatMap((request) => Effect.flatMap(titleFor(request), (title) => requireSummary(request, title))),
      )

    return toolkit.of({
      seerr_search: Effect.fn("SeerrTools.search")(function* ({ query, page }) {
        const result = yield* api.requestAs("seerr", { method: "GET", path: "/search", query: { query, page } }, SearchPage)
        const results = result.results.flatMap((item) => {
          if (!isMediaType(item.mediaType)) return []
          const title = item.title ?? item.name
          if (!present(title)) return []
          return [
            {
              mediaType: item.mediaType,
              tmdbId: item.id,
              title,
              availability: availabilityOf(item.mediaInfo?.status),
              ...yearOf(item.releaseDate ?? item.firstAirDate),
              ...(present(item.overview) && item.overview !== "" ? { overview: item.overview.slice(0, 280) } : {}),
            },
          ]
        })
        return { page: result.page, totalPages: result.totalPages, results }
      }),

      seerr_media: Effect.fn("SeerrTools.media")(function* ({ mediaType, tmdbId }) {
        const media = yield* details(mediaType, tmdbId)
        const title = media.title ?? media.name ?? "untitled"
        const seasonStatus = new Map((media.mediaInfo?.seasons ?? []).map((season) => [season.seasonNumber, season.status]))
        const requests = (media.mediaInfo?.requests ?? []).flatMap((request) => {
          const summary = summarizeRequest(request, title)
          return summary === undefined ? [] : [summary]
        })
        const tvdbId = media.externalIds?.tvdbId
        const imdbId = media.imdbId ?? media.externalIds?.imdbId
        return {
          mediaType,
          tmdbId,
          title,
          availability: availabilityOf(media.mediaInfo?.status),
          requests,
          ...yearOf(media.releaseDate ?? media.firstAirDate),
          ...(present(media.overview) ? { overview: media.overview.slice(0, 500) } : {}),
          ...(present(tvdbId) ? { tvdbId } : {}),
          ...(present(imdbId) ? { imdbId } : {}),
          ...(mediaType === "tv" && present(media.seasons)
            ? {
                seasons: media.seasons.map((season) => ({
                  seasonNumber: season.seasonNumber,
                  availability: availabilityOf(seasonStatus.get(season.seasonNumber)),
                  ...(present(season.episodeCount) ? { episodeCount: season.episodeCount } : {}),
                })),
              }
            : {}),
        }
      }),

      seerr_request: Effect.fn("SeerrTools.request")(function* (input) {
        if (input.mediaType === "movie" && input.seasons !== undefined) {
          return yield* new MediaRequestInvalid({ reason: "seasons apply only to TV requests" })
        }
        const created = yield* api.requestAs(
          "seerr",
          {
            method: "POST",
            path: "/request",
            body: {
              mediaType: input.mediaType,
              mediaId: input.tmdbId,
              ...(input.mediaType === "tv" ? { seasons: input.seasons ?? "all" } : {}),
              ...(input.serverId === undefined ? {} : { serverId: input.serverId }),
              ...(input.profileId === undefined ? {} : { profileId: input.profileId }),
              ...(input.rootFolder === undefined ? {} : { rootFolder: input.rootFolder }),
            },
          },
          MediaRequest,
        )
        return { request: yield* reloadRequest(created.id) }
      }),

      seerr_requests: Effect.fn("SeerrTools.requests")(function* ({ filter, mediaType, take, skip }) {
        const page = yield* api.requestAs(
          "seerr",
          { method: "GET", path: "/request", query: { filter, mediaType, take, skip, sort: "added", sortDirection: "desc" } },
          RequestPage,
        )
        const requests = yield* Effect.forEach(
          page.results,
          (request) => Effect.map(titleFor(request), (title) => summarizeRequest(request, title)),
          { concurrency: 5 },
        )
        return { total: page.pageInfo.results, requests: requests.filter(present) }
      }),

      seerr_request_decide: Effect.fn("SeerrTools.decide")(function* ({ requestId, decision }) {
        yield* api.request("seerr", { method: "POST", path: `/request/${requestId}/${decision}` })
        return { request: yield* reloadRequest(requestId) }
      }),

      seerr_request_retry: Effect.fn("SeerrTools.retry")(function* ({ requestId }) {
        yield* api.request("seerr", { method: "POST", path: `/request/${requestId}/retry` })
        return { request: yield* reloadRequest(requestId) }
      }),

      seerr_request_delete: Effect.fn("SeerrTools.delete")(function* ({ requestId }) {
        yield* api.request("seerr", { method: "DELETE", path: `/request/${requestId}` })
        return { deleted: requestId }
      }),
    })
  }),
)
