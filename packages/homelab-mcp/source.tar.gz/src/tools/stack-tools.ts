import { Effect, Schema } from "effect"
import { Tool, Toolkit } from "effect/ai"
import { MediaRequestInvalid, MediaToolError } from "../errors.ts"
import * as MediaApi from "../media-api.ts"
import { MediaService } from "../media-service.ts"
import { redactSecrets } from "../redaction.ts"

const QueryValue = Schema.Union([
  Schema.String,
  Schema.Finite,
  Schema.Boolean,
  Schema.Array(Schema.Union([Schema.String, Schema.Finite])),
])

const ApiPath = Schema.String.annotate({
  description:
    "Path relative to the application's API root, starting with '/'. Sonarr/Radarr use /api/v3, Lidarr/Prowlarr/Seerr /api/v1, so '/series/12' on Sonarr calls /api/v3/series/12. Plex paths start at the server root, e.g. '/library/sections'.",
})

const ApiResult = Schema.Struct({
  body: Schema.Json.annotate({ description: "Parsed JSON response with secret-looking values replaced by [redacted]" }),
})

const ServiceHealth = Schema.Struct({
  service: MediaService,
  reachable: Schema.Boolean,
  version: Schema.optionalKey(Schema.String),
  warnings: Schema.Array(Schema.String),
  error: Schema.optionalKey(Schema.String),
  details: Schema.optionalKey(Schema.String),
})

const MediaStackHealth = Tool.make("media_stack_health", {
  description:
    "Check every media application on Kim (Seerr, Sonarr, Radarr, Lidarr, Prowlarr, Plex): reachability, version, and each Servarr app's health warnings. Start here when something in the media stack seems wrong.",
  success: Schema.Struct({ services: Schema.Array(ServiceHealth) }),
  failure: MediaToolError,
})
  .annotate(Tool.Title, "Media stack health")
  .annotate(Tool.Readonly, true)
  .annotate(Tool.Destructive, false)
  .annotate(Tool.Idempotent, true)

const MediaApiGet = Tool.make("media_api_get", {
  description:
    "Read a media application's REST API when no dedicated tool covers it, e.g. Seerr '/settings/radarr', Plex '/:/prefs', Sonarr '/episode' with query {seriesId: 12}. Plex is limited to known read endpoints; use dedicated tools for scans and refreshes. Secret values are redacted.",
  parameters: Schema.Struct({
    service: MediaService,
    path: ApiPath,
    query: Schema.optionalKey(Schema.Record(Schema.String, QueryValue)),
  }),
  success: ApiResult,
  failure: MediaToolError,
})
  .annotate(Tool.Title, "Read media API")
  .annotate(Tool.Readonly, true)
  .annotate(Tool.Destructive, false)
  .annotate(Tool.Idempotent, true)

const MediaApiWrite = Tool.make("media_api_write", {
  description:
    "Send a POST, PUT or DELETE to any media application's REST API when no dedicated tool covers it, e.g. saving Seerr settings or Plex preferences. Read the current resource with media_api_get first and send complete bodies; Servarr PUTs replace the whole resource. Prefer servarr_config_save for Servarr settings because it previews the diff.",
  parameters: Schema.Struct({
    service: MediaService,
    method: Schema.Literals(["POST", "PUT", "DELETE"]),
    path: ApiPath,
    query: Schema.optionalKey(Schema.Record(Schema.String, QueryValue)),
    body: Schema.optionalKey(Schema.Json),
    confirm: Schema.Literal(true).annotate({ description: "Must be true; confirms the caller intends to change live state" }),
  }),
  success: ApiResult,
  failure: MediaToolError,
})
  .annotate(Tool.Title, "Write media API")
  .annotate(Tool.Readonly, false)
  .annotate(Tool.Destructive, true)

/** Stack-wide tools: health across every application and raw API access. */
export const toolkit = Toolkit.make(MediaStackHealth, MediaApiGet, MediaApiWrite)

const ServarrStatus = Schema.Struct({ version: Schema.String })
const ServarrHealth = Schema.Array(Schema.Struct({ source: Schema.String, type: Schema.String, message: Schema.String }))
const SeerrStatus = Schema.Struct({ version: Schema.String, updateAvailable: Schema.optionalKey(Schema.Boolean) })
const SeerrPublicSettings = Schema.Struct({ mediaServerType: Schema.optionalKey(Schema.Int) })
const PlexIdentity = Schema.Struct({ MediaContainer: Schema.Struct({ version: Schema.String }) })

const SEERR_MEDIA_SERVERS: Readonly<Record<number, string>> = { 1: "Plex", 2: "Jellyfin", 3: "Emby" }

type ServiceHealth = typeof ServiceHealth.Type

// Plex also uses GET for mutations. Unknown endpoints must not inherit read-only permission.
const PLEX_READ_PATHS = [
  /^\/identity$/,
  /^\/:\/prefs$/,
  /^\/library\/sections$/,
  /^\/library\/sections\/\d+\/(all|recentlyAdded)$/,
  /^\/library\/recentlyAdded$/,
  /^\/library\/metadata\/\d+(\/(children|allLeaves))?$/,
  /^\/hubs\/search$/,
  /^\/status\/sessions$/,
]

/** Handlers for the stack-wide tools. */
export const layer = toolkit.toLayer(
  Effect.gen(function* () {
    const api = yield* MediaApi.Service

    const unreachable = (service: MediaService) => (error: { readonly message: string }) =>
      Effect.succeed<ServiceHealth>({ service, reachable: false, warnings: [], error: error.message })

    const servarrHealth = (service: "sonarr" | "radarr" | "lidarr" | "prowlarr") =>
      Effect.all(
        [
          api.requestAs(service, { method: "GET", path: "/system/status" }, ServarrStatus),
          api.requestAs(service, { method: "GET", path: "/health" }, ServarrHealth),
        ],
        { concurrency: 2 },
      ).pipe(
        Effect.map(
          ([status, health]): ServiceHealth => ({
            service,
            reachable: true,
            version: status.version,
            warnings: health.map((entry) => `${entry.type} ${entry.source}: ${entry.message}`),
          }),
        ),
        Effect.catch(unreachable(service)),
      )

    const seerrHealth = Effect.all(
      [
        api.requestAs("seerr", { method: "GET", path: "/status" }, SeerrStatus),
        api.requestAs("seerr", { method: "GET", path: "/settings/public" }, SeerrPublicSettings),
      ],
      { concurrency: 2 },
    ).pipe(
      Effect.map(([status, settings]): ServiceHealth => {
        const server = settings.mediaServerType === undefined ? "unknown" : (SEERR_MEDIA_SERVERS[settings.mediaServerType] ?? "unknown")
        return {
          service: "seerr",
          reachable: true,
          version: status.version,
          warnings: status.updateAvailable === true ? ["Seerr update available"] : [],
          details: `media server: ${server}`,
        }
      }),
      Effect.catch(unreachable("seerr")),
    )

    const plexHealth = api.requestAs("plex", { method: "GET", path: "/identity" }, PlexIdentity).pipe(
      Effect.map((identity): ServiceHealth => ({
        service: "plex",
        reachable: true,
        version: identity.MediaContainer.version,
        warnings: [],
      })),
      Effect.catch(unreachable("plex")),
    )

    return toolkit.of({
      media_stack_health: Effect.fn("StackTools.health")(function* () {
        const services = yield* Effect.all(
          [seerrHealth, servarrHealth("sonarr"), servarrHealth("radarr"), servarrHealth("lidarr"), servarrHealth("prowlarr"), plexHealth],
          { concurrency: "unbounded" },
        )
        return { services }
      }),
      media_api_get: Effect.fn("StackTools.apiGet")(function* ({ service, path, query }) {
        if (service === "plex" && !PLEX_READ_PATHS.some((pattern) => pattern.test(path))) {
          return yield* new MediaRequestInvalid({ reason: "Plex path is not a known read endpoint; use a dedicated Plex tool for scans and refreshes" })
        }
        const body = yield* api.request(service, { method: "GET", path, query })
        return { body: redactSecrets(body) }
      }),
      media_api_write: Effect.fn("StackTools.apiWrite")(function* ({ service, method, path, query, body }) {
        const response = yield* api.request(service, { method, path, query, body })
        return { body: redactSecrets(response) }
      }),
    })
  }),
)
