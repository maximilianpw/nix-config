import { Effect, Schema, Semaphore } from "effect"
import { Tool, Toolkit } from "effect/ai"
import { MediaRequestInvalid, MediaToolError } from "../errors.ts"
import * as MediaApi from "../media-api.ts"
import * as PlexMusic from "../plex-music.ts"

const Count = (fallback: number, maximum: number) => Schema.Int.check(Schema.isBetween({ minimum: 1, maximum })).pipe(Schema.withDecodingDefault(Effect.succeed(fallback)))
const Offset = Schema.Int.check(Schema.isGreaterThanOrEqualTo(0)).pipe(Schema.withDecodingDefault(Effect.succeed(0)))
const TrackKeys = Schema.Array(PlexMusic.PlexKey).check(Schema.isBetweenLength(1, 200))
const PlaylistTitle = Schema.NonEmptyString.check(Schema.isMaxLength(200))
const Failure = Schema.Union([MediaToolError, PlexMusic.PlaylistRefreshFailed])

const Search = Tool.make("plex_music_search", {
  description: "Search tracks by title, or browse a music library. Returns artist, album, play count and last-played time. Page using offset and hasMore; disambiguate recordings before adding them.",
  parameters: Schema.Struct({ sectionKey: PlexMusic.PlexKey, title: Schema.optionalKey(Schema.NonEmptyString),
    sort: Schema.optionalKey(Schema.Literals(["titleSort:asc", "addedAt:desc", "lastViewedAt:asc", "viewCount:asc"])), offset: Offset, limit: Count(50, 200) }),
  success: Schema.Struct({ tracks: Schema.Array(PlexMusic.MusicTrack), offset: Schema.Int, total: Schema.NullOr(Schema.Int), hasMore: Schema.Boolean }), failure: Failure,
}).annotate(Tool.Readonly, true).annotate(Tool.Destructive, false).annotate(Tool.Idempotent, true)

const List = Tool.make("plex_playlists", {
  description: "List audio playlists belonging to the connected Plex user, including smart playlists. Page using offset and hasMore.",
  parameters: Schema.Struct({ offset: Offset, limit: Count(50, 200) }),
  success: Schema.Struct({ playlists: Schema.Array(PlexMusic.MusicPlaylist), offset: Schema.Int, total: Schema.NullOr(Schema.Int), hasMore: Schema.Boolean }), failure: Failure,
}).annotate(Tool.Readonly, true).annotate(Tool.Destructive, false).annotate(Tool.Idempotent, true)

const Read = Tool.make("plex_playlist", {
  description: "Read an entire audio playlist in order, including playlist entry IDs and a snapshot. Smart playlists can be read but not refreshed with explicit tracks. Limited to 10000 tracks.",
  parameters: Schema.Struct({ playlistKey: PlexMusic.PlexKey }), success: PlexMusic.PlaylistState, failure: Failure,
}).annotate(Tool.Readonly, true).annotate(Tool.Destructive, false).annotate(Tool.Idempotent, true)

const Create = Tool.make("plex_playlist_create", {
  description: "Create a regular audio playlist for the connected Plex user from 1-200 distinct track ratingKeys, in order. Only existing Plex tracks can be added. Requires confirm: true. Creation is not retried; list playlists after an uncertain result.",
  parameters: Schema.Struct({ title: PlaylistTitle, ratingKeys: TrackKeys, confirm: Schema.Literal(true) }),
  success: Schema.Struct({ created: Schema.Boolean, title: Schema.String }), failure: Failure,
}).annotate(Tool.Readonly, false).annotate(Tool.Destructive, false).annotate(Tool.Idempotent, false)

const Rename = Tool.make("plex_playlist_rename", {
  description: "Rename a regular audio playlist after reading it. Requires its current snapshot and confirm: true.",
  parameters: Schema.Struct({ playlistKey: PlexMusic.PlexKey, title: PlaylistTitle, expectedSnapshot: Schema.NonEmptyString, confirm: Schema.Literal(true) }),
  success: Schema.Struct({ renamed: Schema.Boolean, title: Schema.String }), failure: Failure,
}).annotate(Tool.Readonly, false).annotate(Tool.Destructive, false).annotate(Tool.Idempotent, true)

const Refresh = Tool.make("plex_playlist_refresh", {
  description: "Preview an exact ordered selection of 1-200 distinct tracks for an existing regular playlist. Adds, removes duplicates/unselected entries and reorders. Include every track to keep. pinnedRatingKeys must remain in the selection. To write, repeat the selection with apply: true, confirm: true and expectedSnapshot from the preview. Preserves playlist identity; writes are not atomic and are never blindly retried. No music files are deleted. Does not schedule future runs or remember pins.",
  parameters: Schema.Struct({ playlistKey: PlexMusic.PlexKey, ratingKeys: TrackKeys,
    pinnedRatingKeys: Schema.Array(PlexMusic.PlexKey).check(Schema.isMaxLength(200)).pipe(Schema.withDecodingDefault(Effect.succeed([]))),
    expectedSnapshot: Schema.optionalKey(Schema.NonEmptyString),
    apply: Schema.Boolean.pipe(Schema.withDecodingDefault(Effect.succeed(false))), confirm: Schema.optionalKey(Schema.Literal(true)) }),
  success: Schema.Struct({ applied: Schema.Boolean, snapshot: Schema.String, playlist: PlexMusic.MusicPlaylist,
    tracks: Schema.Array(PlexMusic.MusicTrack), addedRatingKeys: Schema.Array(PlexMusic.PlexKey), removedPlaylistItemIds: Schema.Array(PlexMusic.PlexKey), orderChanged: Schema.Boolean }), failure: Failure,
}).annotate(Tool.Readonly, false).annotate(Tool.Destructive, true).annotate(Tool.Idempotent, false)

/** Music browsing and regular playlist editing, with a read-only refresh preview by default. */
export const toolkit = Toolkit.make(Search, List, Read, Create, Rename, Refresh)

const uniqueKeys = (keys: ReadonlyArray<string>) => new Set(keys).size === keys.length
  ? Effect.void : Effect.fail(new MediaRequestInvalid({ reason: "Select distinct track ratingKeys; duplicate requested tracks are not supported" }))
const editable = (state: typeof PlexMusic.PlaylistState.Type) => state.playlist.smart
  ? Effect.fail(new MediaRequestInvalid({ reason: "Smart playlists use filter rules; explicit track edits are not supported" })) : Effect.void
const checkSnapshot = (state: typeof PlexMusic.PlaylistState.Type, expected: string) => state.snapshot === expected
  ? Effect.void : Effect.fail(new MediaRequestInvalid({ reason: "Plex playlist changed since the preview; read it and preview again" }))

/** Handlers serialize edits from this process; external Plex clients can still edit concurrently. */
export const layer = toolkit.toLayer(Effect.gen(function* () {
  const api = yield* MediaApi.Service
  const edits = yield* Semaphore.make(1)
  return toolkit.of({
    plex_music_search: (input) => PlexMusic.searchTracks(api, input),
    plex_playlists: ({ offset, limit }) => PlexMusic.listPlaylists(api, offset, limit),
    plex_playlist: ({ playlistKey }) => PlexMusic.readPlaylist(api, playlistKey),
    plex_playlist_create: Effect.fn("PlexPlaylistTools.create")(function* ({ title, ratingKeys }) {
      yield* uniqueKeys(ratingKeys)
      if (title.trim().length === 0) return yield* new MediaRequestInvalid({ reason: "Playlist title must contain visible text" })
      yield* PlexMusic.resolveTracks(api, ratingKeys)
      const uri = yield* PlexMusic.trackUri(api, ratingKeys)
      yield* api.request("plex", { method: "POST", path: "/playlists", query: { title, type: "audio", smart: 0, uri } })
      return { created: true, title }
    }),
    plex_playlist_rename: Effect.fn("PlexPlaylistTools.rename")(function* ({ playlistKey, title, expectedSnapshot }) {
      return yield* edits.withPermits(1)(Effect.gen(function* () {
        if (title.trim().length === 0) return yield* new MediaRequestInvalid({ reason: "Playlist title must contain visible text" })
        const state = yield* PlexMusic.readPlaylist(api, playlistKey)
        yield* editable(state)
        yield* checkSnapshot(state, expectedSnapshot)
        yield* api.request("plex", { method: "PUT", path: `/playlists/${playlistKey}`, query: { title } })
        return { renamed: true, title }
      }))
    }),
    plex_playlist_refresh: Effect.fn("PlexPlaylistTools.refresh")(function* (input) {
      return yield* edits.withPermits(1)(Effect.gen(function* () {
        yield* uniqueKeys(input.ratingKeys)
        if (input.apply && (input.confirm !== true || input.expectedSnapshot === undefined)) return yield* new MediaRequestInvalid({ reason: "Applying a playlist refresh requires confirm: true and expectedSnapshot from its preview" })
        const state = yield* PlexMusic.readPlaylist(api, input.playlistKey)
        yield* editable(state)
        if (input.expectedSnapshot !== undefined) yield* checkSnapshot(state, input.expectedSnapshot)
        const desired = new Set(input.ratingKeys)
        if (input.pinnedRatingKeys.some((key) => !desired.has(key) || !state.tracks.some((track) => track.ratingKey === key))) return yield* new MediaRequestInvalid({ reason: "Every pinned track must already be in the playlist and remain in ratingKeys" })
        const tracks = yield* PlexMusic.resolveTracks(api, input.ratingKeys)
        const seen = new Set<string>()
        const removedPlaylistItemIds = state.tracks.filter((track) => {
          if (!desired.has(track.ratingKey) || seen.has(track.ratingKey)) return true
          seen.add(track.ratingKey)
          return false
        }).flatMap((track) => track.playlistItemId === null ? [] : [track.playlistItemId])
        const existing = new Set(state.tracks.map((track) => track.ratingKey))
        const addedRatingKeys = input.ratingKeys.filter((key) => !existing.has(key))
        const orderChanged = JSON.stringify(state.tracks.map((track) => track.ratingKey)) !== JSON.stringify(input.ratingKeys)
        // Track validation can take several calls; check the playlist again just before writes.
        let result = state
        if (input.apply) {
          const latest = yield* PlexMusic.readPlaylist(api, input.playlistKey)
          yield* checkSnapshot(latest, state.snapshot)
          result = orderChanged ? yield* PlexMusic.applyPlaylistTracks(api, latest, input.ratingKeys) : latest
        }
        return { applied: input.apply, snapshot: result.snapshot, playlist: result.playlist, tracks, addedRatingKeys, removedPlaylistItemIds, orderChanged }
      }))
    }),
  })
}))
