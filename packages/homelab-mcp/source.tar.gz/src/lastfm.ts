import { Effect, Schema } from "effect"
import { UpstreamResponseInvalid } from "./errors.ts"
import type * as MediaApi from "./media-api.ts"

/** A public Last.fm username; no account session is needed for discovery reads. */
export const Username = Schema.String.check(Schema.isPattern(/^[A-Za-z0-9_-]{1,64}$/))

/** Last.fm track metadata is a discovery candidate, never a playable Plex identifier. */
export const LastfmTrack = Schema.Struct({
  title: Schema.String,
  artist: Schema.String,
  mbid: Schema.String,
  playCount: Schema.optionalKey(Schema.Int).annotate({ description: "User play count for top tracks; global play count for similar tracks" }),
  playedAt: Schema.optionalKey(Schema.Int),
  nowPlaying: Schema.Boolean,
})

/** Time windows supported by user.getTopTracks. */
export const Period = Schema.Literals(["overall", "7day", "1month", "3month", "6month", "12month"])

const IntegerText = Schema.String.check(Schema.isPattern(/^\d{1,15}$/))
const Artist = Schema.Union([Schema.Struct({ name: Schema.String }), Schema.Struct({ "#text": Schema.String })])
const UpstreamTrack = Schema.Struct({
  name: Schema.String,
  artist: Artist,
  mbid: Schema.optionalKey(Schema.String),
  playcount: Schema.optionalKey(Schema.Union([IntegerText, Schema.Int.check(Schema.isGreaterThanOrEqualTo(0))])),
  date: Schema.optionalKey(Schema.Struct({ uts: IntegerText })),
  "@attr": Schema.optionalKey(Schema.Struct({ nowplaying: Schema.optionalKey(Schema.String) })),
})
const TrackList = Schema.Struct({
  // XML-derived JSON may represent a single track as an object.
  track: Schema.optionalKey(Schema.Union([Schema.Array(UpstreamTrack), UpstreamTrack])),
  "@attr": Schema.optionalKey(Schema.Struct({ totalPages: Schema.optionalKey(IntegerText) })),
})
const UserResponse = Schema.Struct({
  toptracks: Schema.optionalKey(TrackList), recenttracks: Schema.optionalKey(TrackList), lovedtracks: Schema.optionalKey(TrackList),
})
const SimilarResponse = Schema.Struct({ similartracks: TrackList })

const toTrack = (track: typeof UpstreamTrack.Type, includePlayedAt: boolean): typeof LastfmTrack.Type => ({
  title: track.name,
  artist: "name" in track.artist ? track.artist.name : track.artist["#text"],
  mbid: track.mbid ?? "",
  nowPlaying: track["@attr"]?.nowplaying === "true",
  ...(track.playcount === undefined ? {} : { playCount: Number(track.playcount) }),
  // Loved-track timestamps record the love action, not a listen.
  ...(!includePlayedAt || track.date === undefined ? {} : { playedAt: Number(track.date.uts) }),
})
const toTracks = (list: typeof TrackList.Type, includePlayedAt: boolean) => {
  const tracks = list.track === undefined ? [] : Array.isArray(list.track) ? list.track : [list.track]
  return tracks.map((track) => toTrack(track, includePlayedAt))
}

/** Read one public history/favorites page; callers must honor hasMore before claiming complete coverage. */
export const userTracks = Effect.fn("Lastfm.userTracks")(function* (api: MediaApi.Interface, input: {
  readonly username: string; readonly kind: "top" | "recent" | "loved"; readonly period: typeof Period.Type;
  readonly page: number; readonly limit: number; readonly from?: number;
}) {
  const method = input.kind === "top" ? "user.getTopTracks" : input.kind === "recent" ? "user.getRecentTracks" : "user.getLovedTracks"
  const response = yield* api.requestAs("lastfm", { method: "GET", path: "/", query: {
    method, user: input.username, page: input.page, limit: input.limit,
    ...(input.kind === "top" ? { period: input.period } : {}),
    ...(input.kind === "recent" && input.from !== undefined ? { from: input.from } : {}),
  } }, UserResponse)
  const list = input.kind === "top" ? response.toptracks : input.kind === "recent" ? response.recenttracks : response.lovedtracks
  if (list === undefined) return yield* new UpstreamResponseInvalid({ service: "lastfm", method: "GET", path: "/", detail: `missing ${input.kind} tracks container` })
  const tracks = toTracks(list, input.kind === "recent")
  const totalPages = list["@attr"]?.totalPages === undefined ? null : Number(list["@attr"].totalPages)
  return { tracks, page: input.page, totalPages, hasMore: totalPages === null ? tracks.length >= input.limit : input.page < totalPages }
})

/** Get track similarity candidates. Missing or ambiguous Plex matches must be handled separately. */
export const similarTracks = Effect.fn("Lastfm.similarTracks")(function* (api: MediaApi.Interface, artist: string, title: string, limit: number) {
  const response = yield* api.requestAs("lastfm", { method: "GET", path: "/", query: {
    method: "track.getSimilar", artist, track: title, autocorrect: 1, limit,
  } }, SimilarResponse)
  return toTracks(response.similartracks, false)
})

/** Conservative artist/title identity: retain punctuation and version suffixes to avoid substituting recordings. */
export const trackIdentity = (track: { readonly title: string; readonly artist: string }): string =>
  JSON.stringify([track.artist, track.title].map((value) => value.normalize("NFKC").trim().replace(/\s+/g, " ").toLowerCase()))
