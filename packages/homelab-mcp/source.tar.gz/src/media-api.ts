import { Context, Duration, Effect, Layer, Option, Redacted, Schedule, Schema } from "effect"
import { FetchHttpClient, HttpClient, HttpClientRequest } from "effect/http"
import * as Connections from "./configuration/connections.ts"
import * as Credentials from "./credentials.ts"
import {
  type MediaApiError,
  UpstreamRejected,
  UpstreamResponseInvalid,
  UpstreamUnreachable,
} from "./errors.ts"
import { apiBasePath, type MediaService } from "./media-service.ts"
import { isSecretKey, redactSecrets } from "./redaction.ts"

/** HTTP methods the upstream REST APIs use. */
export type HttpMethod = "GET" | "POST" | "PUT" | "DELETE"

/** A query parameter value; arrays repeat the parameter name. */
export type QueryValue = string | number | boolean | ReadonlyArray<string | number>

/** One request to an application's REST API. */
export interface ApiRequest {
  readonly method: HttpMethod
  /**
   * Path relative to the application's API root, starting with `/`, such as
   * `/series/12` for Sonarr (sent to `/api/v3/series/12`). Plex paths are
   * relative to the server origin, such as `/library/sections`.
   */
  readonly path: string
  readonly query?: Readonly<Record<string, QueryValue>> | undefined
  readonly body?: Schema.Json | undefined
  /** Disable automatic retries for GET endpoints that mutate state, such as a Plex scan. */
  readonly retry?: false
}

/** Authenticated access to each configured application's REST API. */
export interface Interface {
  /**
   * Send a request and return the parsed JSON body, or `null` for an empty body.
   *
   * Read-only GET requests are retried on transport failures and transient statuses; other
   * methods are sent once because Servarr and Seerr writes are not idempotent.
   */
  readonly request: (service: MediaService, request: ApiRequest) => Effect.Effect<Schema.Json, MediaApiError>
  /** Send a request and decode its body with `schema`, reporting a mismatch as `UpstreamResponseInvalid`. */
  readonly requestAs: <S extends Schema.Decoder<unknown>>(
    service: MediaService,
    request: ApiRequest,
    schema: S,
  ) => Effect.Effect<S["Type"], MediaApiError>
}

/** Authenticated upstream API access. */
export class Service extends Context.Service<Service, Interface>()("homelab-mcp/MediaApi") {}

const REQUEST_TIMEOUT = Duration.seconds(30)
const MAX_DETAIL_LENGTH = 800
const RETRYABLE_STATUSES = new Set([408, 429, 500, 502, 503, 504])
// Relative API paths only: no scheme, authority, or query string.
const SAFE_PATH = /^\/(?!\/)[A-Za-z0-9._~\-/:,%@+]*$/

/**
 * Why `path` could leave the application's API root, or `undefined` when it is safe.
 *
 * Segments are checked after percent-decoding because `URL` resolves `%2e%2e` as
 * `..`, and upstream servers may decode `%2f` into a separator.
 */
const unsafePathReason = (path: string): string | undefined => {
  if (!SAFE_PATH.test(path)) return "path must be a relative API path such as /series/12"
  for (const segment of path.split("/")) {
    let decoded: string
    try {
      decoded = decodeURIComponent(segment)
    } catch {
      return "path contains invalid percent-encoding"
    }
    if (decoded === "." || decoded === ".." || decoded.includes("/") || decoded.includes("\\")) {
      return "path must not contain '.' or '..' segments or encoded separators"
    }
  }
  return undefined
}

/**
 * Whether an upstream status means the credential itself was rejected. Seerr answers
 * an unknown API key with 403 because it falls back to an anonymous session.
 */
const isCredentialRejected = (service: MediaService, status: number): boolean =>
  status === 401 || (service === "seerr" && status === 403)

const decodeJsonText = Schema.decodeUnknownEffect(Schema.fromJsonString(Schema.Json))

const ProblemDetails = Schema.Struct({
  title: Schema.optionalKey(Schema.String),
  message: Schema.optionalKey(Schema.String),
  error: Schema.optionalKey(Schema.String),
})
const ValidationFailures = Schema.Array(
  Schema.Struct({ propertyName: Schema.optionalKey(Schema.String), errorMessage: Schema.String }),
)
const decodeProblem = Schema.decodeUnknownOption(ProblemDetails)
const decodeValidation = Schema.decodeUnknownOption(ValidationFailures)
const decodeErrorJson = Schema.decodeUnknownOption(Schema.fromJsonString(Schema.Json))

/** Redact structured errors and known credentials; arbitrary text is not safe to echo. */
const describeErrorBody = (text: string, secrets: ReadonlyArray<Redacted.Redacted<string>>): string => {
  const decoded = decodeErrorJson(text)
  if (Option.isNone(decoded)) return text.trim() === "" ? "empty response body" : "non-JSON error body withheld"
  const body = redactSecrets(decoded.value)
  const sanitize = (message: string) => {
    for (const secret of secrets) message = message.replaceAll(Redacted.value(secret), "[redacted]")
    return message.length > MAX_DETAIL_LENGTH ? `${message.slice(0, MAX_DETAIL_LENGTH)}…` : message
  }
  const validation = decodeValidation(body)
  if (validation._tag === "Some" && validation.value.length > 0) {
    return sanitize(validation.value
      .map((failure) => isSecretKey(failure.propertyName ?? "")
        ? `${failure.propertyName}: [redacted]`
        : (failure.propertyName ? `${failure.propertyName}: ${failure.errorMessage}` : failure.errorMessage))
      .join("; "))
  }
  const problem = decodeProblem(body)
  if (problem._tag === "Some") {
    const summary = problem.value.message ?? problem.value.error ?? problem.value.title
    if (summary !== undefined) return sanitize(summary)
  }
  return typeof body === "object" && body !== null ? sanitize(JSON.stringify(body)) : "error body withheld"
}

const authorize = (service: MediaService, secret: Redacted.Redacted<string>) =>
  service === "plex"
    ? HttpClientRequest.setHeader("X-Plex-Token", Redacted.value(secret))
    : HttpClientRequest.setHeader("X-Api-Key", Redacted.value(secret))

/** Production API access over `fetch`, authenticated with each resolved connection's credential. */
export const layerWithoutDependencies: Layer.Layer<
  Service,
  never,
  Connections.Service | Credentials.Service | HttpClient.HttpClient
> = Layer.effect(
  Service,
  Effect.gen(function* () {
    const connections = yield* Connections.Service
    const credentials = yield* Credentials.Service
    const client = yield* HttpClient.HttpClient

    const request = Effect.fn("MediaApi.request")(function* (service: MediaService, apiRequest: ApiRequest) {
      const { method, path } = apiRequest
      const failure = { service, method, path }
      const unsafe = unsafePathReason(path)
      if (unsafe !== undefined) return yield* new UpstreamUnreachable({ ...failure, detail: unsafe })
      // Resolve once per request so every attempt uses one configuration revision.
      const connection = yield* connections.resolve(service)
      const origin = connection.baseUrl
      const root = `${origin.pathname.replace(/\/$/, "")}${apiBasePath(service)}`
      const url = new URL(`${root}${path}`, origin)
      if (url.origin !== origin.origin || !(url.pathname === root || url.pathname.startsWith(`${root}/`))) {
        return yield* new UpstreamUnreachable({ ...failure, detail: "path resolves outside the application's API root" })
      }

      let baseRequest = HttpClientRequest.make(method)(url).pipe(HttpClientRequest.acceptJson)
      if (apiRequest.query !== undefined) {
        baseRequest = HttpClientRequest.setUrlParams(baseRequest, apiRequest.query)
      }
      if (apiRequest.body !== undefined) {
        baseRequest = HttpClientRequest.bodyJsonUnsafe(baseRequest, apiRequest.body)
      }

      const sendWith = (secret: Redacted.Redacted<string>) => {
        const send = client.execute(authorize(service, secret)(baseRequest)).pipe(
          Effect.provideService(FetchHttpClient.RequestInit, { redirect: "manual" }),
          Effect.flatMap((response) => Effect.map(response.text, (text) => ({ status: response.status, text }))),
          Effect.timeout(REQUEST_TIMEOUT),
          Effect.mapError(() => new UpstreamUnreachable({ ...failure, detail: "HTTP transport failed or timed out" })),
          Effect.flatMap((response) => RETRYABLE_STATUSES.has(response.status)
            ? Effect.fail(new UpstreamRejected({
              ...failure, status: response.status, detail: describeErrorBody(response.text, [secret, credentials.accessToken]),
            }))
            : Effect.succeed(response)),
        )
        return method === "GET" && apiRequest.retry !== false
          ? send.pipe(Effect.retry({
            times: 2,
            schedule: Schedule.exponential(Duration.millis(200)),
            while: (error) => error._tag === "UpstreamUnreachable" || RETRYABLE_STATUSES.has(error.status),
          }))
          : send
      }

      const secret = connection.credential
      const usedSecrets = [secret, credentials.accessToken]
      let response = yield* sendWith(secret)
      if (isCredentialRejected(service, response.status)) {
        // A legacy credential file may hold a regenerated key; a rejected request changed
        // nothing, so resending with the key now on disk is safe even for writes.
        if (Option.isSome(connection.refreshCredential)) {
          const fresh = yield* connection.refreshCredential.value.pipe(Effect.option)
          if (Option.isSome(fresh) && Redacted.value(fresh.value) !== Redacted.value(secret)) {
            usedSecrets.push(fresh.value)
            response = yield* sendWith(fresh.value)
          }
        }
        if (isCredentialRejected(service, response.status)) {
          return yield* new UpstreamRejected({
            ...failure,
            status: response.status,
            detail: `${describeErrorBody(response.text, usedSecrets)} (the ${service} credential from ${connection.credentialSource} was rejected; ${connection.credentialRecovery})`,
          })
        }
      }

      if (response.status < 200 || response.status >= 300) {
        return yield* new UpstreamRejected({ ...failure, status: response.status, detail: describeErrorBody(response.text, usedSecrets) })
      }
      if (response.text.trim().length === 0) return null
      return yield* decodeJsonText(response.text).pipe(
        Effect.mapError(() => new UpstreamResponseInvalid({ ...failure, detail: "body is not JSON" })),
      )
    })

    const requestAs = <S extends Schema.Decoder<unknown>>(service: MediaService, apiRequest: ApiRequest, schema: S) =>
      request(service, apiRequest).pipe(
        Effect.flatMap((json) =>
          Schema.decodeUnknownEffect(schema)(json).pipe(
            Effect.mapError(
              () =>
                new UpstreamResponseInvalid({
                  service,
                  method: apiRequest.method,
                  path: apiRequest.path,
                  detail: "body does not match the expected response schema",
                }),
            ),
          ),
        ),
      )

    return Service.of({ request, requestAs })
  }),
)

/** Production API access using the global `fetch`. */
export const layer = layerWithoutDependencies.pipe(Layer.provide(FetchHttpClient.layer))
