import { BunRuntime, BunServices } from "@effect/platform-bun"
import { Console, Effect, FileSystem, Layer, Option, Redacted, Schema } from "effect"
import { Command, Flag } from "effect/cli"
import { ConnectionInvalid } from "./configuration/connection.ts"
import type { ConnectionSummary } from "./configuration/connections.ts"
import * as Connections from "./configuration/connections.ts"
import * as Credentials from "./credentials.ts"
import * as ServerConfig from "./server-config.ts"

// Local administration for the installation, run with the same environment as the server
// (HOMELAB_MCP_DATA_DIRECTORY, HOMELAB_MCP_CREDENTIALS_DIRECTORY, ...). A running server
// reads its connections at startup, so changes made here apply after it restarts.

/** The command would write state that a server without a data directory cannot keep. */
class DataDirectoryRequired extends Schema.TaggedError<DataDirectoryRequired>()("DataDirectoryRequired", {}) {
  override get message(): string {
    return "Data directory required: set HOMELAB_MCP_DATA_DIRECTORY to the server's data directory and run again"
  }
}

const RESTART_NOTICE = "Restart homelab-mcp so the running server uses these connections."

const describeConnection = (connection: ConnectionSummary) => {
  const credential = Option.match(connection.credentialProblem, {
    onNone: () => connection.credential,
    onSome: (problem) => `unreadable (${problem})`,
  })
  const defaults = connection.defaults.rootFolder === undefined ? "" : `  root folder ${connection.defaults.rootFolder}`
  return `${connection.integration.padEnd(9)} ${connection.enabled ? "enabled " : "disabled"}  ${connection.displayName}  ${connection.baseUrl}  credential ${credential}${defaults}  [${connection.id} r${connection.revision}]`
}

const list = Command.make("list", {}, () =>
  Effect.gen(function* () {
    const connections = yield* (yield* Connections.Service).list
    if (connections.length === 0) {
      yield* Console.log("No saved connections.")
      return
    }
    for (const connection of connections) yield* Console.log(describeConnection(connection))
  })).pipe(Command.withDescription("List saved connections without their credentials"))

const importLegacy = Command.make("import-legacy", {}, () =>
  Effect.gen(function* () {
    const { dataDirectory } = yield* ServerConfig.Service
    if (Option.isNone(dataDirectory)) return yield* new DataDirectoryRequired()
    const report = yield* (yield* Connections.Service).importLegacy
    for (const connection of report.imported) yield* Console.log(`imported  ${describeConnection(connection)}`)
    for (const integration of report.skipped) yield* Console.log(`kept      ${integration}: already had a saved connection`)
    for (const entry of report.unavailable) yield* Console.log(`not found ${entry.integration}: ${entry.reason}`)
    yield* Console.log("Legacy credential files are no longer read.")
    yield* Console.log(RESTART_NOTICE)
  })).pipe(
  Command.withDescription(
    "Copy the legacy credential files and *_URL / *_ROOT_FOLDER variables into saved connections, then stop reading the files",
  ),
)

const setLastfm = Command.make("set-lastfm", { apiKeyFile: Flag.File("api-key-file", { mustExist: true }) }, ({ apiKeyFile }) =>
  Effect.gen(function* () {
    const { dataDirectory } = yield* ServerConfig.Service
    if (Option.isNone(dataDirectory)) return yield* new DataDirectoryRequired()
    const fs = yield* FileSystem.FileSystem
    const key = (yield* fs.readFileString(apiKeyFile)).trim()
    if (!/^[a-fA-F0-9]{32}$/.test(key)) return yield* new ConnectionInvalid({ field: "api-key-file", reason: "expected a file containing only a 32-character Last.fm API key" })
    const connections = yield* Connections.Service
    const existing = (yield* connections.list).find((connection) => connection.integration === "lastfm")
    if (existing === undefined) {
      yield* connections.create({ integration: "lastfm", baseUrl: "https://ws.audioscrobbler.com", credential: Redacted.make(key), enabled: true })
    } else {
      yield* connections.update(existing.id, existing.revision, { credential: { _tag: "Replace", secret: Redacted.make(key) }, enabled: true })
    }
    yield* Console.log("Last.fm API key saved for public music reads.")
    yield* Console.log(RESTART_NOTICE)
  })).pipe(Command.withDescription("Save or replace a Last.fm API key from a local file, including after legacy import"))

const connections = Command.make("connections").pipe(
  Command.withDescription("Manage connections to media applications"),
  Command.withSubcommands([list, importLegacy, setLastfm]),
)

const admin = Command.make("homelab-mcp-admin").pipe(
  Command.withDescription("Local administration for homelab-mcp"),
  Command.withSubcommands([connections]),
)

const ApplicationStateLive = Connections.layer.pipe(
  Layer.provideMerge(Credentials.layer),
  Layer.provideMerge(ServerConfig.layer),
)

Command.runWith(admin, { version: "0.1.0" })(process.argv.slice(2)).pipe(
  Effect.provide(ApplicationStateLive),
  Effect.provide(BunServices.layer),
  BunRuntime.runMain,
)
