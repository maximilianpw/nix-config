import { Result, type Schema } from "effect"

/** One changed value between two JSON documents, addressed by a dotted path. */
export interface JsonChange {
  /** Dotted path such as `fields.host` or `cutoff`; Servarr `fields` entries are addressed by name. */
  readonly path: string
  readonly before: Schema.Json | undefined
  readonly after: Schema.Json | undefined
}

type JsonObject = Schema.JsonObject

const isObject = (value: Schema.Json | undefined): value is JsonObject =>
  value !== null && value !== undefined && typeof value === "object" && !Array.isArray(value)

const isArray = (value: Schema.Json | undefined): value is Schema.JsonArray => Array.isArray(value)

type NamedEntry = JsonObject & { readonly name: string }

const isNamedList = (value: Schema.Json | undefined): value is ReadonlyArray<NamedEntry> =>
  isArray(value) && value.every((entry) => isObject(entry) && typeof entry["name"] === "string")

/**
 * Apply a partial update to a Servarr-style resource.
 *
 * Objects merge recursively and every other value replaces the current one. A
 * resource's `fields` list (`[{ name, value }]`) may be updated with an object
 * keyed by field name, e.g. `{ fields: { host: "127.0.0.1" } }`.
 *
 * @returns The merged resource, or the unknown field names when `fields` names a field the resource lacks.
 */
export const mergeChanges = (current: JsonObject, changes: JsonObject): Result.Result<JsonObject, ReadonlyArray<string>> => {
  const unknownFields: Array<string> = []
  const merge = (base: JsonObject, patch: JsonObject): JsonObject => {
    const merged: Record<string, Schema.Json> = { ...base }
    for (const [key, change] of Object.entries(patch)) {
      const existing = base[key]
      if (key === "fields" && isNamedList(existing) && isObject(change)) {
        for (const name of Object.keys(change)) {
          if (!existing.some((entry) => entry.name === name)) unknownFields.push(name)
        }
        merged[key] = existing.map((entry) => {
          const value = change[entry.name]
          return value === undefined ? entry : { ...entry, value }
        })
      } else if (isObject(existing) && isObject(change)) {
        merged[key] = merge(existing, change)
      } else {
        merged[key] = change
      }
    }
    return merged
  }
  const merged = merge(current, changes)
  return unknownFields.length > 0 ? Result.fail(unknownFields) : Result.succeed(merged)
}

const same = (left: Schema.Json | undefined, right: Schema.Json | undefined): boolean =>
  JSON.stringify(left) === JSON.stringify(right)

/**
 * List the leaf values that differ between two JSON documents.
 *
 * Lists of named entries (Servarr `fields`, quality items with names) are compared
 * by name so a changed field reports `fields.<name>` rather than the whole list.
 */
export const diffJson = (before: Schema.Json | undefined, after: Schema.Json | undefined, path = ""): ReadonlyArray<JsonChange> => {
  if (same(before, after)) return []
  const child = (key: string) => (path === "" ? key : `${path}.${key}`)
  if (isObject(before) && isObject(after)) {
    const keys = [...new Set([...Object.keys(before), ...Object.keys(after)])]
    return keys.flatMap((key) => diffJson(before[key], after[key], child(key)))
  }
  if (isNamedList(before) && isNamedList(after)) {
    const byName = (entries: ReadonlyArray<NamedEntry>) => new Map(entries.map((entry) => [entry.name, entry]))
    const beforeByName = byName(before)
    const afterByName = byName(after)
    if (beforeByName.size === before.length && afterByName.size === after.length) {
      const names = [...new Set([...beforeByName.keys(), ...afterByName.keys()])]
      return names.flatMap((name) => {
        const left = beforeByName.get(name)
        const right = afterByName.get(name)
        // A Servarr field entry changes only through its value.
        if (left !== undefined && right !== undefined && "value" in left && "value" in right) {
          return diffJson(left["value"], right["value"], child(name))
        }
        return diffJson(left, right, child(name))
      })
    }
  }
  return [{ path: path === "" ? "(root)" : path, before, after }]
}
