import { Schema } from "effect"

/** Every application on Kim that this server can talk to. */
export const MediaService = Schema.Literals(["seerr", "sonarr", "radarr", "lidarr", "prowlarr", "plex"])

/** An application on Kim that this server can talk to. */
export type MediaService = typeof MediaService.Type

/** The Servarr applications, which share one REST API style and `X-Api-Key` authentication. */
export const ServarrService = Schema.Literals(["sonarr", "radarr", "lidarr", "prowlarr"])

/** One of the Servarr applications. */
export type ServarrService = typeof ServarrService.Type

/** The Servarr applications that manage a media library, as opposed to Prowlarr's indexer management. */
export const LibraryService = Schema.Literals(["sonarr", "radarr", "lidarr"])

/** One of the library-managing Servarr applications. */
export type LibraryService = typeof LibraryService.Type

/**
 * Path prefix of an application's REST API relative to its origin.
 *
 * Plex has no versioned API root, so its paths start at the origin.
 */
export const apiBasePath = (service: MediaService): string => {
  switch (service) {
    case "seerr":
      return "/api/v1"
    case "sonarr":
    case "radarr":
      return "/api/v3"
    case "lidarr":
    case "prowlarr":
      return "/api/v1"
    case "plex":
      return ""
  }
}
