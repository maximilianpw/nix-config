import { Database as SqliteClient } from "bun:sqlite"
import { fileURLToPath } from "node:url"
import { drizzle, type SQLiteBunDatabase } from "drizzle-orm/bun-sqlite"
import { migrate } from "drizzle-orm/bun-sqlite/migrator"
import { readMigrationFiles } from "drizzle-orm/migrator"
import { Clock, Context, Effect, FileSystem, Layer, Option, Path, Result, Schema } from "effect"
import * as ServerConfig from "../server-config.ts"

/** Drizzle handle for queries inside `src/storage`; never exported beyond it. */
export type Db = SQLiteBunDatabase

/** Where the database lives. */
export type DatabaseLocation =
  | { readonly _tag: "File"; readonly path: string; readonly directory: string }
  | { readonly _tag: "Memory" }

/**
 * The local SQLite database, migrated and ready.
 *
 * Only storage modules use this; they expose domain operations instead of tables.
 */
export interface Interface {
  readonly location: DatabaseLocation
  /** Run synchronous queries. A thrown error becomes `StorageFailure`. */
  readonly use: <A>(operation: string, run: (db: Db) => A) => Effect.Effect<A, StorageFailure>
  /**
   * Run `run` in one transaction. Returning a failed `Result` rolls back every write
   * and fails with that error; a thrown error rolls back and becomes `StorageFailure`.
   */
  readonly transaction: <A, E>(operation: string, run: (tx: Db) => Result.Result<A, E>) => Effect.Effect<A, E | StorageFailure>
}

/** The migrated application database. */
export class Service extends Context.Service<Service, Interface>()("homelab-mcp/Database") {}

/** A query or transaction failed unexpectedly, e.g. the disk is full or the database is locked. */
export class StorageFailure extends Schema.TaggedError<StorageFailure>()("StorageFailure", {
  operation: Schema.String,
  reason: Schema.String,
}) {
  override get message(): string {
    return `Storage failure during ${this.operation}: ${this.reason}`
  }
}

/** The database file could not be opened or is not a usable SQLite database. */
export class DatabaseUnavailable extends Schema.TaggedError<DatabaseUnavailable>()("DatabaseUnavailable", {
  path: Schema.String,
  reason: Schema.String,
}) {
  override get message(): string {
    return `Database unavailable at ${this.path}: ${this.reason}`
  }
}

/** A schema migration failed; the database was left at its previous version. */
export class DatabaseMigrationFailed extends Schema.TaggedError<DatabaseMigrationFailed>()("DatabaseMigrationFailed", {
  path: Schema.String,
  reason: Schema.String,
  backup: Schema.optionalKey(Schema.String),
}) {
  override get message(): string {
    const backup = this.backup === undefined ? "" : `; a pre-migration backup is at ${this.backup}`
    return `Database migration failed at ${this.path}: ${this.reason}${backup}`
  }
}

/** The database was migrated by a newer release; this release must not guess how to use it. */
export class DatabaseNewerThanApplication extends Schema.TaggedError<DatabaseNewerThanApplication>()("DatabaseNewerThanApplication", {
  path: Schema.String,
  unknownMigrations: Schema.Array(Schema.String),
}) {
  override get message(): string {
    return `Database newer than application at ${this.path}: it has migrations ${this.unknownMigrations.join(", ")} that this release does not know; run the newer release or restore the backup taken before its upgrade`
  }
}

/** Every failure that stops the database from opening. */
export type DatabaseStartupError = DatabaseUnavailable | DatabaseMigrationFailed | DatabaseNewerThanApplication

const DATABASE_FILE = "homelab-mcp.sqlite"
const BACKUP_DIRECTORY = "backups"
// Resolves to the repository's `drizzle/` from both `src/storage` and `dist/storage`.
const MIGRATIONS_FOLDER = fileURLToPath(new URL("../../drizzle", import.meta.url))

const describe = (error: unknown): string => (error instanceof Error ? error.message : String(error))

const makeService = (client: SqliteClient, db: Db, location: DatabaseLocation): Interface => ({
  location,
  use: (operation, run) =>
    Effect.try({ try: () => run(db), catch: (error) => new StorageFailure({ operation, reason: describe(error) }) }),
  transaction: <A, E>(operation: string, run: (tx: Db) => Result.Result<A, E>) =>
    Effect.suspend((): Effect.Effect<A, E | StorageFailure> => {
      try {
        // IMMEDIATE takes the write lock up front, so a concurrent CLI write waits instead of failing mid-way.
        client.exec("BEGIN IMMEDIATE")
        const result = run(db)
        client.exec(Result.isSuccess(result) ? "COMMIT" : "ROLLBACK")
        return Result.isSuccess(result) ? Effect.succeed(result.success) : Effect.fail(result.failure)
      } catch (error) {
        if (client.inTransaction) client.exec("ROLLBACK")
        return Effect.fail(new StorageFailure({ operation, reason: describe(error) }))
      }
    }),
})

/**
 * Opens the database under the data directory, backs it up before pending migrations,
 * refuses databases from newer releases, applies migrations, and closes it on release.
 *
 * Without a data directory the database lives in memory and nothing survives a restart.
 */
export const layer: Layer.Layer<Service, DatabaseStartupError, ServerConfig.Service | FileSystem.FileSystem | Path.Path> =
  Layer.effect(
    Service,
    Effect.gen(function* () {
      const { dataDirectory } = yield* ServerConfig.Service
      const fs = yield* FileSystem.FileSystem
      const path = yield* Path.Path

      const location: DatabaseLocation = Option.match(dataDirectory, {
        onNone: () => ({ _tag: "Memory" }),
        onSome: (directory) => ({ _tag: "File", directory, path: path.join(directory, DATABASE_FILE) }),
      })
      const displayPath = location._tag === "File" ? location.path : ":memory:"
      const unavailable = (reason: string) => new DatabaseUnavailable({ path: displayPath, reason })

      if (location._tag === "File") {
        yield* fs.makeDirectory(location.directory, { recursive: true, mode: 0o700 }).pipe(
          Effect.mapError((error) => unavailable(`cannot create data directory: ${error.message}`)),
        )
        // Create a new database file owner-only; SQLite gives its -wal and -shm files the same mode.
        yield* fs.writeFile(location.path, new Uint8Array(), { flag: "a", mode: 0o600 }).pipe(
          Effect.mapError((error) => unavailable(`cannot create database file: ${error.message}`)),
        )
      } else {
        yield* Effect.logWarning("No data directory is configured; connections and settings are kept in memory and lost on restart. Set HOMELAB_MCP_DATA_DIRECTORY to persist them.")
      }

      const client = yield* Effect.acquireRelease(
        Effect.try({
          try: () => {
            const client = new SqliteClient(displayPath, { create: true, strict: true })
            try {
              // WAL lets the admin CLI read and write while the server runs.
              client.exec("PRAGMA journal_mode = WAL")
              client.exec("PRAGMA busy_timeout = 5000")
              client.exec("PRAGMA foreign_keys = ON")
              // Forces SQLite to read the header, so a non-database file fails here.
              client.query("SELECT count(*) FROM sqlite_schema").get()
            } catch (error) {
              client.close()
              throw error
            }
            return client
          },
          catch: (error) => unavailable(describe(error)),
        }),
        (client) => Effect.sync(() => client.close()),
      )
      const db = drizzle({ client })

      const local = yield* Effect.try({
        try: () => readMigrationFiles({ migrationsFolder: MIGRATIONS_FOLDER }).map((migration) => migration.name),
        catch: (error) => new DatabaseMigrationFailed({ path: displayPath, reason: `cannot read migrations: ${describe(error)}` }),
      })
      const { applied, hasTables } = yield* Effect.try({
        try: () => {
          const tables = client.query<{ name: string }, []>("SELECT name FROM sqlite_schema WHERE type = 'table'").all().map((row) => row.name)
          const applied = tables.includes("__drizzle_migrations")
            ? client.query<{ name: string }, []>("SELECT name FROM __drizzle_migrations").all().map((row) => row.name)
            : []
          return { applied, hasTables: tables.length > 0 }
        },
        catch: (error) => unavailable(describe(error)),
      })

      const unknownMigrations = applied.filter((name) => !local.includes(name))
      if (unknownMigrations.length > 0) {
        return yield* new DatabaseNewerThanApplication({ path: displayPath, unknownMigrations })
      }

      const pending = local.filter((name) => !applied.includes(name))
      let backup: string | undefined
      // Back up any existing database before changing it; a brand-new file has nothing to lose.
      if (pending.length > 0 && hasTables && location._tag === "File") {
        const backupDirectory = path.join(location.directory, BACKUP_DIRECTORY)
        const stamp = new Date(yield* Clock.currentTimeMillis).toISOString().replace(/[:.]/g, "-")
        const target = path.join(backupDirectory, `before-${pending[0]}-${stamp}.sqlite`)
        yield* fs.makeDirectory(backupDirectory, { recursive: true, mode: 0o700 }).pipe(
          Effect.mapError((error) => new DatabaseMigrationFailed({ path: displayPath, reason: `cannot create backup directory: ${error.message}` })),
        )
        yield* Effect.try({
          try: () => client.query("VACUUM INTO ?").run(target),
          catch: (error) => new DatabaseMigrationFailed({ path: displayPath, reason: `pre-migration backup failed: ${describe(error)}` }),
        })
        backup = target
      }

      yield* Effect.try({
        try: () => migrate(db, { migrationsFolder: MIGRATIONS_FOLDER }),
        catch: (error) =>
          new DatabaseMigrationFailed({ path: displayPath, reason: describe(error), ...(backup === undefined ? {} : { backup }) }),
      })
      if (backup !== undefined) yield* Effect.logInfo(`Database migrated after backing up to ${backup}`)

      const now = new Date(yield* Clock.currentTimeMillis).toISOString()
      yield* Effect.try({
        try: () => client.query("INSERT OR IGNORE INTO installation (id, created_at) VALUES (1, ?)").run(now),
        catch: (error) => new DatabaseMigrationFailed({ path: displayPath, reason: `cannot initialize installation row: ${describe(error)}` }),
      })

      return Service.of(makeService(client, db, location))
    }),
  )
