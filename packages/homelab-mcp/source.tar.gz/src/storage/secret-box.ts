import { createCipheriv, createDecipheriv, createHash } from "node:crypto"
import { isNotNull } from "drizzle-orm"
import { Context, Crypto, Effect, FileSystem, Layer, Option, Path, Redacted, Result, Schema } from "effect"
import * as ServerConfig from "../server-config.ts"
import * as Database from "./database.ts"
import { connections } from "./schema.ts"

/** A credential sealed with the installation key. */
export interface SealedSecret {
  readonly keyId: string
  /** `iv || tag || ciphertext`. */
  readonly sealed: Uint8Array
}

/**
 * Authenticated encryption for stored upstream credentials.
 *
 * `context` binds a sealed value to its owner (for example a connection id), so a value
 * copied onto another record fails to open instead of authenticating that record.
 */
export interface Interface {
  readonly keyId: string
  readonly seal: (secret: Redacted.Redacted<string>, context: string) => Effect.Effect<SealedSecret>
  /** Why a sealed value cannot be opened, or its plaintext. */
  readonly open: (sealed: SealedSecret, context: string) => Result.Result<Redacted.Redacted<string>, string>
}

/** The installation's credential-sealing key. */
export class Service extends Context.Service<Service, Interface>()("homelab-mcp/SecretBox") {}

/** The key file is missing while stored credentials depend on it. */
export class SecretKeyMissing extends Schema.TaggedError<SecretKeyMissing>()("SecretKeyMissing", {
  path: Schema.String,
  reason: Schema.String,
}) {
  override get message(): string {
    return `Secret key missing at ${this.path}: ${this.reason}`
  }
}

/** The key file exists but cannot be used. */
export class SecretKeyInvalid extends Schema.TaggedError<SecretKeyInvalid>()("SecretKeyInvalid", {
  path: Schema.String,
  reason: Schema.String,
}) {
  override get message(): string {
    return `Secret key invalid at ${this.path}: ${this.reason}`
  }
}

/** Stored credentials were sealed with a different key than the one loaded. */
export class SecretKeyMismatch extends Schema.TaggedError<SecretKeyMismatch>()("SecretKeyMismatch", {
  path: Schema.String,
  loaded: Schema.String,
  stored: Schema.Array(Schema.String),
}) {
  override get message(): string {
    return `Secret key mismatch at ${this.path}: loaded key ${this.loaded} but stored credentials use ${this.stored.join(", ")}; restore the key that matches this database`
  }
}

/** Every failure that stops the key from loading. */
export type SecretKeyError = SecretKeyMissing | SecretKeyInvalid | SecretKeyMismatch

const KEY_FILE = "secret-key"
const KEY_BYTES = 32
const IV_BYTES = 12
const TAG_BYTES = 16
const CIPHER = "aes-256-gcm"

const keyIdOf = (key: Uint8Array) => createHash("sha256").update(key).digest("hex").slice(0, 16)

const make = (key: Uint8Array, crypto: Crypto.Crypto): Interface => {
  const keyId = keyIdOf(key)
  return {
    keyId,
    seal: (secret, context) =>
      // A failing system random source is a catastrophic runtime condition, not an expected error.
      Effect.map(Effect.orDie(crypto.randomBytes(IV_BYTES)), (iv) => {
        const cipher = createCipheriv(CIPHER, key, iv)
        cipher.setAAD(Buffer.from(context, "utf8"))
        const ciphertext = Buffer.concat([cipher.update(Redacted.value(secret), "utf8"), cipher.final()])
        return { keyId, sealed: Buffer.concat([iv, cipher.getAuthTag(), ciphertext]) }
      }),
    open: (sealed, context) => {
      if (sealed.keyId !== keyId) return Result.fail(`sealed with key ${sealed.keyId}, not the loaded key ${keyId}`)
      if (sealed.sealed.length < IV_BYTES + TAG_BYTES) return Result.fail("sealed value is truncated")
      const bytes = Buffer.from(sealed.sealed)
      try {
        const decipher = createDecipheriv(CIPHER, key, bytes.subarray(0, IV_BYTES))
        decipher.setAAD(Buffer.from(context, "utf8"))
        decipher.setAuthTag(bytes.subarray(IV_BYTES, IV_BYTES + TAG_BYTES))
        const plaintext = Buffer.concat([decipher.update(bytes.subarray(IV_BYTES + TAG_BYTES)), decipher.final()])
        return Result.succeed(Redacted.make(plaintext.toString("utf8")))
      } catch {
        return Result.fail("sealed value failed authentication; it was altered or belongs to another record")
      }
    },
  }
}

/**
 * Loads the key from `HOMELAB_MCP_SECRET_KEY_FILE` or `<data directory>/secret-key`.
 *
 * A key is generated only in the data directory and only while no stored credential
 * depends on one; a missing key is never silently replaced. Without a data directory
 * the key is ephemeral, matching the in-memory database.
 */
export const layer: Layer.Layer<
  Service,
  SecretKeyError | Database.StorageFailure,
  Database.Service | ServerConfig.Service | FileSystem.FileSystem | Path.Path | Crypto.Crypto
> = Layer.effect(
  Service,
  Effect.gen(function* () {
    const database = yield* Database.Service
    const { secretKeyFile, dataDirectory } = yield* ServerConfig.Service
    const fs = yield* FileSystem.FileSystem
    const path = yield* Path.Path
    const crypto = yield* Crypto.Crypto

    const storedKeyIds = yield* database.use("SecretBox.storedKeyIds", (db) =>
      db
        .selectDistinct({ keyId: connections.credentialKeyId })
        .from(connections)
        .where(isNotNull(connections.credentialKeyId))
        .all()
        .flatMap((row) => (row.keyId === null ? [] : [row.keyId])),
    )

    const keyPath = Option.orElse(secretKeyFile, () => Option.map(dataDirectory, (directory) => path.join(directory, KEY_FILE)))
    if (Option.isNone(keyPath)) {
      const key = yield* Effect.orDie(crypto.randomBytes(KEY_BYTES))
      return Service.of(make(key, crypto))
    }
    const file = keyPath.value
    const external = Option.isSome(secretKeyFile)

    const exists = yield* fs.exists(file).pipe(
      Effect.mapError((error) => new SecretKeyInvalid({ path: file, reason: error.message })),
    )
    if (!exists) {
      if (storedKeyIds.length > 0) {
        return yield* new SecretKeyMissing({
          path: file,
          reason: `stored credentials were sealed with key ${storedKeyIds.join(", ")}; restore that key file from the backup taken with this database`,
        })
      }
      if (external) {
        return yield* new SecretKeyMissing({ path: file, reason: "HOMELAB_MCP_SECRET_KEY_FILE names a file that does not exist" })
      }
      const key = yield* Effect.orDie(crypto.randomBytes(KEY_BYTES))
      // `wx` refuses to overwrite a key another process created in the meantime.
      yield* fs.writeFileString(file, `${Buffer.from(key).toString("base64")}\n`, { flag: "wx", mode: 0o600 }).pipe(
        Effect.mapError((error) => new SecretKeyInvalid({ path: file, reason: `cannot create key file: ${error.message}` })),
      )
      yield* Effect.logInfo(`Created credential-sealing key ${keyIdOf(key)} at ${file}; back it up together with the database`)
      return Service.of(make(key, crypto))
    }

    const contents = yield* fs.readFileString(file).pipe(
      Effect.mapError((error) => new SecretKeyInvalid({ path: file, reason: error.message })),
    )
    const key = Buffer.from(contents.trim(), "base64")
    if (key.length !== KEY_BYTES || key.toString("base64") !== contents.trim()) {
      return yield* new SecretKeyInvalid({ path: file, reason: `expected ${KEY_BYTES} bytes encoded as base64` })
    }
    const service = make(key, crypto)
    const foreign = storedKeyIds.filter((keyId) => keyId !== service.keyId)
    if (foreign.length > 0) {
      return yield* new SecretKeyMismatch({ path: file, loaded: service.keyId, stored: foreign })
    }
    return Service.of(service)
  }),
)
