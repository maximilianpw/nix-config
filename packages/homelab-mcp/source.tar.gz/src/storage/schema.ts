import { sql } from "drizzle-orm"
import { blob, check, integer, sqliteTable, text } from "drizzle-orm/sqlite-core"

// Table layout is private to `src/storage`; other modules use the stores' domain types.
// Changing this file requires `bun run db:generate` and a committed migration.

/** The single installation row: configuration revision and one-time migration markers. */
export const installation = sqliteTable(
  "installation",
  {
    id: integer("id").primaryKey(),
    /** Incremented by every application-configuration change, so readers can tell snapshots apart. */
    configRevision: integer("config_revision").notNull().default(0),
    /** When legacy credential files were imported; afterwards they are no longer consulted. */
    legacyImportCompletedAt: text("legacy_import_completed_at"),
    createdAt: text("created_at").notNull(),
  },
  (table) => [check("installation_single_row", sql`${table.id} = 1`)],
)

/** Configured links to upstream media applications. */
export const connections = sqliteTable(
  "connections",
  {
    id: text("id").primaryKey(),
    // The first release allows one connection per integration; stable IDs let a later release lift this.
    integration: text("integration").notNull().unique(),
    displayName: text("display_name").notNull(),
    enabled: integer("enabled", { mode: "boolean" }).notNull(),
    baseUrl: text("base_url").notNull(),
    /** Identifies the key that sealed the credential, so a wrong key is detected before decryption. */
    credentialKeyId: text("credential_key_id"),
    /** AES-256-GCM `iv || tag || ciphertext`, bound to the connection id and integration. */
    credentialSealed: blob("credential_sealed", { mode: "buffer" }),
    defaultsJson: text("defaults_json").notNull().default("{}"),
    revision: integer("revision").notNull().default(1),
    createdAt: text("created_at").notNull(),
    updatedAt: text("updated_at").notNull(),
  },
  (table) => [
    check(
      "connections_credential_complete",
      sql`(${table.credentialKeyId} IS NULL) = (${table.credentialSealed} IS NULL)`,
    ),
  ],
)
