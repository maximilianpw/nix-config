import { eq, sql } from "drizzle-orm"
import { Clock, Context, Crypto, Effect, Layer, Option, Redacted, Result, Schema } from "effect"
import {
  BaseUrl,
  ConnectionDefaults,
  ConnectionExists,
  ConnectionId,
  ConnectionNotFound,
  ConnectionRevisionConflict,
  DisplayName,
  Integration,
  LegacyImportAlreadyCompleted,
} from "../configuration/connection.ts"
import * as Database from "./database.ts"
import { connections, installation } from "./schema.ts"
import * as SecretBox from "./secret-box.ts"

/** A connection's stored credential after unsealing. */
export type StoredCredential =
  | { readonly _tag: "None" }
  | { readonly _tag: "Sealed"; readonly secret: Redacted.Redacted<string> }
  /** Present but unusable, e.g. altered or copied from another record; the reason is safe to show. */
  | { readonly _tag: "Unreadable"; readonly reason: string }

/** One saved connection. */
export interface StoredConnection {
  readonly id: ConnectionId
  readonly integration: Integration
  readonly displayName: DisplayName
  readonly enabled: boolean
  readonly baseUrl: BaseUrl
  readonly defaults: ConnectionDefaults
  readonly credential: StoredCredential
  /** Incremented by every change; updates must name the revision they were based on. */
  readonly revision: number
  readonly createdAt: string
  readonly updatedAt: string
}

/** A connection to create. */
export interface NewConnection {
  readonly integration: Integration
  readonly displayName: DisplayName
  readonly enabled: boolean
  readonly baseUrl: BaseUrl
  readonly defaults: ConnectionDefaults
  readonly credential: Option.Option<Redacted.Redacted<string>>
}

/** What to do with a connection's stored credential. */
export type CredentialChange =
  | { readonly _tag: "Keep" }
  | { readonly _tag: "Replace"; readonly secret: Redacted.Redacted<string> }
  | { readonly _tag: "Clear" }

/** Fields to change on an existing connection; omitted fields keep their value. */
export interface ConnectionChanges {
  readonly displayName?: DisplayName
  readonly enabled?: boolean
  readonly baseUrl?: BaseUrl
  readonly defaults?: ConnectionDefaults
  readonly credential?: CredentialChange
}

/** Installation-wide persisted state. */
export interface InstallationState {
  /** Incremented by every application-configuration change. */
  readonly configRevision: number
  readonly legacyImportCompletedAt: Option.Option<string>
}

/** Which integrations a legacy import created and which already had a connection. */
export interface LegacyImportResult {
  readonly imported: ReadonlyArray<StoredConnection>
  readonly skipped: ReadonlyArray<Integration>
}

/** Persistent connections with sealed credentials. */
export interface Interface {
  readonly installation: Effect.Effect<InstallationState, Database.StorageFailure>
  readonly list: Effect.Effect<ReadonlyArray<StoredConnection>, Database.StorageFailure>
  readonly create: (connection: NewConnection) => Effect.Effect<StoredConnection, ConnectionExists | Database.StorageFailure>
  readonly update: (
    id: ConnectionId,
    expectedRevision: number,
    changes: ConnectionChanges,
  ) => Effect.Effect<StoredConnection, ConnectionNotFound | ConnectionRevisionConflict | Database.StorageFailure>
  readonly remove: (
    id: ConnectionId,
    expectedRevision: number,
  ) => Effect.Effect<void, ConnectionNotFound | ConnectionRevisionConflict | Database.StorageFailure>
  /**
   * Create every given connection whose integration has none, and mark the legacy import
   * complete, in one transaction: either all of it is saved or none of it is.
   */
  readonly importLegacy: (
    connections: ReadonlyArray<NewConnection>,
  ) => Effect.Effect<LegacyImportResult, LegacyImportAlreadyCompleted | Database.StorageFailure>
}

/** Stored connections. */
export class Service extends Context.Service<Service, Interface>()("homelab-mcp/ConnectionStore") {}

type Row = typeof connections.$inferSelect

const RowFields = Schema.Struct({
  id: ConnectionId,
  integration: Integration,
  displayName: DisplayName,
  baseUrl: BaseUrl,
  defaults: Schema.fromJsonString(ConnectionDefaults),
})
const decodeRowFields = Schema.decodeUnknownResult(RowFields)

/** Binds a sealed credential to its connection, so a value copied onto another row fails to open. */
const sealingContext = (id: string, integration: string) => `connection:${id}:${integration}`

/** Stores connections in the application database, sealing credentials with the installation key. */
export const layer: Layer.Layer<Service, never, Database.Service | SecretBox.Service | Crypto.Crypto> = Layer.effect(
  Service,
  Effect.gen(function* () {
    const database = yield* Database.Service
    const secretBox = yield* SecretBox.Service
    const crypto = yield* Crypto.Crypto

    const now = Effect.map(Clock.currentTimeMillis, (millis) => new Date(millis).toISOString())
    // A failing system random source is a catastrophic runtime condition, not an expected error.
    const newId = Effect.map(Effect.orDie(crypto.randomBytes(16)), (bytes) =>
      ConnectionId.make(`con_${Buffer.from(bytes).toString("hex")}`),
    )

    const toDomain = (row: Row): Result.Result<StoredConnection, Database.StorageFailure> =>
      Result.match(decodeRowFields({ ...row, defaults: row.defaultsJson }), {
        onFailure: (error) =>
          Result.fail(new Database.StorageFailure({ operation: "ConnectionStore.decode", reason: `stored connection ${row.id} is malformed: ${error.message}` })),
        onSuccess: (fields) => {
          const credential: StoredCredential = row.credentialKeyId === null || row.credentialSealed === null
            ? { _tag: "None" }
            : Result.match(
              secretBox.open({ keyId: row.credentialKeyId, sealed: row.credentialSealed }, sealingContext(row.id, row.integration)),
              {
                onFailure: (reason): StoredCredential => ({ _tag: "Unreadable", reason }),
                onSuccess: (secret): StoredCredential => ({ _tag: "Sealed", secret }),
              },
            )
          return Result.succeed({
            ...fields,
            enabled: row.enabled,
            credential,
            revision: row.revision,
            createdAt: row.createdAt,
            updatedAt: row.updatedAt,
          })
        },
      })

    const decodeRow = (row: Row) => {
      const result = toDomain(row)
      return Result.isSuccess(result) ? Effect.succeed(result.success) : Effect.fail(result.failure)
    }

    const sealFor = (id: ConnectionId, integration: Integration, secret: Redacted.Redacted<string>) =>
      secretBox.seal(secret, sealingContext(id, integration))

    const bumpRevision = (db: Database.Db) =>
      db.update(installation).set({ configRevision: sql`${installation.configRevision} + 1` }).where(eq(installation.id, 1)).run()

    /** Prepare a row for insertion: allocate its id and seal its credential outside the transaction. */
    const prepareInsert = Effect.fnUntraced(function* (connection: NewConnection, timestamp: string) {
      const id = yield* newId
      const sealed = Option.isSome(connection.credential)
        ? yield* sealFor(id, connection.integration, connection.credential.value)
        : undefined
      const row: typeof connections.$inferInsert = {
        id,
        integration: connection.integration,
        displayName: connection.displayName,
        enabled: connection.enabled,
        baseUrl: connection.baseUrl,
        credentialKeyId: sealed?.keyId ?? null,
        credentialSealed: sealed === undefined ? null : Buffer.from(sealed.sealed),
        defaultsJson: JSON.stringify(connection.defaults),
        revision: 1,
        createdAt: timestamp,
        updatedAt: timestamp,
      }
      return row
    })

    const findById = (db: Database.Db, id: ConnectionId) => db.select().from(connections).where(eq(connections.id, id)).get()

    const checkRevision = (
      current: Row | undefined,
      id: ConnectionId,
      expectedRevision: number,
    ): Result.Result<Row, ConnectionNotFound | ConnectionRevisionConflict> => {
      if (current === undefined) return Result.fail(new ConnectionNotFound({ id }))
      if (current.revision !== expectedRevision) {
        return Result.fail(new ConnectionRevisionConflict({ id, expected: expectedRevision, actual: current.revision }))
      }
      return Result.succeed(current)
    }

    const installationState = database
      .use("ConnectionStore.installation", (db) => db.select().from(installation).where(eq(installation.id, 1)).get())
      .pipe(
        Effect.flatMap((row) =>
          row === undefined
            ? Effect.fail(new Database.StorageFailure({ operation: "ConnectionStore.installation", reason: "installation row is missing" }))
            : Effect.succeed<InstallationState>({
              configRevision: row.configRevision,
              legacyImportCompletedAt: Option.fromNullishOr(row.legacyImportCompletedAt),
            }),
        ),
      )

    const list = database
      .use("ConnectionStore.list", (db) => db.select().from(connections).orderBy(connections.createdAt, connections.id).all())
      .pipe(Effect.flatMap((rows) => Effect.forEach(rows, decodeRow)))

    const create = Effect.fn("ConnectionStore.create")(function* (connection: NewConnection) {
      const row = yield* prepareInsert(connection, yield* now)
      const inserted = yield* database.transaction("ConnectionStore.create", (db) => {
        const existing = db.select({ id: connections.id }).from(connections).where(eq(connections.integration, connection.integration)).get()
        if (existing !== undefined) return Result.fail(new ConnectionExists({ integration: connection.integration }))
        const inserted = db.insert(connections).values(row).returning().get()
        bumpRevision(db)
        return Result.succeed(inserted)
      })
      return yield* decodeRow(inserted)
    })

    const update = Effect.fn("ConnectionStore.update")(function* (
      id: ConnectionId,
      expectedRevision: number,
      changes: ConnectionChanges,
    ) {
      const timestamp = yield* now
      // Sealing needs the integration, which only the stored row knows; read it first and
      // let the transaction's revision check reject the edit if the row changed since.
      const before = yield* database.use("ConnectionStore.update", (db) => findById(db, id))
      const checked = checkRevision(before, id, expectedRevision)
      if (Result.isFailure(checked)) return yield* Effect.fail(checked.failure)
      const { integration } = yield* decodeRow(checked.success)
      const credential = changes.credential ?? { _tag: "Keep" }
      const sealed = credential._tag === "Replace" ? yield* sealFor(id, integration, credential.secret) : undefined

      const updated = yield* database.transaction("ConnectionStore.update", (db) => {
        const current = checkRevision(findById(db, id), id, expectedRevision)
        if (Result.isFailure(current)) return current
        const row = db
          .update(connections)
          .set({
            ...(changes.displayName === undefined ? {} : { displayName: changes.displayName }),
            ...(changes.enabled === undefined ? {} : { enabled: changes.enabled }),
            ...(changes.baseUrl === undefined ? {} : { baseUrl: changes.baseUrl }),
            ...(changes.defaults === undefined ? {} : { defaultsJson: JSON.stringify(changes.defaults) }),
            ...(credential._tag === "Clear" ? { credentialKeyId: null, credentialSealed: null } : {}),
            ...(sealed === undefined ? {} : { credentialKeyId: sealed.keyId, credentialSealed: Buffer.from(sealed.sealed) }),
            revision: current.success.revision + 1,
            updatedAt: timestamp,
          })
          .where(eq(connections.id, id))
          .returning()
          .get()
        bumpRevision(db)
        return Result.succeed(row)
      })
      if (updated === undefined) return yield* new ConnectionNotFound({ id })
      return yield* decodeRow(updated)
    })

    const remove = Effect.fn("ConnectionStore.remove")(function* (id: ConnectionId, expectedRevision: number) {
      yield* database.transaction("ConnectionStore.remove", (db) => {
        const current = checkRevision(findById(db, id), id, expectedRevision)
        if (Result.isFailure(current)) return current
        db.delete(connections).where(eq(connections.id, id)).run()
        bumpRevision(db)
        return Result.succeed(undefined)
      })
    })

    const importLegacy = Effect.fn("ConnectionStore.importLegacy")(function* (candidates: ReadonlyArray<NewConnection>) {
      const timestamp = yield* now
      const prepared = yield* Effect.forEach(candidates, (candidate) =>
        Effect.map(prepareInsert(candidate, timestamp), (row) => ({ integration: candidate.integration, row })),
      )
      const result = yield* database.transaction("ConnectionStore.importLegacy", (db) => {
        const state = db.select().from(installation).where(eq(installation.id, 1)).get()
        if (state?.legacyImportCompletedAt != null) {
          return Result.fail(new LegacyImportAlreadyCompleted({ completedAt: state.legacyImportCompletedAt }))
        }
        const existing = new Set(db.select({ integration: connections.integration }).from(connections).all().map((row) => row.integration))
        const inserted: Array<Row> = []
        const skipped: Array<Integration> = []
        for (const { integration, row } of prepared) {
          if (existing.has(integration)) {
            skipped.push(integration)
            continue
          }
          inserted.push(db.insert(connections).values(row).returning().get())
        }
        db.update(installation).set({ legacyImportCompletedAt: timestamp }).where(eq(installation.id, 1)).run()
        bumpRevision(db)
        return Result.succeed({ inserted, skipped })
      })
      const imported = yield* Effect.forEach(result.inserted, decodeRow)
      return { imported, skipped: result.skipped }
    })

    return Service.of({ installation: installationState, list, create, update, remove, importLegacy })
  }),
)
