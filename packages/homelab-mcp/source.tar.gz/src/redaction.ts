import type { Schema } from "effect"

const SECRET_KEY = /(api.?key|password|passwd|token|secret|credential|cookie|authorization)/i

/** Whether a property name looks like it holds a credential, such as `apiKey` or `password`. */
export const isSecretKey = (key: string): boolean => SECRET_KEY.test(key)

const isJsonArray = (value: Schema.Json): value is Schema.JsonArray => Array.isArray(value)

/**
 * Replace every value stored under a secret-looking key with `"[redacted]"`.
 *
 * Servarr field lists (`[{ name, value, privacy }]`) are also redacted when `privacy`
 * marks the value as a password or API key. Tool results pass through this before
 * reaching the MCP client so upstream credentials never enter a model's context.
 */
export const redactSecrets = (value: Schema.Json): Schema.Json => {
  if (isJsonArray(value)) return value.map(redactSecrets)
  if (value === null || typeof value !== "object") return value
  const privacy = value["privacy"]
  const isPrivateField = (typeof privacy === "string" && privacy !== "normal" && privacy !== "userName") ||
    (typeof value["name"] === "string" && isSecretKey(value["name"]))
  const entries = Object.entries(value).map(([key, entry]): [string, Schema.Json] => {
    const isSecret = isSecretKey(key) || (isPrivateField && key === "value")
    if (isSecret && entry !== null) {
      return [key, entry === "" ? "" : "[redacted]"]
    }
    return [key, redactSecrets(entry)]
  })
  return Object.fromEntries(entries)
}
