import { Context, type Crypto, Effect, type FileSystem, Layer, Option, type Path, Redacted, Ref, Result, Schema, Semaphore } from "effect"
import * as Credentials from "../credentials.ts"
import { ConnectionNotConfigured, CredentialUnavailable } from "../errors.ts"
import * as ServerConfig from "../server-config.ts"
import * as ConnectionStore from "../storage/connection-store.ts"
import * as Database from "../storage/database.ts"
import type { StorageFailure } from "../storage/database.ts"
import * as SecretBox from "../storage/secret-box.ts"
import {
  type BaseUrl,
  ConnectionDefaults,
  type ConnectionExists,
  type ConnectionId,
  ConnectionInvalid,
  type ConnectionNotFound,
  type ConnectionRevisionConflict,
  DisplayName,
  INTEGRATIONS,
  type Integration,
  type LegacyImportAlreadyCompleted,
  parseBaseUrl,
} from "./connection.ts"

/** Everything needed to call one application's API. */
export interface ResolvedConnection {
  readonly integration: Integration
  /** `None` for a legacy connection read from credential files. */
  readonly connectionId: Option.Option<ConnectionId>
  readonly baseUrl: URL
  readonly credential: Redacted.Redacted<string>
  /**
   * Re-read a credential the application may have regenerated. Only legacy files can change
   * underneath a running server; a stored credential is replaced through its connection.
   */
  readonly refreshCredential: Option.Option<Effect.Effect<Redacted.Redacted<string>, CredentialUnavailable>>
  /** Where the credential came from, for error messages, e.g. "sonarr-config.xml". */
  readonly credentialSource: string
  /** What the owner should do when the application rejects the credential. */
  readonly credentialRecovery: string
  readonly defaults: ConnectionDefaults
}

/** A connection as shown to the owner; never carries the credential itself. */
export interface ConnectionSummary {
  readonly id: ConnectionId
  readonly integration: Integration
  readonly displayName: DisplayName
  readonly enabled: boolean
  readonly baseUrl: BaseUrl
  readonly credential: "saved" | "none" | "unreadable"
  /** Why a saved credential cannot be used; set only when `credential` is `"unreadable"`. */
  readonly credentialProblem: Option.Option<string>
  readonly defaults: ConnectionDefaults
  readonly revision: number
  readonly createdAt: string
  readonly updatedAt: string
}

/** A connection to create; strings are validated before anything is saved. */
export interface NewConnectionInput {
  readonly integration: Integration
  /** Defaults to the application's name, e.g. "Sonarr". */
  readonly displayName?: string
  readonly baseUrl: string
  readonly credential?: Redacted.Redacted<string>
  readonly enabled: boolean
  readonly defaults?: ConnectionDefaults
}

/** Changes to an existing connection; omitted fields keep their value. */
export interface ConnectionUpdateInput {
  readonly displayName?: string
  readonly baseUrl?: string
  readonly enabled?: boolean
  readonly defaults?: ConnectionDefaults
  readonly credential?: ConnectionStore.CredentialChange
}

/** Outcome of importing legacy credential files. */
export interface LegacyImportReport {
  readonly imported: ReadonlyArray<ConnectionSummary>
  /** Integrations that already had a connection, which the import left unchanged. */
  readonly skipped: ReadonlyArray<Integration>
  /** Integrations whose legacy credential could not be read, with the reason. */
  readonly unavailable: ReadonlyArray<{ readonly integration: Integration; readonly reason: string }>
}

/**
 * The installation's connections to upstream applications.
 *
 * Saved connections take precedence. Until the legacy import is completed, an integration
 * without a saved connection falls back to its legacy credential file and origin variable.
 */
export interface Interface {
  /** Resolve the connection a tool call should use, from the current configuration revision. */
  readonly resolve: (integration: Integration) => Effect.Effect<ResolvedConnection, ConnectionNotConfigured | CredentialUnavailable>
  readonly list: Effect.Effect<ReadonlyArray<ConnectionSummary>>
  readonly create: (input: NewConnectionInput) => Effect.Effect<ConnectionSummary, ConnectionInvalid | ConnectionExists | StorageFailure>
  readonly update: (
    id: ConnectionId,
    expectedRevision: number,
    input: ConnectionUpdateInput,
  ) => Effect.Effect<ConnectionSummary, ConnectionInvalid | ConnectionNotFound | ConnectionRevisionConflict | StorageFailure>
  readonly remove: (
    id: ConnectionId,
    expectedRevision: number,
  ) => Effect.Effect<void, ConnectionNotFound | ConnectionRevisionConflict | StorageFailure>
  /** Copy every readable legacy credential into saved connections and stop consulting legacy files. */
  readonly importLegacy: Effect.Effect<LegacyImportReport, LegacyImportAlreadyCompleted | StorageFailure>
}

/** Configured connections. */
export class Service extends Context.Service<Service, Interface>()("homelab-mcp/Connections") {}

const INTEGRATION_NAMES: Readonly<Record<Integration, string>> = {
  seerr: "Seerr",
  sonarr: "Sonarr",
  radarr: "Radarr",
  lidarr: "Lidarr",
  prowlarr: "Prowlarr",
  plex: "Plex",
}

/** The configuration every resolution in one call observes together. */
interface Snapshot {
  readonly revision: number
  readonly legacyActive: boolean
  readonly stored: ReadonlyMap<Integration, ConnectionStore.StoredConnection>
}

const decodeDisplayName = Schema.decodeUnknownResult(DisplayName)
const decodeDefaults = Schema.decodeUnknownResult(ConnectionDefaults)

const toSummary = (connection: ConnectionStore.StoredConnection): ConnectionSummary => ({
  id: connection.id,
  integration: connection.integration,
  displayName: connection.displayName,
  enabled: connection.enabled,
  baseUrl: connection.baseUrl,
  credential: connection.credential._tag === "Sealed" ? "saved" : connection.credential._tag === "None" ? "none" : "unreadable",
  credentialProblem: connection.credential._tag === "Unreadable" ? Option.some(connection.credential.reason) : Option.none(),
  defaults: connection.defaults,
  revision: connection.revision,
  createdAt: connection.createdAt,
  updatedAt: connection.updatedAt,
})

const fromResult = <A, E>(result: Result.Result<A, E>): Effect.Effect<A, E> =>
  Result.isSuccess(result) ? Effect.succeed(result.success) : Effect.fail(result.failure)

const validBaseUrl = (input: string) =>
  fromResult(Result.mapError(parseBaseUrl(input), (reason) => new ConnectionInvalid({ field: "baseUrl", reason })))

const validDisplayName = (input: string) =>
  fromResult(
    Result.mapError(
      decodeDisplayName(input.trim()),
      () => new ConnectionInvalid({ field: "displayName", reason: "use 1 to 80 characters without leading or trailing spaces" }),
    ),
  )

const validDefaults = (input: ConnectionDefaults) =>
  fromResult(Result.mapError(decodeDefaults(input), (error) => new ConnectionInvalid({ field: "defaults", reason: error.message })))

const validCredential = (secret: Redacted.Redacted<string>) => {
  const value = Redacted.value(secret).trim()
  return value.length === 0 || /\s/.test(value)
    ? Effect.fail(new ConnectionInvalid({ field: "credential", reason: "enter the API key or token without spaces" }))
    : Effect.succeed(Redacted.make(value))
}

const hasCredential = (credential: ConnectionStore.StoredCredential | "replaced" | "cleared") =>
  credential === "replaced" || (typeof credential === "object" && credential._tag === "Sealed")

/** Connections backed by the connection store, with legacy credential files as a fallback. */
export const layerWithoutDependencies: Layer.Layer<
  Service,
  StorageFailure,
  ConnectionStore.Service | Credentials.Service | ServerConfig.Service
> = Layer.effect(
  Service,
  Effect.gen(function* () {
    const store = yield* ConnectionStore.Service
    const credentials = yield* Credentials.Service
    const { legacyOrigins, legacyRootFolders } = yield* ServerConfig.Service

    const load = Effect.gen(function* () {
      const [installation, stored] = yield* Effect.all([store.installation, store.list])
      return {
        revision: installation.configRevision,
        legacyActive: Option.isNone(installation.legacyImportCompletedAt),
        stored: new Map(stored.map((connection) => [connection.integration, connection])),
      } satisfies Snapshot
    })
    const snapshot = yield* Ref.make<Snapshot>(yield* load)
    // Writers publish the snapshot they committed in order, so readers never see an older one.
    const writes = yield* Semaphore.make(1)
    const publishing = <A, E>(write: Effect.Effect<A, E>) =>
      writes.withPermits(1)(Effect.tap(write, () => Effect.flatMap(load, (next) => Ref.set(snapshot, next))))

    const legacyDefaults = (integration: Integration): ConnectionDefaults => {
      if (integration !== "sonarr" && integration !== "radarr" && integration !== "lidarr") return {}
      return Option.match(legacyRootFolders[integration], { onNone: () => ({}), onSome: (rootFolder) => ({ rootFolder }) })
    }

    const resolve = Effect.fn("Connections.resolve")(function* (integration: Integration) {
      const current = yield* Ref.get(snapshot)
      const stored = current.stored.get(integration)
      if (stored !== undefined) {
        if (!stored.enabled) {
          return yield* new ConnectionNotConfigured({ service: integration, reason: `connection "${stored.displayName}" is disabled` })
        }
        const credential = stored.credential
        if (credential._tag === "None") {
          return yield* new CredentialUnavailable({ service: integration, reason: `connection "${stored.displayName}" has no saved credential` })
        }
        if (credential._tag === "Unreadable") {
          return yield* new CredentialUnavailable({
            service: integration,
            reason: `the saved credential of "${stored.displayName}" cannot be used (${credential.reason}); replace it`,
          })
        }
        return {
          integration,
          connectionId: Option.some(stored.id),
          baseUrl: new URL(stored.baseUrl),
          credential: credential.secret,
          refreshCredential: Option.none(),
          credentialSource: `connection "${stored.displayName}"`,
          credentialRecovery: "if the key was regenerated, replace the connection's saved credential",
          defaults: stored.defaults,
        } satisfies ResolvedConnection
      }
      if (!current.legacyActive) {
        return yield* new ConnectionNotConfigured({ service: integration, reason: "no connection is configured" })
      }
      return {
        integration,
        connectionId: Option.none(),
        baseUrl: legacyOrigins[integration],
        credential: yield* credentials.credential(integration),
        refreshCredential: Option.some(credentials.reload(integration)),
        credentialSource: credentials.describeSource(integration),
        credentialRecovery: "if the key was regenerated, refresh that file and restart homelab-mcp, since systemd LoadCredential= copies it only at service start",
        defaults: legacyDefaults(integration),
      } satisfies ResolvedConnection
    })

    const list = Effect.map(Ref.get(snapshot), (current) =>
      INTEGRATIONS.flatMap((integration) => {
        const connection = current.stored.get(integration)
        return connection === undefined ? [] : [toSummary(connection)]
      }),
    )

    const create = Effect.fn("Connections.create")(function* (input: NewConnectionInput) {
      const baseUrl = yield* validBaseUrl(input.baseUrl)
      const displayName = yield* validDisplayName(input.displayName ?? INTEGRATION_NAMES[input.integration])
      const defaults = yield* validDefaults(input.defaults ?? {})
      const credential = input.credential === undefined ? Option.none() : Option.some(yield* validCredential(input.credential))
      // Phase 3 adds a current successful connection test to this requirement.
      if (input.enabled && Option.isNone(credential)) {
        return yield* new ConnectionInvalid({ field: "enabled", reason: "save a credential before enabling the connection" })
      }
      const created = yield* publishing(
        store.create({ integration: input.integration, displayName, enabled: input.enabled, baseUrl, defaults, credential }),
      )
      return toSummary(created)
    })

    const update = Effect.fn("Connections.update")(function* (id: ConnectionId, expectedRevision: number, input: ConnectionUpdateInput) {
      const changes: {
        displayName?: DisplayName
        baseUrl?: BaseUrl
        enabled?: boolean
        defaults?: ConnectionDefaults
        credential?: ConnectionStore.CredentialChange
      } = {}
      if (input.displayName !== undefined) changes.displayName = yield* validDisplayName(input.displayName)
      if (input.baseUrl !== undefined) changes.baseUrl = yield* validBaseUrl(input.baseUrl)
      if (input.defaults !== undefined) changes.defaults = yield* validDefaults(input.defaults)
      if (input.enabled !== undefined) changes.enabled = input.enabled
      if (input.credential !== undefined) {
        changes.credential = input.credential._tag === "Replace"
          ? { _tag: "Replace", secret: yield* validCredential(input.credential.secret) }
          : input.credential
      }
      const current = Array.from((yield* Ref.get(snapshot)).stored.values()).find((connection) => connection.id === id)
      if (current !== undefined) {
        const enabledAfter = changes.enabled ?? current.enabled
        const credentialAfter = changes.credential?._tag === "Replace"
          ? "replaced"
          : changes.credential?._tag === "Clear"
          ? "cleared"
          : current.credential
        if (enabledAfter && !hasCredential(credentialAfter)) {
          return yield* new ConnectionInvalid({
            field: "enabled",
            reason: changes.credential?._tag === "Clear"
              ? "disable the connection before clearing its credential"
              : "save a working credential before enabling the connection",
          })
        }
      }
      return toSummary(yield* publishing(store.update(id, expectedRevision, changes)))
    })

    const remove = Effect.fn("Connections.remove")(function* (id: ConnectionId, expectedRevision: number) {
      yield* publishing(store.remove(id, expectedRevision))
    })

    const importLegacy = Effect.gen(function* () {
      const unavailable: Array<{ integration: Integration; reason: string }> = []
      const candidates: Array<ConnectionStore.NewConnection> = []
      for (const integration of INTEGRATIONS) {
        const credential = yield* Effect.result(credentials.credential(integration))
        if (Result.isFailure(credential)) {
          unavailable.push({ integration, reason: credential.failure.reason })
          continue
        }
        const baseUrl = parseBaseUrl(legacyOrigins[integration].href)
        if (Result.isFailure(baseUrl)) {
          unavailable.push({ integration, reason: `legacy URL ${legacyOrigins[integration].href} is not a valid base URL: ${baseUrl.failure}` })
          continue
        }
        candidates.push({
          integration,
          displayName: DisplayName.make(INTEGRATION_NAMES[integration]),
          enabled: true,
          baseUrl: baseUrl.success,
          defaults: legacyDefaults(integration),
          credential: Option.some(credential.success),
        })
      }
      const result = yield* publishing(store.importLegacy(candidates))
      return { imported: result.imported.map(toSummary), skipped: result.skipped, unavailable } satisfies LegacyImportReport
    }).pipe(Effect.withSpan("Connections.importLegacy"))

    return Service.of({ resolve, list, create, update, remove, importLegacy })
  }),
)

/** Connections persisted in the SQLite database under the configured data directory. */
export const layer: Layer.Layer<
  Service,
  StorageFailure | Database.DatabaseStartupError | SecretBox.SecretKeyError,
  Credentials.Service | ServerConfig.Service | FileSystem.FileSystem | Path.Path | Crypto.Crypto
> = layerWithoutDependencies.pipe(
  Layer.provide(ConnectionStore.layer),
  Layer.provide(SecretBox.layer),
  Layer.provide(Database.layer),
)
