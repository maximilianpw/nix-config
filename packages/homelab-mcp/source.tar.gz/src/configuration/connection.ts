import { Result, Schema } from "effect"
import { MediaService } from "../media-service.ts"

/** A supported kind of media application, such as Sonarr or Plex. */
export const Integration = MediaService

/** A supported kind of media application. */
export type Integration = MediaService

/** Every integration, in display order. */
export const INTEGRATIONS: ReadonlyArray<Integration> = ["seerr", "sonarr", "radarr", "lidarr", "prowlarr", "plex", "lastfm"]

/** Stable identifier of one configured connection; survives renames and URL changes. */
export const ConnectionId = Schema.String.check(Schema.isPattern(/^con_[0-9a-f]{32}$/)).pipe(Schema.brand("ConnectionId"))

/** Stable identifier of one configured connection. */
export type ConnectionId = typeof ConnectionId.Type

/** Human-readable connection name, such as "Home Sonarr". */
export const DisplayName = Schema.String.check(Schema.isPattern(/^\S(.{0,78}\S)?$/)).pipe(Schema.brand("DisplayName"))

/** Human-readable connection name. */
export type DisplayName = typeof DisplayName.Type

/**
 * An application's base URL: scheme, host, port and any reverse-proxy prefix, without a
 * trailing slash. Never an API endpoint, and never carrying credentials.
 */
export const BaseUrl = Schema.String.pipe(Schema.brand("BaseUrl"))

/** An application's validated base URL. */
export type BaseUrl = typeof BaseUrl.Type

/** Convenience values for writes; they restrict nothing. */
export const ConnectionDefaults = Schema.Struct({
  /** Root folder used when an add names none (Sonarr, Radarr and Lidarr). */
  rootFolder: Schema.optionalKey(Schema.NonEmptyString),
})

/** Convenience values for writes on one connection. */
export interface ConnectionDefaults extends Schema.Schema.Type<typeof ConnectionDefaults> {}

// `/api`, `/api/v1` .. `/api/v9`, optionally followed by a slash.
const API_SUFFIX = /\/api(\/v\d)?\/?$/i

/**
 * Parse an owner-entered base URL, or explain what to change.
 *
 * Rejects credentials, query strings and fragments because the URL is displayed and logged,
 * and rejects API endpoints because each integration appends its own API root.
 */
export const parseBaseUrl = (input: string): Result.Result<BaseUrl, string> => {
  let url: URL
  try {
    url = new URL(input.trim())
  } catch {
    return Result.fail("enter an absolute URL such as http://sonarr:8989")
  }
  if (url.protocol !== "http:" && url.protocol !== "https:") return Result.fail("use an http:// or https:// URL")
  if (url.username !== "" || url.password !== "") return Result.fail("remove the user name and password from the URL; enter the API key separately")
  if (url.search !== "") return Result.fail("remove the query string; enter credentials in the API key field")
  if (url.hash !== "") return Result.fail("remove the #fragment from the URL")
  const match = API_SUFFIX.exec(url.pathname)
  if (match !== null) return Result.fail(`use the application's base URL without ${match[0].replace(/\/$/, "")}`)
  const pathname = url.pathname.replace(/\/+$/, "")
  return Result.succeed(BaseUrl.make(`${url.origin}${pathname}`))
}

/** A connection field that cannot be saved as given; `reason` says how to fix it. */
export class ConnectionInvalid extends Schema.TaggedError<ConnectionInvalid>()("ConnectionInvalid", {
  field: Schema.String,
  reason: Schema.String,
}) {
  override get message(): string {
    return `Connection invalid: ${this.field}: ${this.reason}`
  }
}

/** The first release allows one connection per integration. */
export class ConnectionExists extends Schema.TaggedError<ConnectionExists>()("ConnectionExists", {
  integration: Integration,
}) {
  override get message(): string {
    return `Connection exists: ${this.integration} is already configured; edit or remove that connection`
  }
}

/** No connection has this id, for example because it was removed. */
export class ConnectionNotFound extends Schema.TaggedError<ConnectionNotFound>()("ConnectionNotFound", {
  id: Schema.String,
}) {
  override get message(): string {
    return `Connection not found: ${this.id}`
  }
}

/** The connection changed since the caller read it; reload and reapply the edit. */
export class ConnectionRevisionConflict extends Schema.TaggedError<ConnectionRevisionConflict>()("ConnectionRevisionConflict", {
  id: Schema.String,
  expected: Schema.Int,
  actual: Schema.Int,
}) {
  override get message(): string {
    return `Connection revision conflict: ${this.id} is at revision ${this.actual}, not ${this.expected}; reload it and apply the change again`
  }
}

/** Legacy credentials were already imported, so the legacy files are no longer consulted. */
export class LegacyImportAlreadyCompleted extends Schema.TaggedError<LegacyImportAlreadyCompleted>()("LegacyImportAlreadyCompleted", {
  completedAt: Schema.String,
}) {
  override get message(): string {
    return `Legacy import already completed at ${this.completedAt}; manage connections directly instead`
  }
}
