import { BunHttpServer, BunRuntime, BunServices } from "@effect/platform-bun"
import { Effect, Layer } from "effect"
import { HttpRouter } from "effect/http"
import * as Connections from "./configuration/connections.ts"
import * as Credentials from "./credentials.ts"
import * as MediaApi from "./media-api.ts"
import * as Server from "./server.ts"
import * as ServerConfig from "./server-config.ts"

const HttpServerLive = Layer.unwrap(
  Effect.gen(function* () {
    const { host, port } = yield* ServerConfig.Service
    return BunHttpServer.layer({ hostname: host, port })
  }),
)

const ApplicationStateLive = Connections.layer.pipe(
  Layer.provideMerge(Credentials.layer),
  Layer.provide(BunServices.layer),
)

const Main = HttpRouter.serve(Server.layer).pipe(
  Layer.provide(HttpServerLive),
  Layer.provide(MediaApi.layer),
  Layer.provide(ApplicationStateLive),
  Layer.provide(ServerConfig.layer),
)

BunRuntime.runMain(Layer.launch(Main))
