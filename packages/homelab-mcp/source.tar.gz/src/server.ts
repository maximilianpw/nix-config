import { timingSafeEqual } from "node:crypto"
import { Effect, Layer, Redacted } from "effect"
import { McpProtocol, McpServer } from "effect/ai"
import { HttpRouter, HttpServerRequest, HttpServerResponse } from "effect/http"
import * as Credentials from "./credentials.ts"
import * as LibraryTools from "./tools/library-tools.ts"
import * as PlexTools from "./tools/plex-tools.ts"
import * as PlexPlaylistTools from "./tools/plex-playlist-tools.ts"
import * as MusicDiscoveryTools from "./tools/music-discovery-tools.ts"
import * as SeerrTools from "./tools/seerr-tools.ts"
import * as ServarrTools from "./tools/servarr-tools.ts"
import * as StackTools from "./tools/stack-tools.ts"
import * as TraceTools from "./tools/trace-tools.ts"

/** Path of the Streamable HTTP MCP endpoint. */
export const MCP_PATH = "/mcp"

const HEALTH_PATH = "/healthz"

const INSTRUCTIONS = `Operate Kim's media stack. Seerr handles requests; Sonarr (TV), Radarr (movies) and Lidarr (music) manage libraries and downloads; Prowlarr manages indexers; Plex serves playback.
Tools that add, change or delete library items, requests or settings require confirm: true (servarr_config_save previews until apply: true). Read current state first, tell the user what will change, and only then write.
For "why isn't X available?" use media_trace. For settings without a dedicated tool use media_api_get / media_api_write.
For music discovery use music_discovery with a Last.fm username and Plex music library. Only resolved Plex ratingKeys are playable. Review missing/ambiguous matches and shortfalls. Preview plex_playlist_refresh before applying its exact selection with the returned snapshot. Keep pinned tracks and pass previous selections as exclusions. No automatic downloads or recurring refresh is configured by these tools.
Secret values in results are replaced by [redacted]; never ask the user to paste credentials.`

const unauthorized = HttpServerResponse.empty({
  status: 401,
  headers: { "www-authenticate": 'Bearer realm="homelab-mcp"' },
})

// Kim binds this server to loopback behind Tailscale Serve, but any local process
// could reach loopback, so every request except the health probe needs the token.
const AccessTokenMiddleware = HttpRouter.middleware(
  Effect.gen(function* () {
    const { accessToken } = yield* Credentials.Service
    const expected = Buffer.from(`Bearer ${Redacted.value(accessToken)}`)
    return (httpEffect) =>
      Effect.gen(function* () {
        const request = yield* HttpServerRequest.HttpServerRequest
        if (request.url === HEALTH_PATH) return yield* httpEffect
        const presented = Buffer.from(request.headers["authorization"] ?? "")
        const authorized = presented.length === expected.length && timingSafeEqual(presented, expected)
        return authorized ? yield* httpEffect : unauthorized
      })
  }),
  { global: true },
)

const HealthRoute = HttpRouter.add("GET", HEALTH_PATH, HttpServerResponse.text("ok"))

const Mcp = McpServer.layerHttp({
  name: "homelab-media",
  version: "0.1.0",
  instructions: INSTRUCTIONS,
  path: MCP_PATH,
  protocols: [
    McpProtocol.v2026_07_28,
    McpProtocol.v2025_11_25,
    McpProtocol.v2025_06_18,
    McpProtocol.v2025_03_26,
    McpProtocol.v2024_11_05,
  ],
})

const Toolkits = Layer.mergeAll(
  McpServer.toolkit(StackTools.toolkit).pipe(Layer.provide(StackTools.layer)),
  McpServer.toolkit(TraceTools.toolkit).pipe(Layer.provide(TraceTools.layer)),
  McpServer.toolkit(SeerrTools.toolkit).pipe(Layer.provide(SeerrTools.layer)),
  McpServer.toolkit(LibraryTools.toolkit).pipe(Layer.provide(LibraryTools.layer)),
  McpServer.toolkit(ServarrTools.toolkit).pipe(Layer.provide(ServarrTools.layer)),
  McpServer.toolkit(PlexTools.toolkit).pipe(Layer.provide(PlexTools.layer)),
  McpServer.toolkit(PlexPlaylistTools.toolkit).pipe(Layer.provide(PlexPlaylistTools.layer)),
  McpServer.toolkit(MusicDiscoveryTools.toolkit).pipe(Layer.provide(MusicDiscoveryTools.layer)),
)

/**
 * The complete HTTP application: MCP endpoint, tool handlers, access-token check and health probe.
 *
 * Requires an `HttpRouter` host (see `HttpRouter.serve` or `HttpRouter.toWebHandler`), credentials,
 * and upstream API access.
 */
export const layer = Layer.mergeAll(Toolkits, HealthRoute, AccessTokenMiddleware).pipe(
  Layer.provideMerge(Mcp),
)
