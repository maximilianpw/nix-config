CREATE TABLE `connections` (
	`id` text PRIMARY KEY,
	`integration` text NOT NULL UNIQUE,
	`display_name` text NOT NULL,
	`enabled` integer NOT NULL,
	`base_url` text NOT NULL,
	`credential_key_id` text,
	`credential_sealed` blob,
	`defaults_json` text DEFAULT '{}' NOT NULL,
	`revision` integer DEFAULT 1 NOT NULL,
	`created_at` text NOT NULL,
	`updated_at` text NOT NULL,
	CONSTRAINT "connections_credential_complete" CHECK(("credential_key_id" IS NULL) = ("credential_sealed" IS NULL))
);
--> statement-breakpoint
CREATE TABLE `installation` (
	`id` integer PRIMARY KEY,
	`config_revision` integer DEFAULT 0 NOT NULL,
	`legacy_import_completed_at` text,
	`created_at` text NOT NULL,
	CONSTRAINT "installation_single_row" CHECK("id" = 1)
);
